package com.tp.bpmutils.activiti.controller;

import com.tp.bpmutils.activiti.request.ActivitiDeployProcessReq;
import com.tp.bpmutils.activiti.request.ActivitiProcessActiveTasksReq;
import com.tp.bpmutils.activiti.request.ActivitiQueryProcessInstanceReq;
import com.tp.bpmutils.activiti.response.ActivitiDeployBPMFileResp;
import com.tp.bpmutils.activiti.response.ActivitiDeployProcessResp;
import com.tp.bpmutils.activiti.response.ActivitiProcessActiveTasksResp;
import com.tp.bpmutils.activiti.response.ActivitiProcessImgResp;
import com.tp.bpmutils.activiti.service.IActivitiModelService;
import com.tp.bpmutils.common.controller.BaseController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * BPM Model Controller
 *
 * @author tp
 */
@RestController
@RequestMapping(value = "activiti")
@Tag(name = "Activiti Model 工具接口")
public class ActivitiModelController extends BaseController {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiModelController.class);

    /**
     * BPM Activiti Process Service
     */
    private final transient IActivitiModelService activitiModelService;

    /**
     * ActivitiModelController Constructor
     *
     * @param activitiModelService
     */
    public ActivitiModelController(IActivitiModelService activitiModelService) {
        super();
        this.activitiModelService = activitiModelService;
    }

    /**
     * 流程上傳部署
     *
     * @param file
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWDPOFT001", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "流程上傳部署", description = "流程檔案上傳部署")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "上傳部署成功")
    public ActivitiDeployBPMFileResp deployBPMNFile(@RequestPart("file") @Parameter(schema = @Schema(type = "string", format = "binary"), required = true, name = "流程上傳部署請求檔案") MultipartFile file) {
        LOGGER.info("Deploy Process...");
        checkInput(new Object[]{"file", file});
        String processDefinitionId = activitiModelService.deployProcess(file);
        ActivitiDeployBPMFileResp.BPMProcessDefinition definition = new ActivitiDeployBPMFileResp.BPMProcessDefinition();
        definition.setProcessDefinitionId(processDefinitionId);
        return ActivitiDeployBPMFileResp.success(definition);
    }

    /**
     * 流程資源部署
     *
     * @param
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/deployResourceFiles")
    @Operation(summary = "流程資源部署", description = "流程資源路徑部署")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "啟動成功")
    public ActivitiDeployProcessResp deployResourceFiles(@Parameter(required = true, name = "流程資源路徑部署請求內容") @RequestBody ActivitiDeployProcessReq req) {
        LOGGER.info("Deploy Process...");
        checkInput(req);
        return ActivitiDeployProcessResp.success(activitiModelService.deployResourceFiles(req));
    }

    /**
     * 取得流程圖 Base64 位元字串
     *
     * @param req
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGIMGQ001")
    @Operation(summary = "取得流程圖 Base64 位元字串", description = "取得流程圖(SVG) Base64 位元字串")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "取得流程圖(SVG) Base64 位元字串成功")
    public ActivitiProcessImgResp getProcessImgByPID(@Parameter(required = true, name = "取得流程圖 Base64 位元字串請求內容") @RequestBody ActivitiQueryProcessInstanceReq req) {
        LOGGER.info("Get Process image...");
        checkInput(req);
        return ActivitiProcessImgResp.success(activitiModelService.getProcessImg(req));
    }

    /**
     * 查詢流程定義任務
     *
     * @param req processDefKey：流程定義代碼
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGPCTQ001")
    @Operation(summary = "查詢流程定義任務", description = "查詢流程定義任務")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "查詢成功")
    public ActivitiProcessActiveTasksResp getProcessActiveTasks(@Parameter(required = true, name = "查詢流程定義任務") @RequestBody ActivitiProcessActiveTasksReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Get Process's active tasks..., Process Def key: {}", req.getProcessDefKey());
        }
        checkInput(req);
        return ActivitiProcessActiveTasksResp.success(activitiModelService.getProcessActiveTasks(req));
    }
}
