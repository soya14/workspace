package com.tp.bpmutils.activiti.vo;

import com.tp.bpmutils.common.util.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.task.Task;

/**
 * 任務資訊
 */
@Schema(description = "任務資訊")
public class ActivitiTaskVo extends ActivitiBaseVo {

    /**
     *
     */
    private static final long serialVersionUID = -4066687779819257196L;

    /**
     * 任務編號
     */
    @Schema(description = "任務編號")
    private String taskId;

    /**
     * 任務名稱
     */
    @Schema(description = "任務名稱")
    private String taskName;

    /**
     * 任務定義代碼
     */
    @Schema(description = "任務定義代碼")
    private String taskDefKey;

    /**
     * 流程實例代號
     */
    @Schema(description = "流程實例代號")
    private String processInstanceId;

    /**
     * 流程定義編號
     */
    @Schema(description = "流程定義編號")
    private String processDefinitionId;

    /**
     * 開始時間(格式：yyyy/MM/dd HH:mm:ss)
     */
    @Schema(description = "開始時間(格式：yyyy/MM/dd HH:mm:ss)", example = "date")
    private String createTime;

    /**
     * 指定成員
     */
    @Schema(description = "指定成員")
    private String assignee;

    /**
     * 候選角色
     */
    @Schema(description = "候選角色")
    private String candidateGroup;

    /**
     * 候選成員
     */
    @Schema(description = "候選成員")
    private String candidateUser;

    /**
     * 主流程實例代號
     */
    @Schema(description = "主流程實例代號")
    private String mainProcInstId;

    /**
     * 主流程定義編號
     */
    @Schema(description = "主流程定義編號")
    private String mainProcDefId;

    /**
     * 上一階流程實例代號
     */
    @Schema(description = "上一階流程實例代號")
    private String sourceProcInstId;

    /**
     * 上一階流程定義編號
     */
    @Schema(description = "上一階流程定義編號")
    private String sourceProcDefId;

    /**
     * ActivitiTaskVo 1
     */
    public ActivitiTaskVo() {
        super();
    }

    /**
     * ActivitiTaskVo 2
     *
     * @param task
     * @param candidateGroup
     * @param candidateUser
     */
    public ActivitiTaskVo(Task task, String candidateGroup, String candidateUser) {
        this(candidateGroup, candidateUser, task.getProcessInstanceId(), task.getProcessDefinitionId(), null, null);
        this.taskId = task.getId();
        this.taskName = task.getName();
        this.taskDefKey = task.getTaskDefinitionKey();
        this.processInstanceId = task.getProcessInstanceId();
        this.processDefinitionId = task.getProcessDefinitionId();
        this.createTime = DateUtil.dateToString(task.getCreateTime(), DateUtil.PATTEN_YEAR_MONTH_DAY_FULL_TIME);
        this.assignee = task.getAssignee();
    }

    /**
     * ActivitiTaskVo 3
     *
     * @param candidateGroup
     * @param candidateUser
     * @param mainProcInstId
     * @param mainProcDefId
     * @param sourceProcInstId
     * @param sourceProcDefId
     */
    public ActivitiTaskVo(String candidateGroup, String candidateUser, String mainProcInstId, String mainProcDefId, String sourceProcInstId, String sourceProcDefId) {
        super();
        this.candidateGroup = candidateGroup;
        this.candidateUser = candidateUser;
        this.mainProcInstId = mainProcInstId;
        this.mainProcDefId = mainProcDefId;
        this.sourceProcInstId = sourceProcInstId;
        this.sourceProcDefId = sourceProcDefId;
    }

    /**
     * ActivitiTaskVo 4
     *
     * @param historicActivityInstance
     * @param candidateGroup
     * @param candidateUser
     */
    public ActivitiTaskVo(HistoricActivityInstance historicActivityInstance, String candidateGroup, String candidateUser) {
        this(candidateGroup, candidateUser, historicActivityInstance.getProcessInstanceId(), historicActivityInstance.getProcessDefinitionId(), null, null);
        this.taskId = historicActivityInstance.getTaskId();
        this.taskName = historicActivityInstance.getActivityName();
        this.taskDefKey = historicActivityInstance.getActivityId();
        this.processInstanceId = historicActivityInstance.getProcessInstanceId();
        this.processDefinitionId = historicActivityInstance.getProcessDefinitionId();
        this.createTime = DateUtil.dateToString(historicActivityInstance.getStartTime(), DateUtil.PATTEN_YEAR_MONTH_DAY_FULL_TIME);
        this.assignee = historicActivityInstance.getAssignee();
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public String getProcessDefinitionId() {
        return processDefinitionId;
    }

    public void setProcessDefinitionId(String processDefinitionId) {
        this.processDefinitionId = processDefinitionId;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDefKey() {
        return taskDefKey;
    }

    public void setTaskDefKey(String taskDefKey) {
        this.taskDefKey = taskDefKey;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public String getCandidateGroup() {
        return candidateGroup;
    }

    public void setCandidateGroup(String candidateGroup) {
        this.candidateGroup = candidateGroup;
    }

    public String getCandidateUser() {
        return candidateUser;
    }

    public void setCandidateUser(String candidateUser) {
        this.candidateUser = candidateUser;
    }

    public String getMainProcInstId() {
        return mainProcInstId;
    }

    public void setMainProcInstId(String mainProcInstId) {
        this.mainProcInstId = mainProcInstId;
    }

    public String getMainProcDefId() {
        return mainProcDefId;
    }

    public void setMainProcDefId(String mainProcDefId) {
        this.mainProcDefId = mainProcDefId;
    }

    public String getSourceProcInstId() {
        return sourceProcInstId;
    }

    public void setSourceProcInstId(String sourceProcInstId) {
        this.sourceProcInstId = sourceProcInstId;
    }

    public String getSourceProcDefId() {
        return sourceProcDefId;
    }

    public void setSourceProcDefId(String sourceProcDefId) {
        this.sourceProcDefId = sourceProcDefId;
    }
}
