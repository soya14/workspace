package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 查詢待辦清單請求
 *
 * @author tp
 */
@Schema(description = "查詢待辦清單請求")
public class ActivitiQueryPendingReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = 5368236488152519871L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {{"empCodes", "candidateGroups"}};

    /**
     * 員工編號
     */
    @ArraySchema(arraySchema = @Schema(description = "員工編號：[1, 2 ...]"))
    private List<String> empCodes;

    /**
     * 角色
     */
    @ArraySchema(arraySchema = @Schema(description = "角色(like查詢)：[DEP_ADMIN, AUDIT_ADMIN ...]"))
    private List<String> candidateGroups;

    /**
     * 流程定義代碼
     */
    @Schema(description = "流程定義代碼(prefix比對)：PendingItem")
    private String processDefKey;

    /**
     * 任務定義代碼
     */
    @Schema(description = "任務定義代碼：Apply")
    private String taskDefKey;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM.clone();
    }

    public List<String> getEmpCodes() {
        return empCodes;
    }

    public void setEmpCodes(List<String> empCodes) {
        this.empCodes = empCodes;
    }

    public List<String> getCandidateGroups() {
        return candidateGroups;
    }

    public void setCandidateGroups(List<String> candidateGroups) {
        this.candidateGroups = candidateGroups;
    }

    public String getProcessDefKey() {
        return processDefKey;
    }

    public void setProcessDefKey(String processDefKey) {
        this.processDefKey = processDefKey;
    }

    public String getTaskDefKey() {
        return taskDefKey;
    }

    public void setTaskDefKey(String taskDefKey) {
        this.taskDefKey = taskDefKey;
    }
}
