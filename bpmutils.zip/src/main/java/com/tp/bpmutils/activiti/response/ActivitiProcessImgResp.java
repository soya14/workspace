package com.tp.bpmutils.activiti.response;

import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 取得流程圖(SVG) Base64 位元字串回覆
 *
 * @author tp
 */
@Schema(description = "取得流程圖(SVG) Base64 位元字串回覆")
public class ActivitiProcessImgResp extends BPMApiResponse {

    /**
     * 流程圖(SVG) Base64 位元字串
     */
    @Schema(description = "流程圖(SVG) Base64 位元字串")
    private ActivitiMainSubVo data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiProcessImgResp success(ActivitiMainSubVo data) {
        ActivitiProcessImgResp apiSuccess = new ActivitiProcessImgResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public ActivitiMainSubVo getData() {
        return data;
    }

    public void setData(ActivitiMainSubVo data) {
        this.data = data;
    }
}
