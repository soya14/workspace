package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 啟動流程回覆
 *
 * @author tp
 */
@Schema(description = "啟動流程回覆")
public class ActivitiStartProcessResp extends BPMApiResponse {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private ActStartProcessResData data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiStartProcessResp success(ActStartProcessResData data) {
        ActivitiStartProcessResp apiSuccess = new ActivitiStartProcessResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public ActStartProcessResData getData() {
        return data;
    }

    public void setData(ActStartProcessResData data) {
        this.data = data;
    }

    /**
     * 流程資訊回覆
     */
    @JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
    @Schema(description = "流程資訊回覆")
    public static class ActStartProcessResData {

        /**
         * 流程實例代號
         */
        @Schema(description = "流程實例代號")
        private String processInstanceId;

        /**
         * 任務編號
         */
        @Schema(description = "任務編號")
        private String taskId;

        /**
         * 任務名稱
         */
        @Schema(description = "任務名稱")
        private String taskName;

        public String getProcessInstanceId() {
            return processInstanceId;
        }
        public void setProcessInstanceId(String processInstanceId) {
            this.processInstanceId = processInstanceId;
        }
        public String getTaskId() {
            return taskId;
        }
        public void setTaskId(String taskId) {
            this.taskId = taskId;
        }
        public String getTaskName() {
            return taskName;
        }
        public void setTaskName(String taskName) {
            this.taskName = taskName;
        }
    }
}
