package com.tp.bpmutils.activiti.task;

import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import com.tp.bpmutils.common.util.DataUtil;
import com.tp.bpmutils.common.util.OkHttpUtils;
import okhttp3.FormBody;
import okhttp3.RequestBody;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

/**
 * BPM RESTTask
 *
 * @author tp
 */
public class RESTTask implements JavaDelegate {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(RESTTask.class);

    /**
     * Internal server error
     */
    private static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";

    /**
     * Get method
     */
    private static final String GET_METHOD = "GET";

    /**
     * Post method
     */
    private static final String POST_METHOD = "POST";

    /**
     * Put method
     */
    private static final String PUT_METHOD = "PUT";

    /**
     * Delete method
     */
    private static final String DELETE_METHOD = "DELETE";

    /**
     * Http error code
     */
    private static final String HTTP_ERROR_CODE = "HTTP_ERROR_CODE";

    /**
     * Rest invoke error code
     */
    private static final String REST_INVOKE_ERROR_CODE = "REST_INVOKE_ERROR_CODE";

    /**
     * Rest invoke error message
     */
    private static final String REST_INVOKE_ERROR_MESSAGE = "REST_INVOKE_ERROR_MESSAGE";

    /**
     * Service url
     */
    private transient Expression serviceURL;

    /**
     * Service refer
     */
    private transient Expression serviceRef;

    /**
     * Method
     */
    private transient Expression method;

    /**
     * Input
     */
    private transient Expression input;

    /**
     * Output variable
     */
    private transient Expression outputVariable;

    /**
     * Output mapping
     */
    private transient Expression outputMappings;

    /**
     * Headers
     */
    private transient Expression headers;

    /**
     * Response header variable
     */
    private transient Expression responseHeaderVariable;

    /**
     * Http status variable
     */
    private transient Expression httpStatusVariable;

    /**
     * Error code variable
     */
    private transient Expression errorCodeVariable;

    /**
     * Error message variable
     */
    private transient Expression errorMessageVariable;

    @Override
    public void execute(DelegateExecution execution) {

        if (method == null) {
            String error = "HTTP method for the REST task not found. Please specify the \"method\" form property.";
            throw new BPMException(error, BPMExceptionStatus.METHOD_ERROR);
        }

        if (serviceURL != null && LOGGER.isDebugEnabled()) {
            LOGGER.debug("Executing RESTInvokeTask " + method.getValue(execution).toString() + " - " + serviceURL
                    .getValue(execution).toString());
        } else if (serviceRef != null && LOGGER.isDebugEnabled()) {
            LOGGER.debug("Executing RESTInvokeTask " + method.getValue(execution).toString() + " - " + serviceRef
                    .getValue(execution).toString());
        }

        OkHttpUtils.OKResponse response = null;
        String url = null;
        Map requestHeader = null;
        try {
            if (serviceURL != null) {
                url = serviceURL.getValue(execution).toString();
            } else {
                String urlNotFoundErrorMsg = "Service URL is not provided for " +
                        getTaskDetails(execution) + ". serviceURL or serviceRef must be provided.";
                throw new BPMException(urlNotFoundErrorMsg, BPMExceptionStatus.INPUT_PARAMETER_ERROR);
            }

            if (headers != null) {
                String headerContent = headers.getValue(execution).toString();
                requestHeader = DataUtil.stringToMap(headerContent);
            }

            if (POST_METHOD.equalsIgnoreCase(method.getValue(execution).toString().trim())) {
                String inputContent = input.getValue(execution).toString();
                final okhttp3.MediaType mt = okhttp3.MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
                RequestBody body = FormBody.create(mt, inputContent);
                response = OkHttpUtils.execute(url, requestHeader, body, POST_METHOD);
            } else if (GET_METHOD.equalsIgnoreCase(method.getValue(execution).toString().trim())) {
                response = OkHttpUtils.execute(url, requestHeader, null, GET_METHOD);
            } else if (PUT_METHOD.equalsIgnoreCase(method.getValue(execution).toString().trim())) {
                String inputContent = input.getValue(execution).toString();
                final okhttp3.MediaType mt = okhttp3.MediaType.parse(org.springframework.http.MediaType.APPLICATION_JSON_VALUE);
                RequestBody body = FormBody.create(mt, inputContent);
                response = OkHttpUtils.execute(url, requestHeader, body, PUT_METHOD);
            } else if (DELETE_METHOD.equalsIgnoreCase(method.getValue(execution).toString().trim())) {
                response = OkHttpUtils.execute(url, requestHeader, null, DELETE_METHOD);
            } else {
                String errorMsg = "Unsupported http method. The REST task only supports GET, POST, PUT and DELETE operations";
                throw new BPMException(errorMsg, BPMExceptionStatus.METHOD_ERROR);
            }

            String output = response.getBodyString();

            if (outputVariable != null) {
                String outVarName = outputVariable.getValue(execution).toString();
                execution.setVariable(outVarName, output);
            } else {
                String outputNotFoundErrorMsg = "An outputVariable or outputMappings is not provided. " +
                        "Either an output variable or output mappings  must be provided to save " +
                        "the response.";
                throw new BPMException(outputNotFoundErrorMsg, BPMExceptionStatus.INPUT_PARAMETER_ERROR);
            }

            if (responseHeaderVariable != null && this.headers != null) {
                execution.setVariable(httpStatusVariable.getValue(execution).toString(), response.getHeaders());
            }

            if (httpStatusVariable != null) {
                execution.setVariable(httpStatusVariable.getValue(execution).toString(), response.getStatus());
            }
        } catch (Exception e) {
            String errorMessage = e.getMessage();
            setErrorDetailsForTaskExecution(execution, INTERNAL_SERVER_ERROR, errorMessage, response);
            LOGGER.error(errorMessage, e);
            throw new BPMException(errorMessage, BPMExceptionStatus.SYSTEM_ERROR, e);
        }
    }

    private String getTaskDetails(DelegateExecution execution) {
        return execution.getCurrentActivityId() + " in process instance " + execution.getProcessInstanceId();
    }

    private void setErrorDetailsForTaskExecution(DelegateExecution execution, String errorCode, String errorMessage,
                                                 OkHttpUtils.OKResponse response) {
        if (httpStatusVariable != null && response != null) {
            execution.setVariable(httpStatusVariable.getValue(execution).toString(), response.getStatus());
        } else if (response != null) {
            execution.setVariable(HTTP_ERROR_CODE, response.getStatus());
        }
        if (errorCodeVariable != null) {
            execution.setVariable(errorCodeVariable.getValue(execution).toString(), errorCode);
        } else {
            execution.setVariable(REST_INVOKE_ERROR_CODE, errorCode);
        }
        if (errorMessageVariable != null) {
            execution.setVariable(errorMessageVariable.getValue(execution).toString(), errorMessage);
        } else {
            execution.setVariable(REST_INVOKE_ERROR_MESSAGE, errorMessage);
        }
    }

    public void setServiceURL(Expression serviceURL) {
        this.serviceURL = serviceURL;
    }

    public void setServiceRef(Expression serviceRef) {
        this.serviceRef = serviceRef;
    }

    public void setInput(Expression input) {
        this.input = input;
    }

    public void setOutputVariable(Expression outputVariable) {
        this.outputVariable = outputVariable;
    }

    public void setHeaders(Expression headers) {
        this.headers = headers;
    }

    public void setMethod(Expression method) {
        this.method = method;
    }

    public Expression getOutputMappings() {
        return outputMappings;
    }

    public void setOutputMappings(Expression outputMappings) {
        this.outputMappings = outputMappings;
    }

    public void setResponseHeaderVariable(Expression responseHeaderVariable) {
        this.responseHeaderVariable = responseHeaderVariable;
    }

    public void setHttpStatusVariable(Expression httpStatusVariable) {
        this.httpStatusVariable = httpStatusVariable;
    }

    public void setErrorMessageVariable(Expression errorMessageVariable) {
        this.errorMessageVariable = errorMessageVariable;
    }

    public void setErrorCodeVariable(Expression errorCodeVariable) {
        this.errorCodeVariable = errorCodeVariable;
    }
}
