package com.tp.bpmutils.activiti.service.impl;

import com.tp.bpmutils.activiti.entity.ActHiComment;
import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.ActivitiQueryPendingCountResp;
import com.tp.bpmutils.activiti.service.IActivitiCommonService;
import com.tp.bpmutils.activiti.service.IActivitiQueryService;
import com.tp.bpmutils.activiti.service.IBpmHistoricActivityInstanceQueryService;
import com.tp.bpmutils.activiti.service.IBpmTaskQueryService;
import com.tp.bpmutils.activiti.service.repository.BpmCommentQueryRepository;
import com.tp.bpmutils.activiti.vo.ActivitiCurrentTaskVo;
import com.tp.bpmutils.activiti.vo.ActivitiHistoryTaskInstanceVo;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Comment;
import org.activiti.engine.task.Task;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 處理 Activiti Query 服務實作
 *
 * @author tp
 */
@Service
public class ActivitiQueryServiceImpl implements IActivitiQueryService {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiQueryServiceImpl.class);

    /**
     * Activiti RepositoryService
     */
    private final transient RepositoryService repositoryService;

    /**
     * Activiti TaskService
     */
    private final transient TaskService taskService;

    /**
     * Activiti RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * Activiti HistoryService
     */
    private final transient HistoryService historyService;

    /**
     * BPM ActivitiCommonService
     */
    private final transient IActivitiCommonService activitiCommonService;

    /**
     * BPM CommentQueryRepository
     */
    private final transient BpmCommentQueryRepository bpmCommentQueryRepository;

    /**
     * BPM HistoricActivityInstanceQueryService
     */
    private final transient IBpmHistoricActivityInstanceQueryService bpmHistoricActivityInstanceQueryService;

    /**
     * BPM TaskQueryService
     */
    private final transient IBpmTaskQueryService bpmTaskQueryService;

    /**
     * ActivitiQueryServiceImpl Constructor
     *
     * @param repositoryService
     * @param taskService
     * @param runtimeService
     * @param historyService
     * @param activitiCommonService
     * @param bpmCommentQueryRepository
     * @param bpmHistoricActivityInstanceQueryService
     * @param bpmTaskQueryService
     */
    public ActivitiQueryServiceImpl(RepositoryService repositoryService, TaskService taskService, RuntimeService runtimeService, HistoryService historyService, IActivitiCommonService activitiCommonService, BpmCommentQueryRepository bpmCommentQueryRepository, IBpmHistoricActivityInstanceQueryService bpmHistoricActivityInstanceQueryService, IBpmTaskQueryService bpmTaskQueryService) {
        this.repositoryService = repositoryService;
        this.taskService = taskService;
        this.runtimeService = runtimeService;
        this.historyService = historyService;
        this.activitiCommonService = activitiCommonService;
        this.bpmCommentQueryRepository = bpmCommentQueryRepository;
        this.bpmHistoricActivityInstanceQueryService = bpmHistoricActivityInstanceQueryService;
        this.bpmTaskQueryService = bpmTaskQueryService;
    }

    @Override
    public List<ActivitiTaskVo> getTodoList(ActivitiQueryPendingReq req) {

        // processDefKey與taskDefKey 必須同時存在或同時不存在
        if (StringUtils.isNotBlank(req.getProcessDefKey()) ^ StringUtils.isNotBlank(req.getTaskDefKey())) {
            throw new BPMException(BPMException.getInputParameterError(StringUtils.isBlank(req.getProcessDefKey()) ? "[processDefKey]" : "[taskDefKey]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }

        List<Task> allTaskList = new ArrayList<>();
        List<Task> taskAssigneeList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskAssigneeList = taskService.createTaskQuery().taskAssigneeIds(req.getEmpCodes()).list();
        }
        List<Task> taskCandidateGroupList = null;
        if (CollectionUtils.isNotEmpty(req.getCandidateGroups())) {
            taskCandidateGroupList = bpmTaskQueryService.taskCandidateGroupLikeIn(req.getCandidateGroups());
        }
        List<Task> taskCandidateUserList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskCandidateUserList = bpmTaskQueryService.taskCandidateUserIn(req.getEmpCodes());
        }

        if (CollectionUtils.isNotEmpty(taskAssigneeList)) {
            allTaskList.addAll(taskAssigneeList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateGroupList)) {
            allTaskList.addAll(taskCandidateGroupList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateUserList)) {
            allTaskList.addAll(taskCandidateUserList);
        }

        // 查詢指定流程任務節點
        if (CollectionUtils.isNotEmpty(allTaskList)
                && StringUtils.isNotBlank(req.getProcessDefKey())
                && StringUtils.isNotBlank(req.getTaskDefKey())) {
            allTaskList = allTaskList.stream().filter(e ->
                    e.getProcessDefinitionId().toUpperCase(Locale.ROOT).startsWith(req.getProcessDefKey().toUpperCase(Locale.ROOT))
                            && e.getTaskDefinitionKey().toUpperCase(Locale.ROOT).startsWith(req.getTaskDefKey().toUpperCase(Locale.ROOT))
            ).collect(Collectors.toList());
        }

        List<ActivitiTaskVo> taskVoList = new ArrayList<>();
        if (CollectionUtils.isEmpty(allTaskList)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("{} task list is empty...", req.getEmpCodes());
            }
        } else {

            // 彙整所有任務的taskId清單
            List<String> taskIds = new ArrayList<>();
            allTaskList.forEach(task -> {
                if (!taskIds.contains(task.getId())) {
                    taskIds.add(task.getId());
                }
            });

            Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);

            allTaskList.sort(Comparator.comparing(Task::getCreateTime));
            allTaskList.forEach(task -> {
                ActivitiTaskVo vo = new ActivitiTaskVo(task, activitiCommonService.getCandidateGroupByTaskId(candidateMap, task.getId()), activitiCommonService.getCandidateUserByTaskId(candidateMap, task.getId()));
                taskVoList.add(vo);
            });
        }
        return taskVoList;
    }

    @Override
    public List<ActivitiQueryPendingCountResp.ActivitiPendingProcess> getTodoListCounting(ActivitiQueryPendingCountReq req) {

        // processDefKey與taskDefKey 必須同時存在或同時不存在
        if (StringUtils.isNotBlank(req.getProcessDefKey()) ^ StringUtils.isNotBlank(req.getTaskDefKey())) {
            throw new BPMException(BPMException.getInputParameterError(StringUtils.isBlank(req.getProcessDefKey()) ? "[processDefKey]" : "[taskDefKey]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }

        List<ActivitiQueryPendingCountResp.ActivitiPendingProcess> todoListCounting = new ArrayList<>();

        List<Task> allTaskList = new ArrayList<>();

        List<Task> taskAssigneeList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskAssigneeList = taskService.createTaskQuery().taskAssigneeIds(req.getEmpCodes()).list();
        }
        List<Task> taskCandidateGroupList = null;
        if (CollectionUtils.isNotEmpty(req.getCandidateGroups())) {
            taskCandidateGroupList = bpmTaskQueryService.taskCandidateGroupLikeIn(req.getCandidateGroups());
        }
        List<Task> taskCandidateUserList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskCandidateUserList = bpmTaskQueryService.taskCandidateUserIn(req.getEmpCodes());
        }

        if (CollectionUtils.isNotEmpty(taskAssigneeList)) {
            allTaskList.addAll(taskAssigneeList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateGroupList)) {
            allTaskList.addAll(taskCandidateGroupList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateUserList)) {
            allTaskList.addAll(taskCandidateUserList);
        }

        // 查詢指定流程任務節點
        if (CollectionUtils.isNotEmpty(allTaskList)
                && StringUtils.isNotBlank(req.getProcessDefKey())
                && StringUtils.isNotBlank(req.getTaskDefKey())) {
            allTaskList = allTaskList.stream().filter(e ->
                    e.getProcessDefinitionId().toUpperCase(Locale.ROOT).startsWith(req.getProcessDefKey().toUpperCase(Locale.ROOT))
                            && e.getTaskDefinitionKey().toUpperCase(Locale.ROOT).startsWith(req.getTaskDefKey().toUpperCase(Locale.ROOT))
            ).collect(Collectors.toList());
        }

        if (CollectionUtils.isEmpty(allTaskList)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("{} task list is empty...", req.getEmpCodes());
            }
        } else {

            List<String> processDefinitionKeys = new ArrayList<>();
            allTaskList.forEach(task -> {
                String processDefinitionKey = StringUtils.split(task.getProcessDefinitionId(), ":")[0];
                if (!processDefinitionKeys.contains(processDefinitionKey)) {
                    processDefinitionKeys.add(processDefinitionKey);
                }
            });

            // 彙整流程定義名稱
            Map<String, String> processDefinitionNameMap = new HashMap<>();
            if (CollectionUtils.isNotEmpty(processDefinitionKeys)) {
                List<ProcessDefinition> processDefinitions = repositoryService.createProcessDefinitionQuery().processDefinitionKeys(new HashSet<String>(processDefinitionKeys)).latestVersion().list();
                if (CollectionUtils.isNotEmpty(processDefinitions)) {
                    for (ProcessDefinition processDefinition : processDefinitions) {
                        processDefinitionNameMap.put(processDefinition.getKey(), processDefinition.getName());
                    }
                }
            }

            allTaskList.forEach(task -> {

                String processDefinitionKey = StringUtils.split(task.getProcessDefinitionId(), ":")[0];
                // 流程定義名稱
                String processDefinitionName = processDefinitionNameMap.get(processDefinitionKey);

                ActivitiQueryPendingCountResp.ActivitiPendingProcess todoCounting = null;
                if (CollectionUtils.isNotEmpty(todoListCounting)) {
                    for (ActivitiQueryPendingCountResp.ActivitiPendingProcess pendingProcess : todoListCounting) {
                        if (StringUtils.equals(processDefinitionKey, pendingProcess.getProcessDefKey())) {
                            todoCounting = pendingProcess;
                        }
                    }
                }

                if (null == todoCounting) {
                    todoCounting = new ActivitiQueryPendingCountResp.ActivitiPendingProcess();
                    todoCounting.setProcessDefKey(processDefinitionKey);
                    todoCounting.setProcessName(processDefinitionName);
                    todoCounting.setTotalCount(Integer.valueOf(0));
                    todoCounting.setMainProcDefKey(processDefinitionKey);
                    todoListCounting.add(todoCounting);
                }

                ActivitiQueryPendingCountResp.ActivitiPendingTask counting = null;
                if (CollectionUtils.isNotEmpty(todoCounting.getTasks())) {
                    for (ActivitiQueryPendingCountResp.ActivitiPendingTask pendingTask : todoCounting.getTasks()) {
                        if (StringUtils.equals(task.getTaskDefinitionKey(), pendingTask.getTaskDefKey())) {
                            counting = pendingTask;
                        }
                    }
                }

                if (null == counting) {
                    counting = new ActivitiQueryPendingCountResp.ActivitiPendingTask();
                    counting.setTaskName(task.getName());
                    counting.setTaskDefKey(task.getTaskDefinitionKey());
                    counting.setCount(Integer.valueOf(0));
                    if (null == todoCounting.getTasks()) {
                        todoCounting.setTasks(new ArrayList<>());
                    }
                    todoCounting.getTasks().add(counting);
                }

                counting.setCount(counting.getCount() + 1);
                todoCounting.setTotalCount(todoCounting.getTotalCount() + 1);
            });
        }
        return todoListCounting;
    }

    @Override
    public ActivitiTaskVo getTaskInfo(ActivitiQueryTaskReq req) {
        Task task = taskService.createTaskQuery()
                .taskId(req.getTaskId())
                .singleResult();

        List<String> taskIds = new ArrayList<>();
        taskIds.add(task.getId());

        Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);

        return new ActivitiTaskVo(task, activitiCommonService.getCandidateGroupByTaskId(candidateMap, task.getId()), activitiCommonService.getCandidateUserByTaskId(candidateMap, task.getId()));
    }

    @Override
    public ActivitiMainSubVo getProcessVariables(ActivitiQueryProcessInstanceReq activitiQueryProcessInstanceReq) {
        Map<String, Object> process = runtimeService.getVariables(activitiQueryProcessInstanceReq.getProcessInstanceId());

        ActivitiMainSubVo result = new ActivitiMainSubVo();
        result.setProcess(process);
        result.setMainProcess(process);

        return result;
    }

    @Override
    public ActivitiMainSubVo getProcessVariable(ActivitiQueryProcessVariableReq activitiQueryProcessVariableReq) {
        Object process = runtimeService.getVariable(activitiQueryProcessVariableReq.getProcessInstanceId(), activitiQueryProcessVariableReq.getVariable());

        ActivitiMainSubVo result = new ActivitiMainSubVo();
        result.setProcess(process);
        result.setMainProcess(process);

        return result;
    }

    /**
     * 依processInstId清單查詢ACT_HI_TASKINST中已結束的任務資料
     *
     * @param procInstIds
     * @return
     */
    private Map<String, List<HistoricTaskInstance>> getProcInstIdActHiTaskinstListMap(List<String> procInstIds) {

        Map<String, List<HistoricTaskInstance>> procInstIdActHiTaskinstListMap = new HashMap<>();
        List<HistoricTaskInstance> historicTaskInstanceList = historyService.createHistoricTaskInstanceQuery().processInstanceIdIn(procInstIds).finished().list();
        if (CollectionUtils.isNotEmpty(historicTaskInstanceList)) {
            for (HistoricTaskInstance inst : historicTaskInstanceList) {
                List<HistoricTaskInstance> actHiActinst = MapUtils.getObject(procInstIdActHiTaskinstListMap, inst.getProcessInstanceId(), new ArrayList<>());
                actHiActinst.add(inst);
                procInstIdActHiTaskinstListMap.put(inst.getProcessInstanceId(), actHiActinst);
            }
        }
        return procInstIdActHiTaskinstListMap;
    }

    /**
     * 取得已結束的最新任務資料
     *
     * @param historicTaskInstanceList
     * @return
     */
    private HistoricTaskInstance getLastActHiTaskinst(List<HistoricTaskInstance> historicTaskInstanceList) {

        HistoricTaskInstance historicTaskInstance = null;
        if (CollectionUtils.isNotEmpty(historicTaskInstanceList)) {
            for (HistoricTaskInstance inst : historicTaskInstanceList) {
                if (null == historicTaskInstance || historicTaskInstance.getEndTime().before(inst.getEndTime())) {
                    historicTaskInstance = inst;
                }
            }
        }
        return historicTaskInstance;
    }

    /**
     * 依processInstId清單查詢ACT_HI_COMMENT資料
     *
     * @param procInstIds
     * @return
     */
    private Map<String, List<ActHiComment>> getProcInstIdActHiCommentListMap(List<String> procInstIds) {

        Map<String, List<ActHiComment>> procInstIdActHiCommentListMap = new HashMap<>();
        List<ActHiComment> actHiComments = bpmCommentQueryRepository.findByProcInstIdIn(procInstIds);
        if (CollectionUtils.isNotEmpty(actHiComments)) {
            for (ActHiComment comment : actHiComments) {
                List<ActHiComment> actHiCommentList = MapUtils.getObject(procInstIdActHiCommentListMap, comment.getProcInstId(), new ArrayList<>());
                actHiCommentList.add(comment);
                procInstIdActHiCommentListMap.put(comment.getProcInstId(), actHiCommentList);
            }
        }
        return procInstIdActHiCommentListMap;
    }

    @Override
    public List<ActivitiCurrentTaskVo> getCurrentTasks(ActivitiQueryCurrentTaskReq activitiQueryCurrentTaskReq) {

        List<ActivitiCurrentTaskVo> currentTasks = new ArrayList<>();

        if (CollectionUtils.isEmpty(activitiQueryCurrentTaskReq.getProcessInstanceIds())) {
            throw new BPMException(BPMException.getInputParameterError("[processInstanceIds]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }

        // 未結束歷史節點
        Map<String, List<HistoricActivityInstance>> processInstanceIdHistoricActivityInstanceList = bpmHistoricActivityInstanceQueryService.findMapByProcInstIdInAndEndTimeIsNull(activitiQueryCurrentTaskReq.getProcessInstanceIds());
        // 已結束任務節點
        Map<String, List<HistoricTaskInstance>> procInstIdActHiTaskinstListMap = getProcInstIdActHiTaskinstListMap(activitiQueryCurrentTaskReq.getProcessInstanceIds());
        // 備註
        Map<String, List<ActHiComment>> procInstIdActHiCommentListMap = getProcInstIdActHiCommentListMap(activitiQueryCurrentTaskReq.getProcessInstanceIds());

        for (String processInstanceId : activitiQueryCurrentTaskReq.getProcessInstanceIds()) {

            List<HistoricActivityInstance> historicActivityInstanceList = processInstanceIdHistoricActivityInstanceList.get(processInstanceId);

            List<String> taskIds = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(historicActivityInstanceList)) {
                for (HistoricActivityInstance historicActivityInstance : historicActivityInstanceList) {
                    if (StringUtils.isNotBlank(historicActivityInstance.getTaskId())) {
                        taskIds.add(historicActivityInstance.getTaskId());
                    }
                }
            }

            Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);

            for (HistoricActivityInstance historicActivityInstance : historicActivityInstanceList) {

                // 處理TaskType為Task的資料
                if (StringUtils.isNotBlank(historicActivityInstance.getTaskId())) {

                    HistoricTaskInstance actHiTaskinst = getLastActHiTaskinst(procInstIdActHiTaskinstListMap.get(processInstanceId));

                    String taskId = null;
                    if (null != actHiTaskinst) {
                        taskId = actHiTaskinst.getId();
                    }

                    List<ActHiComment> commentList = new ArrayList<>();
                    if (StringUtils.isNotBlank(taskId)) {
                        List<ActHiComment> tmpCommentList = MapUtils.getObject(procInstIdActHiCommentListMap, processInstanceId, new ArrayList<>());
                        if (CollectionUtils.isNotEmpty(tmpCommentList)) {
                            for (ActHiComment comment : tmpCommentList) {
                                if (StringUtils.equals(comment.getTaskId(), taskId)) {
                                    commentList.add(comment);
                                }
                            }
                        }
                    }
                    taskService.getProcessInstanceComments(processInstanceId);
                    if (CollectionUtils.isNotEmpty(commentList)) {
                        if (LOGGER.isInfoEnabled()) {
                            LOGGER.info("Process Instance:{}, Comment List size :{}", processInstanceId, commentList.size());
                        }
                        commentList.sort(Comparator.comparing(ActHiComment::getTime));
                        ActHiComment comment = commentList.get(commentList.size() - 1);
                        HistoricTaskInstance his = historyService.createHistoricTaskInstanceQuery()
                                .taskId(comment.getTaskId())
                                .singleResult();

                        ActivitiCurrentTaskVo vo = new ActivitiCurrentTaskVo(
                                historicActivityInstance,
                                activitiCommonService.getCandidateGroupByTaskId(candidateMap, historicActivityInstance.getTaskId()),
                                activitiCommonService.getCandidateUserByTaskId(candidateMap, historicActivityInstance.getTaskId()),
                                his.getName(),
                                comment);
                        currentTasks.add(vo);

                    } else {

                        ActivitiCurrentTaskVo vo = new ActivitiCurrentTaskVo(
                                historicActivityInstance,
                                activitiCommonService.getCandidateGroupByTaskId(candidateMap, historicActivityInstance.getTaskId()),
                                activitiCommonService.getCandidateUserByTaskId(candidateMap, historicActivityInstance.getTaskId()),
                                null, null);
                        currentTasks.add(vo);
                    }
                }
            }
        }

        return currentTasks;
    }

    @Override
    public List<ActivitiHistoryTaskInstanceVo> queryProcessInstanceHis(ActivitiQueryProcessInstanceReq req) {
        List<ActivitiHistoryTaskInstanceVo> taskVoList = new ArrayList<>();
        List<Comment> commentList = taskService.getProcessInstanceComments(req.getProcessInstanceId());
        if (CollectionUtils.isNotEmpty(commentList)) {
            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Process Instance:{}, Comment List size :{}", req.getProcessInstanceId(), commentList.size());
            }
            commentList.sort(Comparator.comparing(Comment::getTime));

            List<HistoricActivityInstance> hisList = historyService.createHistoricActivityInstanceQuery().processInstanceId(req.getProcessInstanceId()).list();
            Map<String, HistoricActivityInstance> hisMap = new HashMap<>();
            if (CollectionUtils.isNotEmpty(hisList)) {
                for (HistoricActivityInstance his : hisList) {
                    if (StringUtils.isNotBlank(his.getTaskId())) {
                        hisMap.put(his.getTaskId(), his);
                    }
                }
            }

            commentList.forEach(comment -> {
                HistoricActivityInstance his = hisMap.get(comment.getTaskId());
                if (LOGGER.isDebugEnabled()) {
                    LOGGER.debug("審核人： " + comment.getUserId() + " ,審核內容：" + comment.getFullMessage() + " ,審核時間:" + comment.getTime().toString());
                }
                ActivitiHistoryTaskInstanceVo vo = new ActivitiHistoryTaskInstanceVo(comment, his);
                taskVoList.add(vo);
            });
        }
        return taskVoList;
    }
}
