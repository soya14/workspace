package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢流程定義任務請求
 *
 * @author tp
 */
@Schema(description = "查詢流程定義任務請求")
public class ActivitiProcessActiveTasksReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3889303191462701964L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"processDefKey"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程定義代碼
     */
    @Schema(description = "流程定義代碼：Demo")
    private String processDefKey;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getProcessDefKey() {
        return processDefKey;
    }

    public void setProcessDefKey(String processDefKey) {
        this.processDefKey = processDefKey;
    }
}
