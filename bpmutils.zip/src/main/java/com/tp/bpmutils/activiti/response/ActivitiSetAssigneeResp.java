package com.tp.bpmutils.activiti.response;

import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 改派處理者回覆
 *
 * @author tp
 */
@Schema(description = "改派處理者回覆")
public class ActivitiSetAssigneeResp extends BPMApiResponse {

    /**
     * 結果
     */
    @Schema(description = "結果", example = "true")
    private Boolean data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiSetAssigneeResp success(Boolean data) {
        ActivitiSetAssigneeResp apiSuccess = new ActivitiSetAssigneeResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }
}
