package com.tp.bpmutils.activiti.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;

/**
 * 子母流程關聯主檔 entity
 */
@Entity
@Table(name="BPM_PROCINST_INFO")
public class BpmProcinstInfo implements Serializable {

	private static final long serialVersionUID = -2574749653871934413L;

	/**
	 * PROC_INST_ID: 程實例代號
	 */
	@Id
	@Column(name="PROC_INST_ID")
    private String procInstId;

	/**
	 * PROC_DEF_ID: 程定義編號
	 */
	@Column(name="PROC_DEF_ID")
	private String procDefId;

	/**
	 * MAIN_PROC_INST_ID: 主流程實例代號
	 */
	@Column(name="MAIN_PROC_INST_ID")
    private String mainProcInstId;

	/**
	 * MAIN_PROC_DEF_ID: 主流程定義編號
	 */
	@Column(name="MAIN_PROC_DEF_ID")
    private String mainProcDefId;

	/**
	 * SOURCE_PROC_INST_ID: 上一階流程實例代號
	 */
	@Column(name="SOURCE_PROC_INST_ID")
	private String sourceProcInstId;

	/**
	 * SOURCE_PROC_DEF_ID: 上一階流程定義編號
	 */
	@Column(name="SOURCE_PROC_DEF_ID")
	private String sourceProcDefId;

	/**
	 * 啟動時間
	 */
	@Column(name="START_TIME")
	private Date startTime;

	/**
	 * 結束時間
	 */
	@Column(name="END_TIME")
	private Date endTime;

	/**
	 * BpmProcinstInfo's Contructor
	 */
	public BpmProcinstInfo() {
		// This constructor is intentionally empty. Nothing special is needed here.
	}

	/**
	 * BpmProcinstInfo's Contructor 2
	 *
	 * @param procInstId
	 * @param procDefId
	 * @param mainProcInstId
	 * @param mainProcDefId
	 * @param sourceProcInstId
	 * @param sourceProcDefId
	 * @param startTime
	 * @param endTime
	 */
	public BpmProcinstInfo(String procInstId, String procDefId, String mainProcInstId, String mainProcDefId, String sourceProcInstId, String sourceProcDefId, Date startTime, Date endTime) {
		this.procInstId = procInstId;
		this.procDefId = procDefId;
		this.mainProcInstId = mainProcInstId;
		this.mainProcDefId = mainProcDefId;
		this.sourceProcInstId = sourceProcInstId;
		this.sourceProcDefId = sourceProcDefId;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public String getProcInstId() {
		return procInstId;
	}

	public void setProcInstId(String procInstId) {
		this.procInstId = procInstId;
	}

	public String getProcDefId() {
		return procDefId;
	}

	public void setProcDefId(String procDefId) {
		this.procDefId = procDefId;
	}

	public String getMainProcInstId() {
		return mainProcInstId;
	}

	public void setMainProcInstId(String mainProcInstId) {
		this.mainProcInstId = mainProcInstId;
	}

	public String getMainProcDefId() {
		return mainProcDefId;
	}

	public void setMainProcDefId(String mainProcDefId) {
		this.mainProcDefId = mainProcDefId;
	}

	public String getSourceProcInstId() {
		return sourceProcInstId;
	}

	public void setSourceProcInstId(String sourceProcInstId) {
		this.sourceProcInstId = sourceProcInstId;
	}

	public String getSourceProcDefId() {
		return sourceProcDefId;
	}

	public void setSourceProcDefId(String sourceProcDefId) {
		this.sourceProcDefId = sourceProcDefId;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
}