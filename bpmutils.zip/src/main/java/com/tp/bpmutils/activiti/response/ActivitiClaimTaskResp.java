package com.tp.bpmutils.activiti.response;

import java.util.List;

import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 領取案件回覆
 *
 * @author tp
 */
@Schema(description = "領取案件回覆")
public class ActivitiClaimTaskResp extends BPMApiResponse {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private List<ActivitiTaskVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiClaimTaskResp success(List<ActivitiTaskVo> data) {
        ActivitiClaimTaskResp apiSuccess = new ActivitiClaimTaskResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public List<ActivitiTaskVo> getData() {
        return data;
    }

    public void setData(List<ActivitiTaskVo> data) {
        this.data = data;
    }
}
