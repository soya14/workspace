package com.tp.bpmutils.activiti.response;

import java.util.List;

import com.tp.bpmutils.activiti.vo.ActivitiHistoryTaskInstanceVo;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢案件回覆
 *
 * @author tp
 */
@Schema(description = "查詢案件回覆")
public class ActivitiQueryProcessInstanceResp extends BPMApiResponse {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private List<ActivitiHistoryTaskInstanceVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryProcessInstanceResp success(List<ActivitiHistoryTaskInstanceVo> data) {
        ActivitiQueryProcessInstanceResp apiSuccess = new ActivitiQueryProcessInstanceResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public List<ActivitiHistoryTaskInstanceVo> getData() {
        return data;
    }

    public void setData(List<ActivitiHistoryTaskInstanceVo> data) {
        this.data = data;
    }
}
