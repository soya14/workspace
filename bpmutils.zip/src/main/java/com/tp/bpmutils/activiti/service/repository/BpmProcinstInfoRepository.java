package com.tp.bpmutils.activiti.service.repository;

import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 子母流程關聯主檔
 *
 * @author tp
 */
@Repository
public interface BpmProcinstInfoRepository extends CrudRepository<BpmProcinstInfo, String>, JpaSpecificationExecutor<BpmProcinstInfo> {

    /**
     * 依 procInstId 查詢 BpmProcinstInfo
     *
     * @param procInstId
     * @return
     */
    BpmProcinstInfo findByProcInstId(String procInstId);

    /**
     * 依 mainProcInstId 查詢 BpmProcinstInfo 清單
     *
     * @param mainProcInstId
     * @return
     */
    List<BpmProcinstInfo> findByMainProcInstId(String mainProcInstId);

    /**
     * 依 sourceProcInstId 查詢 BpmProcinstInfo 清單
     *
     * @param sourceProcInstId
     * @return
     */
    List<BpmProcinstInfo> findBySourceProcInstId(String sourceProcInstId);

    /**
     * 依 procInstId 清單查詢 BpmProcinstInfo 清單
     *
     * @param procInstIds
     * @return
     */
    List<BpmProcinstInfo> findByProcInstIdIn(List<String> procInstIds);
}
