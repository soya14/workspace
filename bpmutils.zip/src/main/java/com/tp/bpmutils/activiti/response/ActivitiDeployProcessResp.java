package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 流程資源部署回覆
 *
 * @author tp
 */
@Schema(description = "流程資源部署回覆")
public class ActivitiDeployProcessResp extends BPMApiResponse {

    /**
     * 部署結果
     */
    @Schema(description = "部署結果")
    private ActivitiDeployProcessRespData data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiDeployProcessResp success(ActivitiDeployProcessRespData data) {
        ActivitiDeployProcessResp apiSuccess = new ActivitiDeployProcessResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public ActivitiDeployProcessRespData getData() {
        return data;
    }

    public void setData(ActivitiDeployProcessRespData data) {
        this.data = data;
    }

    /**
     * 部署結果回覆
     */
    @JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
    @Schema(description = "部署結果回覆")
    public static class ActivitiDeployProcessRespData {

        /**
         * 流程資源部署結果
         */
        @Schema(description = "流程資源部署結果(0: 成功, 1: 失敗) ")
        private Integer rtnCode;

        /**
         * 結果訊息
         */
        @Schema(description = "結果訊息(rtnCode=0: Deploy success., rtnCode=1: Process deploy fail: [MyProcess1.bpmn, MyProcess2.bpmn]")
        private String msg;

        /**
         * ActivitiDeployProcessRespData 1
         */
        public ActivitiDeployProcessRespData() {
            // NO BODY
        }

        /**
         * ActivitiDeployProcessRespData 2
         *
         * @param rtnCode
         * @param msg
         */
        public ActivitiDeployProcessRespData(Integer rtnCode, String msg) {
            this.rtnCode = rtnCode;
            this.msg = msg;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public Integer getRtnCode() {
            return rtnCode;
        }

        public void setRtnCode(Integer rtnCode) {
            this.rtnCode = rtnCode;
        }

    }
}
