package com.tp.bpmutils.activiti.delegate;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * callActivity 子流程中取得父流程中變數
 *
 * @author tp
 */
@Service("callActivityGetSuperVariablesDelegate")
public class CallActivityGetSourceVariablesDelegate implements ExecutionListener {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CallActivityGetSourceVariablesDelegate.class);

    private static final long serialVersionUID = -1062639439583143194L;

    /**
     * Activiti's RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * CallActivityGetSuperVariablesDelegate's contructor
     *
     * @param runtimeService
     */
    public CallActivityGetSourceVariablesDelegate(RuntimeService runtimeService) {
        this.runtimeService = runtimeService;
    }

    @Override
    public void notify(DelegateExecution execution) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Variables: {}", execution.getVariables());
        }
        String rootProcessInstanceId = execution.getRootProcessInstanceId();
        Map<String, Object> variables = runtimeService.getVariables(rootProcessInstanceId);
        for(Map.Entry<String, Object> entry : variables.entrySet()) {
            execution.setVariable(entry.getKey(), entry.getValue());
        }
    }
}
