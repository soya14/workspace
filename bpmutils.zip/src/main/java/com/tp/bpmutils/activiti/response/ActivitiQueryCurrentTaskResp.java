package com.tp.bpmutils.activiti.response;

import java.util.List;

import com.tp.bpmutils.activiti.vo.ActivitiCurrentTaskVo;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 目前停留在那些節點(含前一關)回覆
 *
 * @author tp
 */
@Schema(description = "目前停留在那些節點(含前一關)回覆")
public class ActivitiQueryCurrentTaskResp extends BPMApiResponse {

    /**
     * 節點資訊
     */
    @Schema(description = "節點資訊")
    private List<ActivitiCurrentTaskVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryCurrentTaskResp success(List<ActivitiCurrentTaskVo> data) {
        ActivitiQueryCurrentTaskResp apiSuccess = new ActivitiQueryCurrentTaskResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public List<ActivitiCurrentTaskVo> getData() {
        return data;
    }

    public void setData(List<ActivitiCurrentTaskVo> data) {
        this.data = data;
    }
}
