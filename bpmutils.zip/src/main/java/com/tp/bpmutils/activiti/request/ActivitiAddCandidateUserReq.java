package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 新增處理者請求
 *
 * @author tp
 */
@Schema(description = "新增處理者請求")
public class ActivitiAddCandidateUserReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = -3506997692399543817L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"taskId", "user"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 任務編號
     */
    @Schema(description = "任務編號：5", required = true)
    private String taskId;

    /**
     * 增加處理者
     */
    @Schema(description = "要增加哪位處理者：1", required = true)
    private String user;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
