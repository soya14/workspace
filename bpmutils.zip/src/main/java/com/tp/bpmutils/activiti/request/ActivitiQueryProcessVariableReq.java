package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

/**
 * 取得流程變數請求
 *
 * @author tp
 */
@Schema(description = "取得流程變數請求")
public class ActivitiQueryProcessVariableReq extends ActivitiQueryProcessInstanceReq implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 2589738673270022915L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"processInstanceId", "variable"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程變數名稱
     */
    @Schema(description = "流程變數名稱：isSave", required = true)
    private String variable;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getVariable() {
        return variable;
    }

    public void setVariable(String variable) {
        this.variable = variable;
    }
}
