package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

import java.util.Map;

/**
 * 啟動流程請求
 *
 * @author tp
 */
@Schema(description = "啟動流程請求")
public class ActivitiStartProcessReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = 8368371351712055946L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"empCode", "processDefinitionKey"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程圖定義 Id
     */
    @Schema(description = "流程圖定義 Id：PendingItem", required = true)
    private String processDefinitionKey;
    /**
     * 員工編號
     */
    @Schema(description = "員工編號：1", required = true)
    private String empCode;

    /**
     * 流程所需參數
     */
    @Schema(description = "流程所需參數", implementation = Map.class)
    private Map paramMap;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getProcessDefinitionKey() {
        return processDefinitionKey;
    }

    public void setProcessDefinitionKey(String processDefinitionKey) {
        this.processDefinitionKey = processDefinitionKey;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public Map getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map paramMap) {
        this.paramMap = paramMap;
    }
}
