package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 流程部署請求
 *
 * @author tp
 */
@Schema(description = "流程部署請求")
public class ActivitiDeployProcessReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = -9127202330511785148L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"deployFolder"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程資源路徑
     */
    @Schema(description = "流程資源路徑：/tmp", required = true)
    private String deployFolder;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getDeployFolder() {
        return deployFolder;
    }

    public void setDeployFolder(String deployFolder) {
        this.deployFolder = deployFolder;
    }
}
