package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢任務請求
 *
 * @author tp
 */
@Schema(description = "查詢任務請求")
public class ActivitiQueryTaskReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = 3924910250674029548L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"taskId"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 任務編號
     */
    @Schema(description = "任務編號：5", required = true)
    private String taskId;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }
}
