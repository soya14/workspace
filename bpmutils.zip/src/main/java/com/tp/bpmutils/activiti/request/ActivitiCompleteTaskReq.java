package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;
import java.util.Map;

/**
 * 審核節點請求
 *
 * @author tp
 */
@Schema(description = "審核節點請求")
public class ActivitiCompleteTaskReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1555153311932316514L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"empCode", "taskId"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 任務編號
     */
    @Schema(description = "任務編號：5", required = true)
    private String taskId;

    /**
     * 員工編號
     */
    @Schema(description = "員工編號：1", required = true)
    private String empCode;

    /**
     * 角色
     */
    @ArraySchema(arraySchema = @Schema(description = "角色：[DEP_ADMIN, AUDIT_ADMIN]", required = true))
    private List<String> candidateGroups;

    /**
     * 備註
     */
    @Schema(description = "備註：允許通過")
    private String comment;

    /**
     * 流程所需參數
     */
    @Schema(description = "流程所需參數", implementation = Map.class)
    private Map paramMap;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public List<String> getCandidateGroups() {
        return candidateGroups;
    }

    public void setCandidateGroups(List<String> candidateGroups) {
        this.candidateGroups = candidateGroups;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Map getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map paramMap) {
        this.paramMap = paramMap;
    }
}
