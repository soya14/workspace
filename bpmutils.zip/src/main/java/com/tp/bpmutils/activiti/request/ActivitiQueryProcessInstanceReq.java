package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢案件請求
 *
 * @author tp
 */
@Schema(description = "查詢案件請求")
public class ActivitiQueryProcessInstanceReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = -4423572040392907728L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"processInstanceId"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程實例代號
     */
    @Schema(description = "流程實例代號：5", required = true)
    private String processInstanceId;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }
}
