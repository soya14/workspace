package com.tp.bpmutils.activiti.controller;

import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.*;
import com.tp.bpmutils.activiti.service.IActivitiQueryService;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.controller.BaseController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/**
 * BPM Query Controller
 *
 * @author tp
 */
@RestController
@RequestMapping(value = "activiti")
@Tag(name = "Activiti Query 工具接口")
public class ActivitiQueryController extends BaseController {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiQueryController.class);

    /**
     * BPM Activiti Process Service
     */
    private final transient IActivitiQueryService activitiQueryService;

    /**
     * ActivitiQueryController Constructor
     *
     * @param activitiQueryService
     */
    public ActivitiQueryController(IActivitiQueryService activitiQueryService) {
        super();
        this.activitiQueryService = activitiQueryService;
    }

    /**
     * 查詢待辦清單 ( 查詢角色待審案件清單 )
     *
     * @param req empCode：員工編碼 ; candidateGroups：該員工擁有的角色(公司別 + 權限串接)
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGTDLQ001")
    @Operation(summary = "查詢待辦清單", description = "查詢待辦清單")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "查詢成功")
    public ActivitiQueryPendingResp getTodoList(@Parameter(required = true, name = "查詢待辦清單請求內容") @RequestBody ActivitiQueryPendingReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Query EmpCodes:{} Review TODO List", req.getEmpCodes());
        }
        checkInput(req);
        return ActivitiQueryPendingResp.success(activitiQueryService.getTodoList(req));
    }

    /**
     * 查詢待辦數量 ( 查詢角色待審案件數量 )
     *
     * @param req empCode：員工編碼 ; candidateGroups：該員工擁有的角色(公司別 + 權限串接)
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGTDCQ001")
    @Operation(summary = "查詢待辦數量", description = "查詢待辦數量")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "查詢成功")
    public ActivitiQueryPendingCountResp getTodoListCounting(@Parameter(required = true, name = "查詢待辦數量請求內容") @RequestBody ActivitiQueryPendingCountReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Query EmpCodes:{} Review TODO List", req.getEmpCodes());
        }
        checkInput(req);
        return ActivitiQueryPendingCountResp.success(activitiQueryService.getTodoListCounting(req));
    }

    /**
     * 查詢案件資訊
     *
     * @param req
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGINFQ001")
    @Operation(summary = "查詢案件資訊", description = "查詢案件資訊")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "查詢成功")
    public ActivitiQueryTaskResp getTaskInfoByID(@Parameter(required = true, name = "查詢案件資訊請求內容") @RequestBody ActivitiQueryTaskReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Query Current task :{}", req.getTaskId());
        }
        checkInput(req);
        ActivitiTaskVo taskVo = activitiQueryService.getTaskInfo(req);
        return ActivitiQueryTaskResp.success(taskVo);
    }

    /**
     * 取得流程變數
     *
     * @param req processInstanceId：流程實例ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGPCVQ001")
    @Operation(summary = "取得流程變數", description = "取得流程全部變數")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "取得流程變數成功")
    public ActivitiProcessVariablesResp getProcessVariables(@Parameter(required = true, name = "取得流程變數請求內容") @RequestBody ActivitiQueryProcessInstanceReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Get Process Variables..., Process Instance ID :{}", req.getProcessInstanceId());
        }
        checkInput(req);
        return ActivitiProcessVariablesResp.success(activitiQueryService.getProcessVariables(req));
    }

    /**
     * 取得流程變數
     *
     * @param req processInstanceId：流程實例ID ; variable：流程變數名稱
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGPCVQ002")
    @Operation(summary = "取得流程變數", description = "取得流程指定變數內容")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "取得流程變數成功")
    public ActivitiProcessVariableResp getProcessVariable(@Parameter(required = true, name = "取得流程變數請求內容") @RequestBody ActivitiQueryProcessVariableReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Get Process Variable..., Process Instance ID :{}, Variable: {}", req.getProcessInstanceId(), req.getVariable());
        }
        checkInput(req);
        return ActivitiProcessVariableResp.success(activitiQueryService.getProcessVariable(req));
    }

    /**
     * 目前停留在那些節點(含前一關)
     *
     * @param req processInstanceIds：流程實例ID清單
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGTSKQ001")
    @Operation(summary = "目前停留在那些節點(含前一關)", description = "查詢流程目前停留節點(含前一關)資訊")
    @ApiResponse(responseCode = "200", description = "查詢成功")
    @ResponseStatus(HttpStatus.OK)
    public ActivitiQueryCurrentTaskResp getCurrentTasks(@Parameter(required = true, name = "查詢流程目前停留節點(含前一關)資訊") @RequestBody ActivitiQueryCurrentTaskReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Get Current Tasks..., Process Instance IDs: {}", req.getProcessInstanceIds());
        }
        checkInput(req);
        return ActivitiQueryCurrentTaskResp.success(activitiQueryService.getCurrentTasks(req));
    }

    /**
     * 查詢案件歷程
     *
     * @param req processInstanceId：流程案例ID
     * @return ActivitiHistoryTaskInstanceVo list
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGHISQ001")
    @Operation(summary = "查詢案件歷程", description = "查詢案件歷程內容")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "查詢成功")
    public ActivitiQueryProcessInstanceResp getProcessInstanceComments(@Parameter(required = true, name = "查詢案件歷程請求內容") @RequestBody ActivitiQueryProcessInstanceReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Query Process Instance History..., Process Instance:{}", req.getProcessInstanceId());
        }
        checkInput(req);
        return ActivitiQueryProcessInstanceResp.success(activitiQueryService.queryProcessInstanceHis(req));
    }
}
