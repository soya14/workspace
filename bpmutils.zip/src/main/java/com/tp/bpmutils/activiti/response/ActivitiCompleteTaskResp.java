package com.tp.bpmutils.activiti.response;

import java.util.List;

import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 審核節點回覆
 *
 * @author tp
 */
@Schema(description = "審核節點回覆")
public class ActivitiCompleteTaskResp extends BPMApiResponse {

    /**
     * 任務資訊
     */
    @Schema(description = "任務資訊")
    private List<ActivitiTaskVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiCompleteTaskResp success(List<ActivitiTaskVo> data) {
        ActivitiCompleteTaskResp apiSuccess = new ActivitiCompleteTaskResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public List<ActivitiTaskVo> getData() {
        return data;
    }

    public void setData(List<ActivitiTaskVo> data) {
        this.data = data;
    }
}
