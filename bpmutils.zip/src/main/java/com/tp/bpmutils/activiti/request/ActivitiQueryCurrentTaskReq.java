package com.tp.bpmutils.activiti.request;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 目前停留在那些節點(含前一關)請求
 *
 * @author tp
 */
@Schema(description = "目前停留在那些節點(含前一關)請求")
public class ActivitiQueryCurrentTaskReq extends ActivitiReqData {

    /**
	 * 
	 */
	private static final long serialVersionUID = -7666705262556179160L;

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"processInstanceIds"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程實例代號
     */
    @ArraySchema(arraySchema = @Schema(description = "流程實例代號：[5, 15 ...]", required = true))
    private List<String> processInstanceIds;

    @Override
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    @Override
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public List<String> getProcessInstanceIds() {
        return processInstanceIds;
    }

    public void setProcessInstanceIds(List<String> processInstanceIds) {
        this.processInstanceIds = processInstanceIds;
    }
}
