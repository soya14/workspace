package com.tp.bpmutils.activiti.response;

import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 新增處理群組回覆
 *
 * @author tp
 */
@Schema(description = "新增處理群組回覆")
public class ActivitiAddCandidateGroupResp extends BPMApiResponse {

    /**
     * 結果
     */
    @Schema(description = "結果", example = "true")
    private Boolean data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiAddCandidateGroupResp success(Boolean data) {
        ActivitiAddCandidateGroupResp apiSuccess = new ActivitiAddCandidateGroupResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }
}
