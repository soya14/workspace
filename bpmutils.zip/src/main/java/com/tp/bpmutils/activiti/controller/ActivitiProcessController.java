package com.tp.bpmutils.activiti.controller;

import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.*;
import com.tp.bpmutils.activiti.service.IActivitiProcessService;
import com.tp.bpmutils.common.controller.BaseController;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

/**
 * BPM Process Controller
 *
 * @author tp
 */
@RestController
@RequestMapping(value = "activiti")
@Tag(name = "Activiti Process 工具接口")
public class ActivitiProcessController extends BaseController {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiProcessController.class);

    /**
     * BPM Activiti Process Service
     */
    private final transient IActivitiProcessService activitiProcessService;

    /**
     * ActivitiProcessController Constructor
     *
     * @param activitiProcessService
     */
    public ActivitiProcessController(IActivitiProcessService activitiProcessService) {
        super();
        this.activitiProcessService = activitiProcessService;
    }

    /**
     * 啟動流程
     *
     * @param req processDefinitionId：流程圖ID ; paramMap：啟動流程所需帶入的參數
     * @return processInstanceId：流程案例ID
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWSTPCT001")
    @Operation(summary = "啟動流程", description = "啟動流程")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "啟動成功")
    public ActivitiStartProcessResp startProcess(@Parameter(required = true, description = "啟動流程請求內容") @RequestBody ActivitiStartProcessReq req){
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Start process..., Process Definition Key:{}", req.getProcessDefinitionKey());
        }
        checkInput(req);
        return ActivitiStartProcessResp.success(activitiProcessService.startProcess(req));
    }

    /**
     * 領取案件
     *
     * @param req taskId：節點ID ; empCode：領取人
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWCLMTT001")
    @Operation(summary = "領取案件", description = "領取案件")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "領取案件成功")
    public ActivitiClaimTaskResp claimTask(@Parameter(required = true, name = "領取案件請求內容") @RequestBody ActivitiClaimTaskReq req){
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Claim Task..., Task ID :{}, Emp Code: {}", req.getTaskId(), req.getEmpCode());
        }
        checkInput(req);
        return ActivitiClaimTaskResp.success(activitiProcessService.claimTask(req));
    }

    /**
     * 審核節點
     *
     * @param req taskId：節點ID ; paramMap：審核節點所需帶入的參數
     * @return none
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWCPTST001")
    @Operation(summary = "審核節點", description = "審核節點")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "審核成功")
    public ActivitiCompleteTaskResp completeTask(@Parameter(required = true, name = "審核節點請求內容 ") @RequestBody ActivitiCompleteTaskReq req){
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Complete Task..., Task ID :{}", req.getTaskId());
        }
        checkInput(req);
        return ActivitiCompleteTaskResp.success(activitiProcessService.completeTask(req));
    }

    /**
     * 強制終止流程
     *
     * @param req processInstanceId：流程實例ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWTERMT001")
    @Operation(summary = "強制終止流程", description = "強制終止流程")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "強制終止流程成功")
    public ActivitiTerminateProcessResp terminateProcess(@Parameter(required = true, name = "強制終止流程請求內容") @RequestBody ActivitiTerminateProcessReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Terminate Process..., Process Instance ID :{}", req.getProcessInstanceId());
        }
        checkInput(req);
        return ActivitiTerminateProcessResp.success(activitiProcessService.terminateProcess(req));
    }

    /**
     * 新增處理群組
     *
     * @param req taskId：流程任務ID ; group：會簽人員 group ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWADROT001")
    @Operation(summary = "新增處理群組", description = "新增處理群組(CandidateGroup)")
    @ApiResponse(responseCode = "201", description = "新增處理群組成功")
    @ResponseStatus(HttpStatus.CREATED)
    public ActivitiAddCandidateGroupResp addCandidateGroup(@Parameter(required = true, name = "增加會簽人員請求內容") @RequestBody ActivitiAddCandidateGroupReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Add Candidate Group..., Task ID :{}, Group: {}", req.getTaskId(), req.getGroup());
        }
        checkInput(req);
        return ActivitiAddCandidateGroupResp.success(activitiProcessService.addCandidateGroup(req));
    }

    /**
     * 移除原本的群組
     *
     * @param req taskId：流程任務ID ; candidateGroup：群組 group ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWDLROT001")
    @Operation(summary = "移除原本的群組", description = "移除原本的群組(CandidateGroup)")
    @ApiResponse(responseCode = "200", description = "移除原本的群組成功")
    @ResponseStatus(HttpStatus.CREATED)
    public ActivitiDeleteCandidateGroupResp deleteCandidateGroup(@Parameter(required = true, name = "移除原本的群組請求內容") @RequestBody ActivitiDeleteCandidateGroupReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Delete Candidate Group..., Task ID :{}, CandidateGroup: {}", req.getTaskId(), req.getCandidateGroup());
        }
        checkInput(req);
        return ActivitiDeleteCandidateGroupResp.success(activitiProcessService.deleteCandidateGroup(req));
    }

    /**
     * 新增處理者
     *
     * @param req taskId：流程任務ID ; user：處理者 user ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWADUST001")
    @Operation(summary = "新增處理者", description = "新增處理者(CandidateUser)")
    @ApiResponse(responseCode = "201", description = "新增處理者成功")
    @ResponseStatus(HttpStatus.CREATED)
    public ActivitiAddCandidateUserResp addCandidateUser(@Parameter(required = true, name = "新增處理者請求內容") @RequestBody ActivitiAddCandidateUserReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Add Candidate Group..., Task ID :{}, User: {}", req.getTaskId(), req.getUser());
        }
        checkInput(req);
        return ActivitiAddCandidateUserResp.success(activitiProcessService.addCandidateUser(req));
    }

    /**
     * 移除原本的處理者
     *
     * @param req taskId：流程任務ID ; candidateUser：處理者 user ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWDLUST001")
    @Operation(summary = "移除原本的處理者", description = "移除原本的處理者(CandidateUser)")
    @ApiResponse(responseCode = "200", description = "移除原本的處理者成功")
    @ResponseStatus(HttpStatus.CREATED)
    public ActivitiDeleteCandidateUserResp deleteCandidateUser(@Parameter(required = true, name = "移除原本的處理者請求內容") @RequestBody ActivitiDeleteCandidateUserReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Delete Candidate User..., Task ID :{}, CandidateUser: {}", req.getTaskId(), req.getCandidateUser());
        }
        checkInput(req);
        return ActivitiDeleteCandidateUserResp.success(activitiProcessService.deleteCandidateUser(req));
    }

    /**
     * 改派處理者
     *
     * @param req taskId：流程任務ID ; assignee：處理者 user ID
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWREAST001")
    @Operation(summary = "改派處理者", description = "改派處理(Assignee)者")
    @ApiResponse(responseCode = "200", description = "改派成功")
    @ResponseStatus(HttpStatus.CREATED)
    public ActivitiSetAssigneeResp setAssignee(@Parameter(required = true, name = "改派處理者請求內容") @RequestBody ActivitiSetAssigneeReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Set Assignee..., Task ID :{}, Assignee: {}", req.getTaskId(), req.getAssignee());
        }
        checkInput(req);
        return ActivitiSetAssigneeResp.success(activitiProcessService.setAssignee(req));
    }

    /**
     * 增加任務備註
     *
     * @param req taskId：任務ID ;
     *            comment：備註 ;
     *            empCode：員工編碼
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWADCMT001")
    @Operation(summary = "增加任務備註", description = "增加任務備註")
    @ResponseStatus(HttpStatus.CREATED)
    @ApiResponse(responseCode = "201", description = "增加成功")
    public ActivitiAddCommentResp addComment(@Parameter(required = true, name = "增加任務備註內容") @RequestBody ActivitiAddCommentReq req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Add Comment..., Task ID: {}, Comment: {}, Emp Code: {}", req.getTaskId(), req.getComment(), req.getEmpCode());
        }
        checkInput(req);
        return ActivitiAddCommentResp.success(activitiProcessService.addComment(req));
    }
}
