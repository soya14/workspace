package com.tp.bpmutils.activiti.service.repository;

import com.tp.bpmutils.activiti.entity.ActRuIdentitylink;
import org.springframework.data.repository.Repository;

import java.util.List;

/**
 * BPM runtime IdentityLink Repository
 */
public interface BpmRuIdentityLinkRepository extends Repository<ActRuIdentitylink, String> {

    /**
     * 依 taskId 清單查詢 ActRuIdentitylink 清單
     *
     * @param taskIds
     * @return
     */
    List<ActRuIdentitylink> findByTaskIdIn(List<String> taskIds);
}
