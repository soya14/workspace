package com.tp.bpmutils.activiti.response;

import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 增加任務備註回覆
 *
 * @author tp
 */
@Schema(description = "增加任務備註回覆")
public class ActivitiAddCommentResp extends BPMApiResponse {

    /**
     * 結果
     */
    @Schema(description = "結果", example = "true")
    private Boolean data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiAddCommentResp success(Boolean data) {
        ActivitiAddCommentResp apiSuccess = new ActivitiAddCommentResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }
}
