package com.tp.bpmutils.activiti.vo;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * Common Act Vo
 */
public class ActVo extends ActivitiBaseVo {

	/**
	 *
	 */
	private static final long serialVersionUID = -960892677909910717L;

	/**
	 * Act Response
	 */
	private ActResData actResData;

	public ActResData getActResData() {
		return actResData;
	}

	public void setActResData(ActResData actResData) {
		this.actResData = actResData;
	}

	/**
	 * 流程資訊回覆
	 */
	@Schema(description = "流程資訊回覆")
	public static class ActResData {

		/**
		 * 流程實例代號
		 */
		@Schema(description = "流程實例代號")
		private String processInstanceId;

		/**
		 * 任務編號
		 */
		@Schema(description = "任務編號")
		private String taskId;

		/**
		 * 外置表單代碼
		 */
		@Schema(description = "外置表單代碼")
		private String taskType;

		/**
		 * 任務名稱
		 */
		@Schema(description = "任務名稱")
		private String taskName;

		/**
		 * 流程圖(SVG) Base64 位元字串
		 */
		@Schema(description = "流程圖(SVG) Base64 位元字串")
		private String hisImgString;

		/**
		 * 所屬單位(多個)
		 */
		@ArraySchema(arraySchema = @Schema(description = "所屬單位(多個)"))
		private List<Integer> empDepList;

		/**
		 * 權責角色
		 */
		@Schema(description = "權責角色")
		private String authGroup;
		
		public String getProcessInstanceId() {
			return processInstanceId;
		}
		public void setProcessInstanceId(String processInstanceId) {
			this.processInstanceId = processInstanceId;
		}
		public String getTaskId() {
			return taskId;
		}
		public void setTaskId(String taskId) {
			this.taskId = taskId;
		}
		public String getTaskType() {
			return taskType;
		}
		public void setTaskType(String taskType) {
			this.taskType = taskType;
		}
		public String getTaskName() {
			return taskName;
		}
		public void setTaskName(String taskName) {
			this.taskName = taskName;
		}
		public String getHisImgString() {
			return hisImgString;
		}
		public void setHisImgString(String hisImgString) {
			this.hisImgString = hisImgString;
		}
		public List<Integer> getEmpDepList() {
			return empDepList;
		}
		public void setEmpDepList(List<Integer> empDepList) {
			this.empDepList = empDepList;
		}
		public String getAuthGroup() {
			return authGroup;
		}
		public void setAuthGroup(String authGroup) {
			this.authGroup = authGroup;
		}
				
	}
}
