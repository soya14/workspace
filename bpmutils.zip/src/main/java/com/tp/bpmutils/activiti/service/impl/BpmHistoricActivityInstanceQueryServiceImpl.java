package com.tp.bpmutils.activiti.service.impl;

import com.tp.bpmutils.activiti.service.IBpmHistoricActivityInstanceQueryService;
import org.activiti.engine.HistoryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.NativeHistoricActivityInstanceQuery;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * BPM HistoricActivityInstanceQuery 服務實作
 */
@Service
public class BpmHistoricActivityInstanceQueryServiceImpl implements IBpmHistoricActivityInstanceQueryService {

    /**
     * Activiti HistoryService
     */
    private final transient HistoryService historyService;

    /**
     * Activiti ManagementService
     */
    private final transient ManagementService managementService;

    /**
     * BpmHistoricActivityInstanceQueryServiceImpl Constructor
     *
     * @param historyService
     * @param managementService
     */
    public BpmHistoricActivityInstanceQueryServiceImpl(HistoryService historyService, ManagementService managementService) {
        this.historyService = historyService;
        this.managementService = managementService;
    }

    @Override
    public List<HistoricActivityInstance> findByProcInstIdInAndEndTimeIsNull(List<String> procInstIds) {

        String sql = "select * from {0} where PROC_INST_ID_ in ({1}) and END_TIME_ is null";
        String tableName = managementService.getTableName(HistoricActivityInstance.class);
        List nameOfProcInstIds = new ArrayList();
        String nameOfProcInstId = "procInstId{0}";

        for (int i = 0; i < procInstIds.size(); i++) {
            nameOfProcInstIds.add("#{" + MessageFormat.format(nameOfProcInstId, i) + "}");
        }
        NativeHistoricActivityInstanceQuery nativeHistoricActivityInstanceQuery = historyService.createNativeHistoricActivityInstanceQuery().sql(MessageFormat.format(sql, tableName, String.join(",", nameOfProcInstIds)));
        for (int i = 0; i < procInstIds.size(); i++) {
            nativeHistoricActivityInstanceQuery.parameter(MessageFormat.format(nameOfProcInstId, i), procInstIds.get(i));
        }

        return nativeHistoricActivityInstanceQuery.list();
    }

    @Override
    public Map<String, List<HistoricActivityInstance>> findMapByProcInstIdInAndEndTimeIsNull(List<String> procInstIds) {

        Map<String, List<HistoricActivityInstance>> processInstanceIdHistoricActivityInstanceList = new HashMap<>();
        if (CollectionUtils.isNotEmpty(procInstIds)) {
            List<HistoricActivityInstance> historicActivityInstances = findByProcInstIdInAndEndTimeIsNull(procInstIds);
            if (CollectionUtils.isNotEmpty(historicActivityInstances)) {
                for (HistoricActivityInstance historicActivityInstance : historicActivityInstances) {
                    List<HistoricActivityInstance> tmpList = MapUtils.getObject(processInstanceIdHistoricActivityInstanceList, historicActivityInstance.getProcessInstanceId(), new ArrayList<>());
                    tmpList.add(historicActivityInstance);
                    processInstanceIdHistoricActivityInstanceList.put(historicActivityInstance.getProcessInstanceId(), tmpList);
                }
            }
        }

        return processInstanceIdHistoricActivityInstanceList;
    }
}
