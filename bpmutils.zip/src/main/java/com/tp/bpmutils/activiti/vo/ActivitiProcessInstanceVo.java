package com.tp.bpmutils.activiti.vo;

/**
 * Activiti ProcessInstanceVo
 */
public class ActivitiProcessInstanceVo extends ActivitiBaseVo {

    /**
     *
     */
    private static final long serialVersionUID = -6536062839081941518L;

    /** 流程案例 ID */
    private String processInstance;

    /**
     * ActivitiProcessInstanceVo
     *
     * @param processInstance
     */
    public ActivitiProcessInstanceVo(String processInstance) {
        super();
        this.processInstance = processInstance;
    }

    public String getProcessInstance() {
        return processInstance;
    }

    public void setProcessInstance(String processInstance) {
        this.processInstance = processInstance;
    }
}
