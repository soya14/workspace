package com.tp.bpmutils.activiti.response;

import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢案件資訊回覆
 *
 * @author tp
 */
@Schema(description = "查詢案件資訊回覆")
public class ActivitiQueryTaskResp extends BPMApiResponse {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private ActivitiTaskVo data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryTaskResp success(ActivitiTaskVo data) {
        ActivitiQueryTaskResp apiSuccess = new ActivitiQueryTaskResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public ActivitiTaskVo getData() {
        return data;
    }

    public void setData(ActivitiTaskVo data) {
        this.data = data;
    }
}
