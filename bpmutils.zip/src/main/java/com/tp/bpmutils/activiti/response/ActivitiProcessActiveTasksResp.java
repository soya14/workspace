package com.tp.bpmutils.activiti.response;

import java.util.List;

import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢流程定義任務回覆
 *
 * @author tp
 */
@Schema(description = "查詢流程定義任務回覆")
public class ActivitiProcessActiveTasksResp extends BPMApiResponse {

    /**
     * 定義任務
     */
    @ArraySchema(arraySchema = @Schema(description = "定義任務"))
    private List<String> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiProcessActiveTasksResp success(List<String> data) {
        ActivitiProcessActiveTasksResp apiSuccess = new ActivitiProcessActiveTasksResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public List<String> getData() {
        return data;
    }

    public void setData(List<String> data) {
        this.data = data;
    }
}
