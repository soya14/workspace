package com.tp.bpmutils.activiti.response;

import com.tp.bpmutils.common.util.BPMApiResponse;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 強制終止流程回覆
 *
 * @author tp
 */
@Schema(description = "強制終止流程回覆")
public class ActivitiTerminateProcessResp extends BPMApiResponse {

    /**
     * 結果
     */
    @Schema(description = "結果", example = "true")
    private Boolean data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiTerminateProcessResp success(Boolean data) {
        ActivitiTerminateProcessResp apiSuccess = new ActivitiTerminateProcessResp();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    @Override
    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }
}
