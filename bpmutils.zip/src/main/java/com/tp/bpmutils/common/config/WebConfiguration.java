package com.tp.bpmutils.common.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.tp.bpmutils.common.interceptor.RootInterceptor;

/**
 * WebMvc Configurer
 */
@Configuration
public class WebConfiguration implements WebMvcConfigurer {

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		RootInterceptor rootInterceptor = new RootInterceptor();
		registry.addInterceptor(rootInterceptor).addPathPatterns("/**");
	}
}
