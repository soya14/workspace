package com.tp.bpmutils.common.controller;

import io.swagger.v3.oas.annotations.Operation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tp.bpmutils.common.exception.BPMExceptionStatus;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * ErrorController Implements
 */
@Controller
public class ErrorControllerImpl implements ErrorController {

    /**
     * Logger object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ErrorControllerImpl.class);

    @Override
    public String getErrorPath() {
        return "/error";
    }

    /**
     * Error handle
     *
     * @param request
     * @param response
     */
    @RequestMapping("/error")
    @Operation(summary = "Spring 系統錯誤", hidden = true)
    public void handleError(HttpServletRequest request, HttpServletResponse response) {
        int status = response.getStatus();
        if (status == HttpStatus.NOT_FOUND.value()) {
            LOGGER.error("status: {}", status);
            response.setHeader("X-Error-Code", BPMExceptionStatus.SYSTEM_ERROR.code() + "." + HttpStatus.NOT_FOUND.getReasonPhrase());
//            response.setHeader("X-Error-Msg", HttpStatus.NOT_FOUND.name());
        } else if (StringUtils.isBlank(response.getHeader("X-Error-Code"))) {
            LOGGER.error("status: {}", status);
            response.setHeader("X-Error-Code", BPMExceptionStatus.SYSTEM_ERROR.code() + "." + HttpStatus.valueOf(status).getReasonPhrase());
        }
        if (LOGGER.isErrorEnabled()) {
            LOGGER.error("requestURL: {}", request.getRequestURL());
        }
    }
}
