package com.tp.bpmutils.common.config;

import org.activiti.engine.ProcessEngineConfiguration;
import org.activiti.engine.impl.history.HistoryLevel;
import org.activiti.spring.SpringProcessEngineConfiguration;
import org.activiti.spring.boot.AbstractProcessEngineAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.core.task.TaskExecutor;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * Activiti Configuration
 */
@Configuration
public class ActivitiConfiguration extends AbstractProcessEngineAutoConfiguration {

    /**
     * dataSource
     */
    private final transient DataSource dataSource;

    /**
     * environment
     */
    private final transient Environment environment;

    /**
     * ActivitiConfiguration Constructor
     *
     * @param dataSource
     * @param environment
     */
    public ActivitiConfiguration(DataSource dataSource, Environment environment) {
        super();
        this.dataSource = dataSource;
        this.environment = environment;
    }

    /**
     * Get transactionManager
     *
     * @return
     * @throws ClassNotFoundException
     */
    @Bean
    public PlatformTransactionManager transactionManager() throws ClassNotFoundException {
        return new DataSourceTransactionManager(dataSource);
    }

    /**
     * Get Spring ProcessEngineConfiguration
     *
     * @return
     * @throws ClassNotFoundException
     */
    @Bean
    public SpringProcessEngineConfiguration springProcessEngineConfiguration() throws ClassNotFoundException {
        SpringProcessEngineConfiguration configuration = new SpringProcessEngineConfiguration();
        //配置DB資訊
        configuration.setDataSource(dataSource);
        configuration.setDatabaseSchemaUpdate(environment.getProperty("spring.processEngine.dbSchemaUpdate", ProcessEngineConfiguration.DB_SCHEMA_UPDATE_FALSE));
        configuration.setHistoryLevel(HistoryLevel.FULL);
        configuration.setTransactionManager(transactionManager());
        configuration.setAsyncExecutorActivate(environment.getProperty("spring.processEngine.asyncExecutor.activate", Boolean.class));
        configuration.setAsyncExecutorThreadPoolQueueSize(environment.getProperty("spring.processEngine.asyncExecutor.threadPoolQueueSize", Integer.class));
        configuration.setAsyncExecutorCorePoolSize(environment.getProperty("spring.processEngine.asyncExecutor.corePoolSize", Integer.class));
        configuration.setAsyncExecutorMaxPoolSize(environment.getProperty("spring.processEngine.asyncExecutor.maxPoolSize", Integer.class));
        configuration.setAsyncExecutorThreadKeepAliveTime(environment.getProperty("spring.processEngine.asyncExecutor.threadKeepAliveTime", Long.class));
        return configuration;
    }

    /**
     * Primary TaskExecutor
     *
     * @return
     */
    @Primary
    @Bean
    public TaskExecutor primaryTaskExecutor() {
        return new ThreadPoolTaskExecutor();
    }

    /**
     * Get UserDetailsService
     * ps.取自 Activiti 官方範例
     *
     * @return
     */
    @Bean
    public UserDetailsService userDetailsService() {
        return new InMemoryUserDetailsManager();
    }
}
