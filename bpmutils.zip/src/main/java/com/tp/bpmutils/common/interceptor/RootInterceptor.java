package com.tp.bpmutils.common.interceptor;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

/**
 * Root Interceptor
 */
public class RootInterceptor implements HandlerInterceptor {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(RootInterceptor.class);

    /**
     * Env name
     */
    @Value("${env.name}")
    private transient String envName;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        String xServerTraceId = UUID.randomUUID().toString();

        MDC.put("X-Server-TraceId", xServerTraceId);

        response.setHeader("X-Server-TraceId", xServerTraceId);
        response.setHeader("X-Server-Date", DateTimeFormatter.RFC_1123_DATE_TIME
                .withZone(ZoneOffset.UTC)
                .format(Instant.now()));

        LOGGER.info("envName: {}", envName);
        if (StringUtils.equals("local", envName)) {
            response.addHeader("Access-Control-Allow-Origin", "*");
            response.setHeader("Access-Control-Allow-Methods", "*");
            response.setHeader("Access-Control-Allow-Headers", "*");
        }

        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {
        // NO BODY
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler,
                                Exception ex) throws Exception {
        MDC.clear();
    }
}
