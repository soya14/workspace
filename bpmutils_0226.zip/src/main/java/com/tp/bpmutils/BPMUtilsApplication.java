package com.tp.bpmutils;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * BPM Utils APP Initializer
 */
@SpringBootApplication
public class BPMUtilsApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(BPMUtilsApplication.class);
    }

    /**
     * The Main
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(BPMUtilsApplication.class, args);
    }

}
