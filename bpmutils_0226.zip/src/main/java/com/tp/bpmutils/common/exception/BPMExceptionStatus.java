package com.tp.bpmutils.common.exception;

import org.springframework.lang.Nullable;

/**
 * BPM Exception status enum
 *
 * @author tp
 */
public enum BPMExceptionStatus {

    SYSTEM_ERROR("SYS", "系統錯誤", "SystemError"),

    METHOD_ERROR("SYS", "Request method不支援", "MethodError"),

    INPUT_PARAMETER_ERROR("FORMAT", "輸入參數 {0} 錯誤。", "InputParameterError"),

	APPROVED_ERROR("APPROVED", "此案件已被審核", "ApprovedError"),

	PERMISSION_DENIED("PERMISSION", "沒有審核權限", "PermissionDenied");

	/**
	 * code
	 */
    private final String code;
	/**
	 * msg
	 */
    private final String msg;
	/**
	 * description
	 */
	private final String description;

	BPMExceptionStatus(String code, String msg, String description) {
	    this.code = code;
	    this.msg = msg;
	    this.description = description;
	}

	public String code() {
		return this.code;
	}

	public String msg() {
		return this.msg;
	}

	public String description() {
		return this.description;
	}

	@Override
	public String toString() {
		return this.code + " " + name();
	}

	/**
	 * resolve
	 *
	 * @param code
	 * @return
	 */
	@Nullable
	public static BPMExceptionStatus resolve(String code) {
		for (BPMExceptionStatus status : values()) {
			if (status.code.equals(code)) {
				return status;
			}
		}
		return null;
	}
}
