package com.tp.bpmutils.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.net.ssl.*;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

/**
 * Http(SSL)
 */
@Component
public class DummySecureProtocolSocketFactory {

    /**
     * Logger Object
     */
	private static final Logger LOGGER = LoggerFactory.getLogger(DummySecureProtocolSocketFactory.class);

    /**
     * SSLContext singleton object
     */
    private static SSLContext sslcontext;

    /**
     * Dummy init method
     */
    @PostConstruct
    public static void init() {
        sslcontext = createSSLContext();
    }
   
    /**
     * SSLContext
     * @return SSLContext
     */
    private static SSLContext createSSLContext() {
        SSLContext sslcontext = null;
        try {
            sslcontext = SSLContext.getInstance("TLS");
            sslcontext.init(null,  new TrustManager[] { new TrustAllCerts() }, new SecureRandom());
        } catch (NoSuchAlgorithmException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage());
            }
        } catch (KeyManagementException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage());
            }
        }
        return sslcontext;
    }
   
    private static SSLContext getSSLContext() {
        return sslcontext;
    }

    /**
     * Create Customer X509TrustManager
     */
    public static class TrustAllCerts implements X509TrustManager {
        @Override
        public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("TrustAllCerts checkClientTrusted");
            }
        }

        @Override
        public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("TrustAllCerts checkServerTrusted");
            }
        }

        @Override
        public X509Certificate[] getAcceptedIssuers() {return new X509Certificate[0];}
    }

    /**
     * Create TrustAllHostname Verifier
     */
    public static class TrustAllHostnameVerifier implements HostnameVerifier {
        @Override
        public boolean verify(String hostname, SSLSession session) {
            return true;
        }
    }

    /**
     * Create SSLSocketFactory
     *
     * @return
     */
    public static SSLSocketFactory createSSLSocketFactory() {
        SSLSocketFactory ssfFactory = null;

        try {
            SSLContext sc = getSSLContext();
            if (null != sc) {
                ssfFactory = sc.getSocketFactory();
            }
        } catch (Exception e) {
            LOGGER.error("SocketFactory create error.");
        }

        return ssfFactory;
    }
}
