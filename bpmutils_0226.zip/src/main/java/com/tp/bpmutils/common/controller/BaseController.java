package com.tp.bpmutils.common.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tp.bpmutils.activiti.request.ActivitiReqData;
import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 基本輸入、輸出處理 Controller
 *
 * @author tp
 */
public class BaseController {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BaseController.class);

    /**
     * General JSON String
     *
     * @param object
     * @return
     */
    public String toJSON(Object object) {
        ObjectMapper objectMapper = new ObjectMapper();
        String jsonString = null;
        try {
            jsonString = objectMapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }
        return jsonString;
    }

    /**
     * 檢查輸入
     *
     * @param parameters
     */
    public void checkInput(Object[]... parameters) {

        if (ArrayUtils.isNotEmpty(parameters)) {

            StringBuilder nullParameter = new StringBuilder();

            for (Object[] parameter : parameters) {

                if (null == parameter || parameter.length != 2) {
                    continue;
                }

                if (null == parameter[1]) {
                    nullParameter.append('[').append(parameter[0]).append(']');
                    break;
                }
            }

            if (nullParameter.length() > 0) {
                throw new BPMException(BPMException.getInputParameterError(nullParameter.toString()), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
            }
        }
    }

    /**
     * 檢查輸入
     *
     * @param req
     */
    public void checkInput(ActivitiReqData req) {
        checkInput(req, null, null);
    }

    /**
     * 檢查輸入
     *
     * @param req
     * @param requiredParam
     * @param multiChoiceParam
     */
    public void checkInput(Object req, String[] requiredParam, String[][] multiChoiceParam) {

        if (null == req) {
            throw new BPMException(BPMException.getInputParameterError("[INPUT]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        } else {

            StringBuilder nullParameter = new StringBuilder();

//            if (ArrayUtils.isEmpty(requiredParam)) {
//                requiredParam = req.getRequiredParam();
//            }
//
//            if (ArrayUtils.isEmpty(multiChoiceParam)) {
//                multiChoiceParam = req.getMultiChoiceParam();
//            }

            String requiredResult = checkRequiredParam(req, requiredParam);
            if (StringUtils.isNotBlank(requiredResult)) {
                nullParameter.append(requiredResult);
            }

            String multiChoiceResult = checkMultiChoiceParam(req, multiChoiceParam);
            if (StringUtils.isNotBlank(multiChoiceResult)) {
                nullParameter.append(multiChoiceResult);
            }

            if (nullParameter.length() > 0) {
                throw new BPMException(BPMException.getInputParameterError(nullParameter.toString()), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
            }
        }
    }

    /**
     * 檢查必要參數
     *
     * @param req
     * @param requiredParam
     * @return
     */
    protected String checkRequiredParam(Object req, String[] requiredParam) {

        StringBuilder nullParameter = new StringBuilder();

        if (ArrayUtils.isNotEmpty(requiredParam)) {

            try {
                Field[] fields = req.getClass().getDeclaredFields();
                for (String parameter : requiredParam) {

                    if (StringUtils.isBlank(parameter)) {
                        continue;
                    }

                    for (Field field : fields) {
                        field.setAccessible(true);
                        if (StringUtils.equals(parameter, field.getName()) && null == field.get(req)) {
                            nullParameter.append('[').append(upperCaseFirst(parameter)).append(']');
                            break;
                        }
                    }
                }
            } catch (Exception e) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error("req class: {}, requiredParam: {}", req.getClass().getName(), requiredParam);
                }
            }
        }

        return nullParameter.toString();
    }

    /**
     * 檢查多選一必要參數
     *
     * @param req
     * @param multiChoiceParam
     * @return
     */
    protected String checkMultiChoiceParam(Object req, String[][] multiChoiceParam) {

        StringBuilder nullParameter = new StringBuilder();

        if (ArrayUtils.isNotEmpty(multiChoiceParam)) {

            try {
                Field[] fields = req.getClass().getDeclaredFields();
                boolean choiceOne = false;
                for (String[] parameters : multiChoiceParam) {

                    choiceOne = false;
                    for (String parameter : parameters) {

                        if (StringUtils.isBlank(parameter)) {
                            continue;
                        }

                        for (Field field : fields) {
                            field.setAccessible(true);
                            if (StringUtils.equals(parameter, field.getName()) && null != field.get(req)) {
                                choiceOne = true;
                                break;
                            }
                        }

                        if (choiceOne) {
                            break;
                        }
                    }

                    if (!choiceOne) {
                        nullParameter.append('[').append(upperCaseFirst(String.join(" AND ", parameters))).append(']');
                    }
                }
            } catch (Exception e) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error("req class: {}, multiChoiceParam: {}", req.getClass().getName(), multiChoiceParam);
                }
            }
        }

        return nullParameter.toString();

    }

    private String upperCaseFirst(String val) {
        StringBuffer strbf = new StringBuffer();
        Matcher match = Pattern.compile("([a-z])([a-z]*)", Pattern.CASE_INSENSITIVE).matcher(val);
        while (match.find()) {
            match.appendReplacement(strbf, match.group(1).toUpperCase() + match.group(2));
        }
        return match.appendTail(strbf).toString();
    }
}
