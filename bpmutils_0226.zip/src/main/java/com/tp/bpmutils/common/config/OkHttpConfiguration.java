package com.tp.bpmutils.common.config;

import com.tp.bpmutils.common.util.DummySecureProtocolSocketFactory;
import okhttp3.*;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * OkHttp Configuration
 *
 * @author tp
 */
@Configuration
public class OkHttpConfiguration {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(OkHttpConfiguration.class);

    /**
     * OkHttpClient's ssl Trust flag
     */
    private static boolean sslTrust;

    /**
     * OkHttpClient's maxIdleConnections
     */
    private static int maxIdleConnections;

    /**
     * OkHttpClient's keepAliveDuration
     */
    private static long keepAliveDuration;

    /**
     * OkHttpClient's connectTimeout
     */
    private static long connectTimeout;

    /**
     * OkHttpClient's writeTimeout
     */
    private static long writeTimeout;

    /**
     * OkHttpClient's readTimeout
     */
    private static long readTimeout;

    /**
     * OkHttpClient customer's retryCount
     */
    private static int retryCount;

    /**
     * Spring's Environment object
     */
    private static Environment env;

    /**
     * OkHttpConfiguration construct method
     *
     * @param inEnv
     */
    public OkHttpConfiguration(Environment inEnv) {
        setEnvironment(inEnv);
    }

    private static void setEnvironment(Environment newEnv) {
        env = newEnv;
    }

    /**
     * OKHttpConfiguration's init method
     */
    @PostConstruct
    public static void readConfig() {
        sslTrust = BooleanUtils.toBoolean(env.getProperty("okhttp.sslTrust"));
        maxIdleConnections = NumberUtils.toInt(env.getProperty("okhttp.maxIdleConnections"), 200);
        keepAliveDuration = NumberUtils.toLong(env.getProperty("okhttp.keepAliveDuration"), 5L);
        connectTimeout = NumberUtils.toLong(env.getProperty("okhttp.connectTimeout"), 30L);
        writeTimeout = NumberUtils.toLong(env.getProperty("okhttp.writeTimeout"), 30L);
        readTimeout = NumberUtils.toLong(env.getProperty("okhttp.readTimeout"), 30L);
        retryCount = NumberUtils.toInt(env.getProperty("okhttp.readTimeout"), 0);
    }

    /**
     * Gen ConnectionPool
     *
     * @return ConnectionPool
     */
    @Bean
    public ConnectionPool pool() {
        return new ConnectionPool(maxIdleConnections, keepAliveDuration, TimeUnit.MINUTES);
    }

    /**
     * Create OkHttpClient singleton object
     *
     * @return OkHttpClient
     */
    @Bean
    public OkHttpClient okHttpClient() {

        OkHttpClient.Builder mBuilder = new OkHttpClient.Builder();

        // 信任憑證
        if (sslTrust) {
            mBuilder.sslSocketFactory(DummySecureProtocolSocketFactory.createSSLSocketFactory(), new DummySecureProtocolSocketFactory.TrustAllCerts());
            mBuilder.hostnameVerifier(new DummySecureProtocolSocketFactory.TrustAllHostnameVerifier());
        }

        // 是否開啟快取
        mBuilder.retryOnConnectionFailure(false);

        // 連線池
        mBuilder.connectionPool(pool());

        // connect、read、write 超時設定
        mBuilder.connectTimeout(connectTimeout, TimeUnit.SECONDS);
        mBuilder.readTimeout(writeTimeout, TimeUnit.SECONDS);
        mBuilder.writeTimeout(readTimeout, TimeUnit.SECONDS);

        setRetryCount(mBuilder);

        return mBuilder.build();
    }

    /**
     * Create OkHttpClient instance by customer timeout's second
     *
     * @param sec
     * @return
     */
    public static OkHttpClient getInstanceSetTimeOut(Integer sec) {
        OkHttpClient.Builder mBuilder = new OkHttpClient.Builder();

        // 信任憑證
        if (sslTrust) {
            mBuilder.sslSocketFactory(DummySecureProtocolSocketFactory.createSSLSocketFactory(), new DummySecureProtocolSocketFactory.TrustAllCerts());
            mBuilder.hostnameVerifier(new DummySecureProtocolSocketFactory.TrustAllHostnameVerifier());
        }

        // 是否開啟快取
        mBuilder.retryOnConnectionFailure(false);

        // connect、read、write 超時設定
        mBuilder.connectTimeout(sec, TimeUnit.SECONDS);
        mBuilder.readTimeout(sec, TimeUnit.SECONDS);
        mBuilder.writeTimeout(sec, TimeUnit.SECONDS);

        setRetryCount(mBuilder);

        return mBuilder.build();
    }

    /**
     * Customer's retry setting
     *
     * @param mBuilder
     */
    private static void setRetryCount(OkHttpClient.Builder mBuilder) {
        if (retryCount > 0) {
            mBuilder.retryOnConnectionFailure(true);
            mBuilder.interceptors().add(new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    Request request = chain.request();

                    // try the request
                    Response response = chain.proceed(request);

                    int tryCount = 0;
                    int maxLimit = retryCount; //Set your max limit here

                    while (!response.isSuccessful() && tryCount < maxLimit) {
                        LOGGER.error("[intercept] Request failed - {}", tryCount);
                        tryCount++;
                        // retry the request
                        response = chain.proceed(request);
                    }

                    // otherwise just pass the original response on
                    return response;
                }
            });
        }
    }
}
