package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 取得流程圖(SVG) Base64 位元字串回覆
 *
 * @author tp
 */
@Schema(description = "取得流程圖(SVG) Base64 位元字串回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiProcessImgResp {

    /**
     * 流程圖(SVG) Base64 位元字串
     */
    @Schema(description = "流程圖(SVG) Base64 位元字串")
    private ActivitiMainSubVo data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiProcessImgResp success(ActivitiMainSubVo data) {
        ActivitiProcessImgResp apiSuccess = new ActivitiProcessImgResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public ActivitiMainSubVo getData() {
        return data;
    }

    public void setData(ActivitiMainSubVo data) {
        this.data = data;
    }
}
