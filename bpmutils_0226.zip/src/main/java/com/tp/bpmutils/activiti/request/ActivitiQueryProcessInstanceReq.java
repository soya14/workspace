package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import static io.swagger.v3.oas.annotations.media.Schema.AccessMode.READ_ONLY;

/**
 * 查詢案件請求
 *
 * @author tp
 */
@Schema(description = "查詢案件請求")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiQueryProcessInstanceReq {

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"processInstanceId"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程實例代號
     */
    @Schema(description = "流程實例代號：5", required = true)
    private String processInstanceId;

    /**
     * Get Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    /**
     * Get Multi Choice Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }
}
