package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * 流程檔案上傳部署回覆
 *
 * @author tp
 */
@Schema(description = "流程檔案上傳部署回覆")
public class ActivitiUploadProcessReq {

    /**
     * API代碼
     */
    @JsonProperty("MSGID")
    @Size(message = "MSGID 長度不得超過20", max = 20)
    @NotBlank(message = "MSGID is blank")
    @Schema(description = "API代碼(Ex：LON-LX-LIP-01)")
    private String msgId;

    /**
     * 來源端系統APID
     */
    @JsonProperty("SOURCECHANNEL")
    @Size(message = "SOURCECHANNEL 長度不得超過20", max = 20)
    @NotBlank(message = "SOURCECHANNEL is blank")
    @Schema(description = "來源端系統APID(Ex：LIP-C-ELCQPENDC001)")
    private String sourceChannel;

    /**
     * 交易序號(yyyyMMddHHmmssSSS)
     */
    @JsonProperty("TXNSEQ")
    @Size(message = "TXNSEQ 長度不得超過20", max = 20)
    @NotBlank(message = "TXNSEQ is blank")
    @Schema(description = "交易序號(yyyyMMddHHmmssSSS)(Ex：20210507135133125)")
    private String txnSeq;

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getSourceChannel() {
        return sourceChannel;
    }

    public void setSourceChannel(String sourceChannel) {
        this.sourceChannel = sourceChannel;
    }

    public String getTxnSeq() {
        return txnSeq;
    }

    public void setTxnSeq(String txnSeq) {
        this.txnSeq = txnSeq;
    }
}
