package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

/**
 * MwHeader
 */
@Data
public class MwHeader {

    /**
     * 來源端系統APID
     */
    @JsonProperty("MSGID")
    @Size(message = "MSGID 長度不得超過20", max = 20)
    @NotBlank(message = "MSGID is blank")
    protected String msgId;

    /**
     * API代碼
     */
    @JsonProperty("SOURCECHANNEL")
    @Size(message = "SOURCECHANNEL 長度不得超過20", max = 20)
    @NotBlank(message = "SOURCECHANNEL is blank")
    protected String sourceChannel;

    /**
     * 交易序號(yyyyMMddHHmmssSSS)
     */
    @JsonProperty("TXNSEQ")
    @Size(message = "TXNSEQ 長度不得超過20", max = 20)
    @NotBlank(message = "TXNSEQ is blank")
    protected String txnSeq;

}
