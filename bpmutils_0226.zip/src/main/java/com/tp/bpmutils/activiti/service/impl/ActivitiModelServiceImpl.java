package com.tp.bpmutils.activiti.service.impl;

import cn.hutool.core.util.StrUtil;
import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import com.tp.bpmutils.activiti.request.ActivitiDeployProcessReq;
import com.tp.bpmutils.activiti.request.ActivitiProcessActiveTasksReq;
import com.tp.bpmutils.activiti.request.ActivitiQueryProcessInstanceReq;
import com.tp.bpmutils.activiti.response.ActivitiDeployProcessResp;
import com.tp.bpmutils.activiti.response.ActivitiProcessActiveTasksResp;
import com.tp.bpmutils.activiti.service.IActivitiModelService;
import com.tp.bpmutils.activiti.service.repository.BpmProcinstInfoRepository;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowElement;
import org.activiti.bpmn.model.FlowNode;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricActivityInstanceQuery;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.activiti.image.impl.DefaultProcessDiagramGenerator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/**
 * 處理 Activiti Model 服務實作
 *
 * @author tp
 */
@Service
public class ActivitiModelServiceImpl implements IActivitiModelService {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiProcessServiceImpl.class);

    /**
     * Activiti RepositoryService
     */
    private final transient RepositoryService repositoryService;

    /**
     * Activiti RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * Activiti HistoryService
     */
    private final transient HistoryService historyService;

    /**
     * Flow Default Size
     */
    private static final int FLOW_DEFAULT_SIZE = 1;

    /**
     * BPM ProcinstInfoRepository
     */
    private final transient BpmProcinstInfoRepository bpmProcinstInfoRepository;

    /**
     * ActivitiModelServiceImpl Constructor
     *
     * @param repositoryService
     * @param runtimeService
     * @param historyService
     * @param bpmProcinstInfoRepository
     */
    public ActivitiModelServiceImpl(RepositoryService repositoryService, RuntimeService runtimeService, HistoryService historyService, BpmProcinstInfoRepository bpmProcinstInfoRepository) {
        this.repositoryService = repositoryService;
        this.runtimeService = runtimeService;
        this.historyService = historyService;
        this.bpmProcinstInfoRepository = bpmProcinstInfoRepository;
    }

    @Override
    public String deployProcess(MultipartFile file) {

        Deployment deployment = null;
        ProcessDefinition processDefinition = null;
        try {
            String fileName = file.getOriginalFilename();
            deployment = repositoryService.createDeployment()
                    .addInputStream(fileName, file.getInputStream())
                    .name(fileName)
                    .deploy();
            processDefinition = repositoryService.createProcessDefinitionQuery()
                    .deploymentId(deployment.getId())
                    .singleResult();
        } catch (IOException e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        if (null == processDefinition || StringUtils.isBlank(processDefinition.getId())) {
            throw new BPMException(BPMException.getInputParameterError("[INPUT FILE]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }

        return processDefinition.getId();
    }

    @Override
    public ActivitiDeployProcessResp.ActivitiDeployProcessRespData deployResourceFiles(ActivitiDeployProcessReq req) {

        Deployment deployment = null;
        ProcessDefinition processDefinition = null;
        List<String> failFileNameList = new ArrayList<String>();

        try {
            String path = ResourceUtils.getFile(ResourceUtils.CLASSPATH_URL_PREFIX + "\\process\\" + req.getDeployFolder()).getPath() + "\\";
            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("deploy file path >>>>>>> " + path);
            }

            for (String fileName : new File(path).list()) {
                try {
                    deployment = repositoryService.createDeployment()
                            .addInputStream(fileName, Files.newInputStream(Paths.get(path + fileName)))
                            .name(fileName)
                            .deploy();

                    processDefinition = repositoryService.createProcessDefinitionQuery()
                            .deploymentId(deployment.getId())
                            .singleResult();

                    LOGGER.info("{} deployed.", processDefinition);
                } catch (Exception e) {
                    LOGGER.error("error: {}", null != e ? e.getMessage() : "");
                    failFileNameList.add(fileName);
                }
            }
        } catch (Exception e) {
            LOGGER.error(null, e);
        }

        ActivitiDeployProcessResp.ActivitiDeployProcessRespData res = new ActivitiDeployProcessResp.ActivitiDeployProcessRespData();
        if (CollectionUtils.isNotEmpty(failFileNameList)) {
            res.setRtnCode(1);
            res.setMsg("Process deploy fail: " + failFileNameList);
        } else {
            res.setRtnCode(0);
            res.setMsg("Deploy success.");
        }

        return res;
    }

    @Override
    public ActivitiMainSubVo getProcessImg(ActivitiQueryProcessInstanceReq req) {
        String processInstanceId = req.getProcessInstanceId();
        BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(processInstanceId);

        ActivitiMainSubVo result = new ActivitiMainSubVo();
        String process = showProcessImg(processInstanceId);
        result.setProcess(process);

        if (bpmProcinstInfo != null) {
            if (StrUtil.equals(processInstanceId, bpmProcinstInfo.getMainProcInstId())) {
                result.setMainProcess(process);
            } else {
                result.setMainProcess(showProcessImg(bpmProcinstInfo.getMainProcInstId()));
            }

            if (StrUtil.isNotEmpty(bpmProcinstInfo.getSourceProcInstId())) {
                result.setSourceProcess(showProcessImg(bpmProcinstInfo.getSourceProcInstId()));
            }
        } else {
            result.setMainProcess(process);
        }

        return result;
    }

    /**
     * 取得並返回流程圖 bytes(base64) string
     *
     * @param processInstanceId
     * @return
     */
    private String showProcessImg(String processInstanceId) {

        BpmnModel bpmnModel;
        ProcessInstance processInstanceQuery = runtimeService.createProcessInstanceQuery().processInstanceId(processInstanceId).singleResult();
        HistoricProcessInstance processInstance = historyService
                .createHistoricProcessInstanceQuery()
                .processInstanceId(processInstanceId).singleResult();

        if (null == processInstance) {
            if (null != processInstanceQuery) {
                bpmnModel = repositoryService.getBpmnModel(processInstanceQuery.getProcessDefinitionId());
            } else {
                return "";
            }
        } else {
            // 獲取流程圖
            bpmnModel = repositoryService.getBpmnModel(processInstance.getProcessDefinitionId());
        }

        // 取得當前的節點
        List<String> activeActivityIds = new ArrayList();

        if (isEnd(processInstanceId)) {
            // 取得最後一個節點
            HistoricActivityInstanceQuery historicActivityInstanceQuery = historyService.createHistoricActivityInstanceQuery();
            List<HistoricActivityInstance> historicActivityInstanceList = historicActivityInstanceQuery.processInstanceId(processInstanceId).list();
            for (HistoricActivityInstance hi : historicActivityInstanceList) {

                String taskKey = hi.getActivityId();
                if ("endEvent".equals(hi.getActivityType())) {
                    // LOGGER.info("hi.getActivityType()===" + hi.getActivityType());
                    activeActivityIds.add(taskKey);
                }
            }
        } else {
            // 取得當前的節點
            activeActivityIds = runtimeService.getActiveActivityIds(processInstanceId);
        }

        List<HistoricActivityInstance> hisActIntList = historyService.createHistoricActivityInstanceQuery()
                .processInstanceId(processInstanceId)
                .list();
        if (LOGGER.isErrorEnabled()) {
            LOGGER.error("hisActIntList exist: {}", CollectionUtils.isNotEmpty(hisActIntList));
        }

        // Flows 紀錄
        List<String> highLightedFlows = getExecutedFlows(bpmnModel, hisActIntList);
        // 這個類在5.22.0往上的版本中才有
        DefaultProcessDiagramGenerator diagramGenerator = new DefaultProcessDiagramGenerator();
        // 繪製bpmnModel代表的流程的流程圖
        if (LOGGER.isErrorEnabled()) {
            LOGGER.error("bpmnModel exist: {}, activeActivityIds: {}, highLightedFlows: {}, DefaultActivityFontName: {}, DefaultLabelFontName: {}, DefaultAnnotationFontName: {}",
                    null != bpmnModel,
                    Arrays.toString(activeActivityIds.toArray()),
                    Arrays.toString(highLightedFlows.toArray()),
                    diagramGenerator.getDefaultActivityFontName(),
                    diagramGenerator.getDefaultLabelFontName(),
                    diagramGenerator.getDefaultAnnotationFontName());
        }
        InputStream inputStream = diagramGenerator.generateDiagram(
                bpmnModel,
                activeActivityIds,
                highLightedFlows,
                diagramGenerator.getDefaultActivityFontName(),
                diagramGenerator.getDefaultLabelFontName(),
                diagramGenerator.getDefaultAnnotationFontName());
        String encoded = null;

        try {
            byte[] bytes = IOUtils.toByteArray(inputStream);
            encoded = Base64.getEncoder().encodeToString(bytes);
        } catch (IOException e) {
            LOGGER.error("showProcessImg error ", e);
        } finally {
            if (null != inputStream) {
                try {
                    inputStream.close();
                } catch (Exception e) {
                    LOGGER.error("Close inputStream error.");
                }
            }
        }

        return encoded;
    }

    /**
     * Check ProcessInstance End
     *
     * @param processId
     * @return
     */
    public boolean isEnd(String processId) {
        ProcessInstance process = runtimeService.createProcessInstanceQuery().processInstanceId(processId).singleResult();
        if (process == null) {
            LOGGER.info("執行完畢");
            return true;
        } else {
            LOGGER.info("正在執行");
            return false;
        }
    }

    private List<String> getExecutedFlows(BpmnModel bpmnModel, List<HistoricActivityInstance> historicActivityInstanceList) {
        List<String> executedFlowIdList = new ArrayList<>();
        for (int i = 0; i < historicActivityInstanceList.size() - 1; i++) {
            HistoricActivityInstance his = historicActivityInstanceList.get(i);
            FlowNode flowNode = (FlowNode) bpmnModel.getFlowElement(his.getActivityId());
            List<SequenceFlow> sequenceFlowList = flowNode.getOutgoingFlows();
            if (sequenceFlowList.size() > FLOW_DEFAULT_SIZE) {
                HistoricActivityInstance nextHis = historicActivityInstanceList.get(i + 1);
                sequenceFlowList.forEach(sequenceFlow -> {
                    if (sequenceFlow.getTargetFlowElement().getId().equals(nextHis.getActivityId())) {
                        executedFlowIdList.add(sequenceFlow.getId());
                    }
                });
            } else if (sequenceFlowList.size() == FLOW_DEFAULT_SIZE) {
                executedFlowIdList.add(sequenceFlowList.get(0).getId());
            }
        }
        return executedFlowIdList;
    }

    @Override
    public List<ActivitiProcessActiveTasksResp.ElementInfo> getProcessActiveTasks(ActivitiProcessActiveTasksReq activitiProcessActiveTasksReq) {
        List<ActivitiProcessActiveTasksResp.ElementInfo> taskNameList = new ArrayList<>();
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery().processDefinitionKey(activitiProcessActiveTasksReq.getProcessDefKey()).latestVersion().singleResult();
        BpmnModel bpmnModel = repositoryService.getBpmnModel(processDefinition.getId());
        for (FlowElement flowElement : bpmnModel.getProcesses().get(0).getFlowElements()) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error("flowElement: {}", ToStringBuilder.reflectionToString(flowElement));
            }
            if (flowElement instanceof org.activiti.bpmn.model.Task) {
                ActivitiProcessActiveTasksResp.ElementInfo elementInfo = new ActivitiProcessActiveTasksResp.ElementInfo();
                elementInfo.setElementType(Task.class.getSimpleName());
                elementInfo.setElementId(flowElement.getId());
                elementInfo.setElementName(flowElement.getName());
                taskNameList.add(elementInfo);
            }
        }
        return taskNameList;
    }
}
