package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 查詢待辦數量回覆
 *
 * @author tp
 */
@Schema(description = "查詢待辦數量回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiQueryPendingCountResp {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private List<ActivitiPendingProcess> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryPendingCountResp success(List<ActivitiPendingProcess> data) {
        ActivitiQueryPendingCountResp apiSuccess = new ActivitiQueryPendingCountResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public List<ActivitiPendingProcess> getData() {
        return data;
    }

    public void setData(List<ActivitiPendingProcess> data) {
        this.data = data;
    }

    /**
     * Activiti PendingProcess
     */
    @JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
    public static class ActivitiPendingProcess {

        /**
         * 流程定義代碼
         */
        @Schema(description = "流程定義代碼")
        private String processDefKey;

        /**
         * 流程名稱
         */
        @Schema(description = "流程名稱")
        private String processName;

        /**
         * 任務總數
         */
        @Schema(description = "任務總數")
        private Integer totalCount;

        /**
         * 任務清單
         */
        @Schema(description = "任務清單")
        private List<ActivitiPendingTask> tasks;

        /**
         * 主流程定義代碼
         */
        @Schema(description = "主流程定義代碼")
        private String mainProcDefKey;

        /**
         * 上一階流程定義代碼
         */
        @Schema(description = "上一階流程定義代碼")
        private String sourceProcDefKey;

        public String getProcessDefKey() {
            return processDefKey;
        }

        public void setProcessDefKey(String processDefKey) {
            this.processDefKey = processDefKey;
        }

        public String getProcessName() {
            return processName;
        }

        public void setProcessName(String processName) {
            this.processName = processName;
        }

        public Integer getTotalCount() {
            return totalCount;
        }

        public void setTotalCount(Integer totalCount) {
            this.totalCount = totalCount;
        }

        public List<ActivitiPendingTask> getTasks() {
            return tasks;
        }

        public void setTasks(List<ActivitiPendingTask> tasks) {
            this.tasks = tasks;
        }

        public String getMainProcDefKey() {
            return mainProcDefKey;
        }

        public void setMainProcDefKey(String mainProcDefKey) {
            this.mainProcDefKey = mainProcDefKey;
        }

        public String getSourceProcDefKey() {
            return sourceProcDefKey;
        }

        public void setSourceProcDefKey(String sourceProcDefKey) {
            this.sourceProcDefKey = sourceProcDefKey;
        }
    }

    /**
     * Activiti PendingTask
     */
    @JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
    public static class ActivitiPendingTask {

        /**
         * 任務名稱
         */
        @Schema(description = "任務名稱")
        private String taskName;

        /**
         * 任務定義代碼
         */
        @Schema(description = "任務定義代碼")
        private String taskDefKey;

        /**
         * 任務數量
         */
        @Schema(description = "任務數量")
        private Integer count;

        public String getTaskName() {
            return taskName;
        }

        public void setTaskName(String taskName) {
            this.taskName = taskName;
        }

        public String getTaskDefKey() {
            return taskDefKey;
        }

        public void setTaskDefKey(String taskDefKey) {
            this.taskDefKey = taskDefKey;
        }

        public Integer getCount() {
            return count;
        }

        public void setCount(Integer count) {
            this.count = count;
        }
    }
}
