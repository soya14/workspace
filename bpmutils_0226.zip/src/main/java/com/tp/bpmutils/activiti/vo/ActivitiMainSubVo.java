package com.tp.bpmutils.activiti.vo;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

/**
 * 子母流程資訊
 *
 * @author tp
 */
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiMainSubVo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 7752918045430153867L;

    /**
     * 流程資訊
     */
    @Schema(description = "流程資訊")
    private Object process;

    /**
     * 主流程資訊
     */
    @Schema(description = "主流程資訊")
    private Object mainProcess;

    /**
     * 上一階流程資訊
     */
    @Schema(description = "上一階流程資訊")
    private Object sourceProcess;

    public Object getProcess() {
        return process;
    }

    public void setProcess(Object process) {
        this.process = process;
    }

    public Object getMainProcess() {
        return mainProcess;
    }

    public void setMainProcess(Object mainProcess) {
        this.mainProcess = mainProcess;
    }

    public Object getSourceProcess() {
        return sourceProcess;
    }

    public void setSourceProcess(Object sourceProcess) {
        this.sourceProcess = sourceProcess;
    }
}
