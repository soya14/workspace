package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ResponseTemplate
 *
 * @param <S>
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
public class ResponseTemplate<S> {

    /**
     * MWHEADER
     */
    @JsonProperty("MWHEADER")
    private MwHeaderResponse mwHeaderResponse;

    /**
     * TRANRS
     */
    @JsonProperty("TRANRS")
    private S tranrs;

    /**
     * Constructor
     *
     * @param mwHeaderResponse
     */
    public ResponseTemplate(MwHeaderResponse mwHeaderResponse) {
        this.mwHeaderResponse = mwHeaderResponse;
    }

}
