package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.activiti.vo.ActivitiCurrentTaskVo;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 目前停留在那些節點(含前一關)回覆
 *
 * @author tp
 */
@Schema(description = "目前停留在那些節點(含前一關)回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiQueryCurrentTaskResp {

    /**
     * 節點資訊
     */
    @Schema(description = "節點資訊")
    private List<ActivitiCurrentTaskVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryCurrentTaskResp success(List<ActivitiCurrentTaskVo> data) {
        ActivitiQueryCurrentTaskResp apiSuccess = new ActivitiQueryCurrentTaskResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public List<ActivitiCurrentTaskVo> getData() {
        return data;
    }

    public void setData(List<ActivitiCurrentTaskVo> data) {
        this.data = data;
    }
}
