package com.tp.bpmutils.activiti.service.listener;

import com.tp.bpmutils.activiti.service.repository.BpmProcinstInfoRepository;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.impl.ActivitiEntityEventImpl;
import org.activiti.engine.impl.persistence.entity.HistoricProcessInstanceEntityImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BPM ActivitiProcessComplete Listener<br/>
 * listen by ActivitiConfiguration
 *
 * @author tp
 */
public class BpmActivitiProcessCompleteListener implements ActivitiEventListener {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BpmEventListener.class);

    /**
     * BPM ProcinstInfoRepository
     */
    private final transient BpmProcinstInfoRepository bpmProcinstInfoRepository;

    /**
     * BpmActivitiProcessCompleteListener Constructor
     * @param bpmProcinstInfoRepository
     */
    public BpmActivitiProcessCompleteListener(BpmProcinstInfoRepository bpmProcinstInfoRepository) {
        this.bpmProcinstInfoRepository = bpmProcinstInfoRepository;
    }

    @Override
    public void onEvent(ActivitiEvent event) {
        if (event instanceof ActivitiEntityEventImpl) {
            ActivitiEntityEventImpl eventImpl = (ActivitiEntityEventImpl) event;
            Object entity = eventImpl.getEntity();
            if (entity instanceof HistoricProcessInstanceEntityImpl) {
                HistoricProcessInstanceEntityImpl hiProcInstEntityImpl = (HistoricProcessInstanceEntityImpl) entity;
                if (LOGGER.isInfoEnabled()) {
                    LOGGER.info("A process has ended: {}", hiProcInstEntityImpl.getProcessInstanceId());
                }
                bpmProcinstInfoRepository.setEndTimeFor(hiProcInstEntityImpl.getEndTime(), hiProcInstEntityImpl.getProcessInstanceId());
            }
        }
    }

    @Override
    public boolean isFailOnException() {
        return false;
    }
}