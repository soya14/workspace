package com.tp.bpmutils.activiti.service;

import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.ActivitiStartProcessResp;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;

import java.util.List;

/**
 * 處理 Activiti Process 服務介面
 *
 * @author tp
 */
public interface IActivitiProcessService {

    /**
     * 啟用流程
     *
     * @param req
     * @return
     */
    ActivitiStartProcessResp.ActStartProcessResData startProcess(ActivitiStartProcessReq req);

    /**
     * 完成節點
     *
     * @param activitiCompleteTaskReq
     */
    List<ActivitiTaskVo> completeTask(ActivitiCompleteTaskReq activitiCompleteTaskReq);

    /**
     * 領取案件
     *
     * @param activitiClaimTaskReq
     */
    List<ActivitiTaskVo> claimTask(ActivitiClaimTaskReq activitiClaimTaskReq);

    /**
     * 強制終止流程
     *
     * @param activitiTerminateProcessReq
     * @return
     */
    boolean terminateProcess(ActivitiTerminateProcessReq activitiTerminateProcessReq);

    /**
     * 增加會簽人員
     *
     * @param activitiAddCandidateGroupReq
     * @return
     */
    boolean addCandidateGroup(ActivitiAddCandidateGroupReq activitiAddCandidateGroupReq);

    /**
     * 移除群組
     *
     * @param activitiDeleteCandidateGroupReq
     * @return
     */
    boolean deleteCandidateGroup(ActivitiDeleteCandidateGroupReq activitiDeleteCandidateGroupReq);

    /**
     * 增加會簽人員
     *
     * @param activitiAddCandidateUserReq
     * @return
     */
    boolean addCandidateUser(ActivitiAddCandidateUserReq activitiAddCandidateUserReq);

    /**
     * 移除原本的處理者
     *
     * @param activitiDeleteCandidateUserReq
     * @return
     */
    boolean deleteCandidateUser(ActivitiDeleteCandidateUserReq activitiDeleteCandidateUserReq);

    /**
     * 改派處理者
     *
     * @param activitiSetAssigneeReq
     * @return
     */
    boolean setAssignee(ActivitiSetAssigneeReq activitiSetAssigneeReq);

    /**
     * 增加任務備註
     *
     * @param activitiAddCommentReq
     * @return
     */
    boolean addComment(ActivitiAddCommentReq activitiAddCommentReq);
}
