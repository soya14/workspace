package com.tp.bpmutils.activiti.task;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.tp.bpmutils.common.util.OkHttpUtils;
import org.activiti.engine.delegate.DelegateExecution;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * BPM CathayRESTTask
 *
 * @author tp
 */
public class CathayRESTTask extends AbstractRESTTask {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CathayRESTTask.class);

    @Override
    protected void postHandle(DelegateExecution execution, OkHttpUtils.OKResponse response) {
        try {
            String output = response.getBodyString();
            if (StrUtil.isNotBlank(output)) {
                JSONObject jsonObject = JSONUtil.parseObj(output);
                JSONObject mwheader = jsonObject.get("MWHEADER", JSONObject.class);

                if (mwheader != null) {
                    execution.setVariable("RETURNCODE", mwheader.get("RETURNCODE"));
                    execution.setVariable("RETURNDESC", mwheader.get("RETURNDESC"));
                }
            }
        } catch (Exception e) {
            //output非json字串格式
            LOGGER.error("error", e);
        }
    }

}
