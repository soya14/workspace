package com.tp.bpmutils.activiti.task;

/**
 * BPM RESTTask
 *
 * @author tp
 */
public class RESTTask extends AbstractRESTTask {

}
