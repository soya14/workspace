package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 審核節點回覆
 *
 * @author tp
 */
@Schema(description = "審核節點回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiCompleteTaskResp {

    /**
     * 任務資訊
     */
    @Schema(description = "任務資訊")
    private List<ActivitiTaskVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiCompleteTaskResp success(List<ActivitiTaskVo> data) {
        ActivitiCompleteTaskResp apiSuccess = new ActivitiCompleteTaskResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public List<ActivitiTaskVo> getData() {
        return data;
    }

    public void setData(List<ActivitiTaskVo> data) {
        this.data = data;
    }
}
