package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 查詢案件資訊回覆
 *
 * @author tp
 */
@Schema(description = "查詢案件資訊回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiQueryTaskResp {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private ActivitiTaskVo data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryTaskResp success(ActivitiTaskVo data) {
        ActivitiQueryTaskResp apiSuccess = new ActivitiQueryTaskResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public ActivitiTaskVo getData() {
        return data;
    }

    public void setData(ActivitiTaskVo data) {
        this.data = data;
    }
}
