package com.tp.bpmutils.activiti.service.impl;

import cn.hutool.core.collection.ListUtil;
import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.ActivitiStartProcessResp;
import com.tp.bpmutils.activiti.service.IActivitiCommonService;
import com.tp.bpmutils.activiti.service.IActivitiProcessService;
import com.tp.bpmutils.activiti.service.repository.BpmProcinstInfoRepository;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.constant.ActivitiConst;
import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import com.tp.bpmutils.common.util.DataUtil;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.identity.Authentication;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Task;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 處理 Activiti Process 服務實作
 *
 * @author tp
 */
@Service
public class ActivitiProcessServiceImpl implements IActivitiProcessService {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiProcessServiceImpl.class);

    /**
     * Activiti RepositoryService
     */
    private final transient RepositoryService repositoryService;

    /**
     * Activiti RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * Activiti TaskService
     */
    private final transient TaskService taskService;

    /**
     * Activiti HistoryService
     */
    private final transient HistoryService historyService;

    /**
     * BPM ActivitiCommonService
     */
    private final transient IActivitiCommonService activitiCommonService;

    /**
     * BPM ProcinstInfoRepository
     */
    private final transient BpmProcinstInfoRepository bpmProcinstInfoRepository;

    /**
     * ActivitiProcessServiceImpl Constructor
     *
     * @param repositoryService
     * @param runtimeService
     * @param taskService
     * @param historyService
     * @param activitiCommonService
     * @param bpmProcinstInfoRepository
     */
    public ActivitiProcessServiceImpl(RepositoryService repositoryService, RuntimeService runtimeService, TaskService taskService, HistoryService historyService, IActivitiCommonService activitiCommonService, BpmProcinstInfoRepository bpmProcinstInfoRepository) {
        this.repositoryService = repositoryService;
        this.runtimeService = runtimeService;
        this.taskService = taskService;
        this.historyService = historyService;
        this.activitiCommonService = activitiCommonService;
        this.bpmProcinstInfoRepository = bpmProcinstInfoRepository;
    }

    private Map<String, Object> getBeanMap(Object bean) {
        Map<String, Object> beanMap = DataUtil.beanToMap(bean);
        if (MapUtils.isNotEmpty(beanMap)) {
            if (null != beanMap.get("ParamMap")) {
                beanMap.remove("ParamMap");
            }
            if (null != beanMap.get("RequiredParam")) {
                beanMap.remove("RequiredParam");
            }
            if (null != beanMap.get("MultiChoiceParam")) {
                beanMap.remove("MultiChoiceParam");
            }
        }
        return beanMap;
    }

    @Override
    public ActivitiStartProcessResp.ActStartProcessResData startProcess(ActivitiStartProcessReq req) {

        // 配置啟動流程 EmpCode 將會記錄誰啟用流程
        Authentication.setAuthenticatedUserId(req.getEmpCode());

        // 啟動流程(by key & last version)
        ProcessDefinition processDefinition = repositoryService.createProcessDefinitionQuery()
                .processDefinitionKey(req.getProcessDefinitionKey())
                .latestVersion()
                .singleResult();

        Map<String, Object> variables = new ConcurrentHashMap<>();
        if (MapUtils.isNotEmpty(req.getParamMap())) {
            variables.putAll(req.getParamMap());
        }

        Map<String, Object> beanMap = getBeanMap(req);
        if (MapUtils.isNotEmpty(beanMap)) {
            for (Map.Entry<String, Object> entry : beanMap.entrySet()) {
                if (StringUtils.isNotBlank(entry.getKey()) && Objects.nonNull(entry.getValue())) {
                    variables.put(entry.getKey(), entry.getValue());
                }
            }
        }

        ProcessInstance processInstance = runtimeService
                .startProcessInstanceById(processDefinition.getId(), variables);

        ActivitiStartProcessResp.ActStartProcessResData res = new ActivitiStartProcessResp.ActStartProcessResData();
        res.setProcessInstanceId(processInstance.getProcessInstanceId());
        // (Legacy) 系統回傳設定
        // setResTaskData(processInstance.getProcessInstanceId(), req, res);
        List<Task> taskList = taskService.createTaskQuery()
                .processInstanceId(processInstance.getProcessInstanceId())
                .list();
        if (CollectionUtils.isNotEmpty(taskList)) {
            res.setTaskId(taskList.get(0).getId());
            res.setTaskName(taskList.get(0).getName());
        }

        // 母流程，增加寫入「子母流程關系紀錄表」
        String procInstId = res.getProcessInstanceId();
        String procDefId = processInstance.getProcessDefinitionId();
        Date startTIme = processInstance.getStartTime();
        bpmProcinstInfoRepository.save(new BpmProcinstInfo(procInstId, procDefId, procInstId, procDefId, null, null, startTIme, null));

        return res;
    }

    @Override
    public List<ActivitiTaskVo> completeTask(ActivitiCompleteTaskReq activitiCompleteTaskReq) {

        List<ActivitiTaskVo> activitiTaskVoList = new ArrayList<>();

        String empCode = activitiCompleteTaskReq.getEmpCode();
        Authentication.setAuthenticatedUserId(empCode);

        Task task = taskService.createTaskQuery()
                .taskId(activitiCompleteTaskReq.getTaskId())
                .singleResult();

        // 若 查無任務 且 歷史案件不為空，則返回錯誤訊息: 此案件已被審核
        if (task == null) {
            HistoricTaskInstance his = historyService.createHistoricTaskInstanceQuery().taskId(activitiCompleteTaskReq.getTaskId()).finished().singleResult();
            if (his != null) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error(BPMExceptionStatus.APPROVED_ERROR.msg() + "! TaskId: " + activitiCompleteTaskReq.getTaskId() + ", completeTask complete");
                }
                throw new BPMException(BPMExceptionStatus.APPROVED_ERROR.msg(), BPMExceptionStatus.APPROVED_ERROR, HttpStatus.BAD_REQUEST.value(), 3);
            }
        } else {

            // 若判斷後權限不足, 則返回錯誤訊息: 沒有審核權限
            if (!StringUtils.equals(task.getAssignee(), activitiCompleteTaskReq.getEmpCode())) {

                List<String> thisTaskIds = new ArrayList<>();
                thisTaskIds.add(activitiCompleteTaskReq.getTaskId());

                Map<String, Map<String, List<String>>> thisCandidateMap = activitiCommonService.getCandidateListByTaskIds(thisTaskIds);
                List<String> candidateUserList = MapUtils.getObject(MapUtils.getObject(thisCandidateMap, ActivitiConst.CANDIDATE_USER), activitiCompleteTaskReq.getTaskId());
                List<String> candidateGroupList = MapUtils.getObject(MapUtils.getObject(thisCandidateMap, ActivitiConst.CANDIDATE_GROUP), activitiCompleteTaskReq.getTaskId());
                boolean candidateUserFlag = !(CollectionUtils.isNotEmpty(candidateUserList) && candidateUserList.contains(activitiCompleteTaskReq.getEmpCode()));
                boolean candidateGroupFlag = !(CollectionUtils.isNotEmpty(candidateGroupList) && CollectionUtils.isNotEmpty(activitiCompleteTaskReq.getCandidateGroups()) && CollectionUtils.containsAny(candidateGroupList, activitiCompleteTaskReq.getCandidateGroups()));
                if (candidateUserFlag && candidateGroupFlag) {
                    throw new BPMException(BPMExceptionStatus.PERMISSION_DENIED.msg(), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value(), 2);
                }
            }

            // 審核內容
            if (StringUtils.isNotEmpty(activitiCompleteTaskReq.getComment())) {
                taskService.addComment(task.getId(), task.getProcessInstanceId(), activitiCompleteTaskReq.getComment());
            }

            taskService.complete(task.getId(), activitiCompleteTaskReq.getParamMap());

            // 查詢下一位(或多位)審核者。先由子母流程關聯表取得所有流程實代號，再查出所有待處理任務
            // 由子母流程關聯表取得所有流程實代號
            List<BpmProcinstInfo> bpmProcinstInfoList = bpmProcinstInfoRepository.findByProcInstIdWithSameMainProcInstId(task.getProcessInstanceId());
            Map<String, BpmProcinstInfo> bpmProcinstInfoMap = new HashMap<>();
            List<String> procInstIdList = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(bpmProcinstInfoList)) {
                for (BpmProcinstInfo bpmProcinstInfo : bpmProcinstInfoList) {
                    bpmProcinstInfoMap.put(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo);
                    procInstIdList.add(bpmProcinstInfo.getProcInstId());
                }
            }

            // 查出所有待處理任務
            List<Task> taskList = null;
            if (CollectionUtils.isNotEmpty(procInstIdList)) {
                taskList = taskService.createTaskQuery().processInstanceIdIn(procInstIdList).list();
            }

            if (CollectionUtils.isNotEmpty(taskList)) {

                // 彙整所有任務的taskId清單
                List<String> taskIds = new ArrayList<>();
                taskList.forEach(activitiTask -> {
                    if (!taskIds.contains(activitiTask.getId())) {
                        taskIds.add(activitiTask.getId());
                    }
                });

                Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);

                taskList.forEach(activitiTask -> {
                    BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoMap.get(activitiTask.getProcessInstanceId());
                    ActivitiTaskVo vo = null;
                    if (bpmProcinstInfo != null) {
                        vo = new ActivitiTaskVo(activitiTask, activitiCommonService.getCandidateGroupByTaskId(candidateMap, activitiTask.getId()), activitiCommonService.getCandidateUserByTaskId(candidateMap, activitiTask.getId()), bpmProcinstInfo);
                    } else {
                        vo = new ActivitiTaskVo(activitiTask, activitiCommonService.getCandidateGroupByTaskId(candidateMap, activitiTask.getId()), activitiCommonService.getCandidateUserByTaskId(candidateMap, activitiTask.getId()));
                    }
                    activitiTaskVoList.add(vo);
                });
            }
        }

        return activitiTaskVoList;
    }

    @Override
    public List<ActivitiTaskVo> claimTask(ActivitiClaimTaskReq activitiClaimTaskReq) {

        List<ActivitiTaskVo> activitiTaskVoList = new ArrayList<>();

        String empCode = activitiClaimTaskReq.getEmpCode();
        String taskId = activitiClaimTaskReq.getTaskId();

        Authentication.setAuthenticatedUserId(empCode);

        taskService.claim(taskId, empCode);

        Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(ListUtil.toList(taskId));

        Task task = taskService.createTaskQuery()
                .taskId(activitiClaimTaskReq.getTaskId())
                .singleResult();

        BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(task.getProcessInstanceId());
        ActivitiTaskVo vo = new ActivitiTaskVo(
                task,
                activitiCommonService.getCandidateGroupByTaskId(candidateMap, task.getId()),
                activitiCommonService.getCandidateUserByTaskId(candidateMap, task.getId()),
                bpmProcinstInfo
        );

        activitiTaskVoList.add(vo);

        return activitiTaskVoList;
    }

    @Override
    public boolean terminateProcess(ActivitiTerminateProcessReq activitiTerminateProcessReq) {

        boolean result = false;

        if (StringUtils.isBlank(activitiTerminateProcessReq.getDeleteReason()) && LOGGER.isErrorEnabled()) {
            LOGGER.error("processInstanceId: {}, deleteReason: {}", activitiTerminateProcessReq.getProcessInstanceId(), "NULL");
        }

        BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(activitiTerminateProcessReq.getProcessInstanceId());
        if (null == bpmProcinstInfo || StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getMainProcInstId())) {
            runtimeService.deleteProcessInstance(activitiTerminateProcessReq.getProcessInstanceId(), activitiTerminateProcessReq.getDeleteReason());
            result = true;
        } else {
            if (!StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getMainProcInstId()) && LOGGER.isErrorEnabled()) {
                LOGGER.error("processInstanceId: {}, error: {}", activitiTerminateProcessReq.getProcessInstanceId(), "Process is not the main.");
            }
        }

        return result;
    }

    @Override
    public boolean addCandidateGroup(ActivitiAddCandidateGroupReq activitiAddCandidateGroupReq) {

        boolean result = false;

        taskService.addCandidateGroup(activitiAddCandidateGroupReq.getTaskId(), activitiAddCandidateGroupReq.getGroup());
        result = true;

        return result;
    }

    @Override
    public boolean deleteCandidateGroup(ActivitiDeleteCandidateGroupReq activitiDeleteCandidateGroupReq) {

        boolean result = false;

        taskService.deleteCandidateGroup(activitiDeleteCandidateGroupReq.getTaskId(), activitiDeleteCandidateGroupReq.getCandidateGroup());
        result = true;

        return result;
    }

    @Override
    public boolean addCandidateUser(ActivitiAddCandidateUserReq activitiAddCandidateUserReq) {

        boolean result = false;

        taskService.addCandidateUser(activitiAddCandidateUserReq.getTaskId(), activitiAddCandidateUserReq.getUser());
        result = true;

        return result;
    }

    @Override
    public boolean deleteCandidateUser(ActivitiDeleteCandidateUserReq activitiDeleteCandidateUserReq) {

        boolean result = false;

        taskService.deleteCandidateUser(activitiDeleteCandidateUserReq.getTaskId(), activitiDeleteCandidateUserReq.getCandidateUser());
        result = true;

        return result;
    }

    @Override
    public boolean setAssignee(ActivitiSetAssigneeReq activitiSetAssigneeReq) {

        boolean result = false;

        taskService.setAssignee(activitiSetAssigneeReq.getTaskId(), activitiSetAssigneeReq.getAssignee());
        result = true;

        return result;
    }

    @Override
    public boolean addComment(ActivitiAddCommentReq activitiAddCommentReq) {

        boolean result = false;

        Authentication.setAuthenticatedUserId(activitiAddCommentReq.getEmpCode());

        Task task = taskService.createTaskQuery()
                .taskId(activitiAddCommentReq.getTaskId())
                .singleResult();
        taskService.addComment(activitiAddCommentReq.getTaskId(), task.getProcessInstanceId(), activitiAddCommentReq.getComment());
        result = true;

        return result;
    }
}
