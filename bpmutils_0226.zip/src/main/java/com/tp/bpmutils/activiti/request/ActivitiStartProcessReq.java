package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.Map;

import static io.swagger.v3.oas.annotations.media.Schema.AccessMode.READ_ONLY;

/**
 * 啟動流程請求
 *
 * @author tp
 */
@Schema(description = "啟動流程請求")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiStartProcessReq {

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"empCode", "processDefinitionKey"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程圖定義 Id
     */
    @Schema(description = "流程圖定義 Id：PendingItem", required = true)
    private String processDefinitionKey;
    /**
     * 員工編號
     */
    @Schema(description = "員工編號：1", required = true)
    private String empCode;

    /**
     * 流程所需參數
     */
    @Schema(description = "流程所需參數", implementation = Map.class)
    private Map paramMap;

    /**
     * Get Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    /**
     * Get Multi Choice Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getProcessDefinitionKey() {
        return processDefinitionKey;
    }

    public void setProcessDefinitionKey(String processDefinitionKey) {
        this.processDefinitionKey = processDefinitionKey;
    }

    public String getEmpCode() {
        return empCode;
    }

    public void setEmpCode(String empCode) {
        this.empCode = empCode;
    }

    public Map getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map paramMap) {
        this.paramMap = paramMap;
    }
}
