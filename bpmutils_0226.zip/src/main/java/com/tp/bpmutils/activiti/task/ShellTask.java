package com.tp.bpmutils.activiti.task;

import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import com.tp.bpmutils.common.util.DataUtil;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.Expression;
import org.activiti.engine.delegate.JavaDelegate;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

/**
 * BPM ShellTask
 *
 * @author tp
 */
public class ShellTask implements JavaDelegate {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ShellTask.class);

    /**
     * 退出狀態變數名稱
     */
    private static final String EXIT_CODE = "exitCode";

    /**
     * 執行命令所在目錄
     */
    private transient Expression baseShellDir;

    /**
     * 命令陣列
     */
    private transient Expression command;

    /**
     * 日誌輸出字符集
     */
    private transient Expression outputCharset;

    /**
     * 輸出變數名稱
     */
    private transient Expression outputVariable;

    /**
     * 錯誤訊息變數名稱
     */
    private transient Expression errorMessageVariable;

    /**
     * 允許執行的 commond 類型
     */
    protected static final String[] ALLOW_COMMAND = {
            "sh", "python"
    };

    @Override
    public void execute(DelegateExecution execution) {

        /**
         * Not need to force baseDir
         *  if (baseShellDir == null) {
         *      throw new RuntimeException("baseShellDir not found.");
         *  }
         */

        if (command == null) {
            throw new BPMException("cmd not found.", BPMExceptionStatus.SYSTEM_ERROR);
        }

        // List<String> cmdList = JSON.parseArray(command.getValue(execution).toString(), String.class);
        List<String> cmdList = DataUtil.stringToBean(command.getValue(execution).toString(), List.class);

        if (StringUtils.equalsAny(cmdList.get(0), ALLOW_COMMAND)) {
            throw new BPMException("command不符合規定", BPMExceptionStatus.SYSTEM_ERROR);
        }

        if (!paramsIsSafe(cmdList)) {
            //ex: cd '/opt';rm -rf '/*'
            throw new BPMException("command不安全", BPMExceptionStatus.SYSTEM_ERROR);
        }

        String charset = outputCharset == null ? "utf8" : outputCharset.getValue(execution).toString();
        String shellDir = baseShellDir == null ? null : baseShellDir.getValue(execution).toString();

        try {
            ExecCmdResult execCmdResult = execCommand(
                    shellDir,
                    cmdList.toArray(new String[0]),
                    charset
            );

            if (outputVariable != null) {
                String outVarName = outputVariable.getValue(execution).toString();
                execution.setVariable(outVarName, execCmdResult.getOutputString());
            }

            execution.setVariable(EXIT_CODE, execCmdResult.getExitCode());

        } catch (Exception e) {
            String errorMessage = e.getMessage();
            setErrorDetailsForTaskExecution(execution, errorMessage);
            LOGGER.error(errorMessage, e);
            throw new BPMException(errorMessage, BPMExceptionStatus.SYSTEM_ERROR, e);
        }
    }

    private void setErrorDetailsForTaskExecution(DelegateExecution execution, String errorMessage) {
        if (errorMessageVariable != null) {
            execution.setVariable(errorMessageVariable.getValue(execution).toString(), errorMessage);
        }
    }

    public void setOutputVariable(Expression outputVariable) {
        this.outputVariable = outputVariable;
    }

    public void setErrorMessageVariable(Expression errorMessageVariable) {
        this.errorMessageVariable = errorMessageVariable;
    }

    private ExecCmdResult execCommand(String baseShellDir, String[] cmd, String charsetName) throws InterruptedException, IOException {
        ExecCmdResult execCmdResult = new ExecCmdResult();

        File dir = null;
        if (!StringUtils.isNotBlank(baseShellDir)) {
            dir = new File(baseShellDir);
        }

        Process process = Runtime.getRuntime().exec(cmd, null, dir);
        StringBuilder sb = new StringBuilder();

        try (BufferedReader input = new BufferedReader(
                new InputStreamReader(process.getInputStream(), charsetName))) {
            /**
             * Fix from code:
             *  String line = "";
             *  while ((line = input.readLine()) != null) {
             *      sb.append(line);
             *  }
             */
            input.lines().forEachOrdered(
                    s -> {
                        sb.append(s);
                    }
            );
        }

        int value = process.waitFor();
        execCmdResult.setExitCode(value);
        execCmdResult.setOutputString(sb.toString());

        return execCmdResult;
    }

    /**
     * 检测参数是否合法
     *
     * @param params 参数
     * @return
     */
    private static boolean paramsIsSafe(List<String> params) {
        if (CollectionUtils.isEmpty(params)) {
            return false;
        }
        for (String param : params) {
            String safeParam = getSafeParam(param);
            if (safeParam.length() != param.length()) {
                return false;
            }
        }
        return true;
    }

    /**
     * 返回合法的参数
     *
     * @param param 参数
     * @return
     */
    private static String getSafeParam(String param) {
        StringBuilder safeParam = new StringBuilder();
        String whiteCharList = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890-=[]\\',./ ~@#%^*()_+\"{}:?";
        char[] safeParamChars = param.toCharArray();

        for (char safeParamChar : safeParamChars) {
            int whiteListIndex = whiteCharList.indexOf(safeParamChar);
            if (-1 == whiteListIndex) {
                return safeParam.toString();
            }
            safeParam.append(whiteCharList.charAt(whiteListIndex));
        }
        return safeParam.toString();
    }

    /**
     * 執行指令結果
     *
     * @author tp
     */
    private static class ExecCmdResult {

        /**
         * 輸出內容
         */
        private String outputString;

        /**
         * 退出狀態
         */
        private int exitCode;

        public String getOutputString() {
            return outputString;
        }

        /**
         * 設定輸出內容
         *
         * @param outputString
         * @return
         */
        public ExecCmdResult setOutputString(String outputString) {
            this.outputString = outputString;
            return this;
        }

        public int getExitCode() {
            return exitCode;
        }

        /**
         * 設定退出狀態
         *
         * @param exitCode
         * @return
         */
        public ExecCmdResult setExitCode(int exitCode) {
            this.exitCode = exitCode;
            return this;
        }
    }

}
