package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 流程檔案上傳部署回覆
 *
 * @author tp
 */
@Schema(description = "流程檔案上傳部署回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiDeployBPMFileResp {

    /**
     * 流程部署定義資訊
     */
    @Schema(description = "流程部署定義資訊")
    private BPMProcessDefinition data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiDeployBPMFileResp success(BPMProcessDefinition data) {
        ActivitiDeployBPMFileResp apiSuccess = new ActivitiDeployBPMFileResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public BPMProcessDefinition getData() {
        return data;
    }

    public void setData(BPMProcessDefinition data) {
        this.data = data;
    }

    /**
     * 部署流程資訊
     */
    @JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
    @Schema(description = "部署流程資訊")
    public static class BPMProcessDefinition {

        /**
         * 流程定義編號
         */
        @Schema(description = "流程定義編號")
        private String processDefinitionId;

        public String getProcessDefinitionId() {
            return processDefinitionId;
        }

        public void setProcessDefinitionId(String processDefinitionId) {
            this.processDefinitionId = processDefinitionId;
        }
    }
}
