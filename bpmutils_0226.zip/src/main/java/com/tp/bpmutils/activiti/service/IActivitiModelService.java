package com.tp.bpmutils.activiti.service;

import com.tp.bpmutils.activiti.request.ActivitiDeployProcessReq;
import com.tp.bpmutils.activiti.request.ActivitiProcessActiveTasksReq;
import com.tp.bpmutils.activiti.request.ActivitiQueryProcessInstanceReq;
import com.tp.bpmutils.activiti.response.ActivitiDeployProcessResp;
import com.tp.bpmutils.activiti.response.ActivitiProcessActiveTasksResp;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 處理 Activiti Model 服務介面
 *
 * @author tp
 */
public interface IActivitiModelService {

    /**
     * DeployProcess
     *
     * @param file
     * @return
     */
    String deployProcess(MultipartFile file);

    /**
     * Deploy Resource Files
     *
     * @param req
     * @return
     */
    ActivitiDeployProcessResp.ActivitiDeployProcessRespData deployResourceFiles(ActivitiDeployProcessReq req);

    /**
     * Get Process Image
     *
     * @param req
     * @return
     */
    ActivitiMainSubVo getProcessImg(ActivitiQueryProcessInstanceReq req);

    /**
     * 查詢流程定義任務
     *
     * @param activitiProcessActiveTasksReq
     * @return
     */
    List<ActivitiProcessActiveTasksResp.ElementInfo> getProcessActiveTasks(ActivitiProcessActiveTasksReq activitiProcessActiveTasksReq);
}
