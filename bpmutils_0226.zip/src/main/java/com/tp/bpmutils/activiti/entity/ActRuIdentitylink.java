package com.tp.bpmutils.activiti.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Runtime Identitylink entity
 */
@Entity
public class ActRuIdentitylink {

    /**
     * ID
     */
    @Id
    @Column(name="ID_")
    private String id;

    /**
     * 鎖
     */
    @Column(name="REV_")
    private Integer rev;

    /**
     * 候選角色
     */
    @Column(name="GROUP_ID_")
    private String groupId;

    /**
     * 類型
     */
    @Column(name="TYPE_")
    private String type;

    /**
     * 人員ID
     */
    @Column(name="USER_ID_")
    private String userId;

    /**
     * 任務編號
     */
    @Column(name="TASK_ID_")
    private String taskId;

    /**
     * 流程實例代號
     */
    @Column(name="PROC_INST_ID_")
    private String procInstId;

    /**
     * 流程定義代號
     */
    @Column(name="PROC_DEF_ID_")
    private String procDefId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getRev() {
        return rev;
    }

    public void setRev(Integer rev) {
        this.rev = rev;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(String procInstId) {
        this.procInstId = procInstId;
    }

    public String getProcDefId() {
        return procDefId;
    }

    public void setProcDefId(String procDefId) {
        this.procDefId = procDefId;
    }
}
