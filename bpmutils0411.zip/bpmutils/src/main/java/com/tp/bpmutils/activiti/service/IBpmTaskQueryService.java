package com.tp.bpmutils.activiti.service;

import org.activiti.engine.task.Task;

import java.util.List;

/**
 * BPM TaskQuery 服務介面
 */
public interface IBpmTaskQueryService {

    /**
     * Get Task List by CandidateUsers
     *
     * @param candidateUsers
     * @return
     */
    List<Task> taskCandidateUserIn(List<String> candidateUsers);

    /**
     * Get Task List by CandidateGroups
     *
     * @param candidateGroups
     * @return
     */
    List<Task> taskCandidateGroupLikeIn(List<String> candidateGroups);
}
