package com.tp.bpmutils.activiti.vo;

import com.tp.bpmutils.activiti.entity.ActHiComment;
import com.tp.bpmutils.common.util.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.task.Comment;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

/**
 * 歷史任務資訊
 */
@Schema(description = "歷史任務資訊")
public class ActivitiHistoryTaskInstanceVo extends ActivitiBaseVo {

    /**
     *
     */
    private static final long serialVersionUID = 7694023323531772457L;

    /**
     * 任務編號
     */
    @Schema(description = "任務編號")
    private String taskId;

    /**
     * 任務名稱
     */
    @Schema(description = "任務名稱")
    private String nodeName;

    /**
     * 員工編號
     */
    @Schema(description = "員工編號")
    private String userId;

    /**
     * 備註
     */
    @Schema(description = "備註")
    private String comment;

    /**
     * 䢖立時間
     */
    @Schema(description = "䢖立時間")
    private String time;

    /**
     * 流程實例代號
     */
    @Schema(description = "流程實例代號")
    private String processInstanceId;

    /**
     * 流程定義編號
     */
    @Schema(description = "流程定義編號")
    private String processDefinitionId;

    /**
     * 主流程實例代號
     */
    @Schema(description = "主流程實例代號")
    private String mainProcInstId;

    /**
     * 主流程定義編號
     */
    @Schema(description = "主流程定義編號")
    private String mainProcDefId;

    /**
     * 上一階流程實例代號
     */
    @Schema(description = "上一階流程實例代號")
    private String sourceProcInstId;

    /**
     * 上一階流程定義編號
     */
    @Schema(description = "上一階流程定義編號")
    private String sourceProcDefId;

    /**
     * ActivitiHistoryTaskInstanceVo 1
     */
    public ActivitiHistoryTaskInstanceVo() {
        super();
    }

    /**
     * ActivitiHistoryTaskInstanceVo 2
     *
     * @param comment
     * @param his
     */
    public ActivitiHistoryTaskInstanceVo(Comment comment, HistoricActivityInstance his) {
        this(comment, his, his.getProcessInstanceId(), his.getProcessDefinitionId(), null, null);
    }

    /**
     * ActivitiHistoryTaskInstanceVo 3
     *
     * @param comment
     * @param his
     * @param mainProcInstId
     * @param mainProcDefId
     * @param sourceProcInstId
     * @param sourceProcDefId
     */
    public ActivitiHistoryTaskInstanceVo(Comment comment, HistoricActivityInstance his, String mainProcInstId, String mainProcDefId, String sourceProcInstId, String sourceProcDefId) {
        super();
        this.taskId = comment.getTaskId();
        this.nodeName = his.getActivityId();
        this.userId = comment.getUserId();
        this.comment = comment.getFullMessage();
        this.time = DateUtil.dateToString(comment.getTime(), DateUtil.PATTEN_YEAR_MONTH_DAY_FULL_TIME);
        this.processInstanceId = his.getProcessInstanceId();
        this.processDefinitionId = his.getProcessDefinitionId();
        this.mainProcInstId = mainProcInstId;
        this.mainProcDefId = mainProcDefId;
        this.sourceProcInstId = sourceProcInstId;
        this.sourceProcDefId = sourceProcDefId;
    }

    /**
     * ActivitiHistoryTaskInstanceVo 4
     *
     * @param actHiComment
     * @param his
     * @param mainProcInstId
     * @param mainProcDefId
     * @param sourceProcInstId
     * @param sourceProcDefId
     */
    public ActivitiHistoryTaskInstanceVo(ActHiComment actHiComment, HistoricActivityInstance his, String mainProcInstId, String mainProcDefId, String sourceProcInstId, String sourceProcDefId) throws IOException {
        super();
        this.taskId = actHiComment.getTaskId();
        this.nodeName = his.getActivityId();
        this.userId = actHiComment.getUserId();
        this.comment = IOUtils.toString(actHiComment.getFullMsg(), StandardCharsets.UTF_8.name());
        this.time = DateUtil.dateToString(actHiComment.getTime(), DateUtil.PATTEN_YEAR_MONTH_DAY_FULL_TIME);
        this.processInstanceId = his.getProcessInstanceId();
        this.processDefinitionId = his.getProcessDefinitionId();
        this.mainProcInstId = mainProcInstId;
        this.mainProcDefId = mainProcDefId;
        this.sourceProcInstId = sourceProcInstId;
        this.sourceProcDefId = sourceProcDefId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getNodeName() {
        return nodeName;
    }

    public void setNodeName(String nodeName) {
        this.nodeName = nodeName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getProcessInstanceId() {
        return processInstanceId;
    }

    public void setProcessInstanceId(String processInstanceId) {
        this.processInstanceId = processInstanceId;
    }

    public String getProcessDefinitionId() {
        return processDefinitionId;
    }

    public void setProcessDefinitionId(String processDefinitionId) {
        this.processDefinitionId = processDefinitionId;
    }

    public String getMainProcInstId() {
        return mainProcInstId;
    }

    public void setMainProcInstId(String mainProcInstId) {
        this.mainProcInstId = mainProcInstId;
    }

    public String getMainProcDefId() {
        return mainProcDefId;
    }

    public void setMainProcDefId(String mainProcDefId) {
        this.mainProcDefId = mainProcDefId;
    }

    public String getSourceProcInstId() {
        return sourceProcInstId;
    }

    public void setSourceProcInstId(String sourceProcInstId) {
        this.sourceProcInstId = sourceProcInstId;
    }

    public String getSourceProcDefId() {
        return sourceProcDefId;
    }

    public void setSourceProcDefId(String sourceProcDefId) {
        this.sourceProcDefId = sourceProcDefId;
    }
    
}
