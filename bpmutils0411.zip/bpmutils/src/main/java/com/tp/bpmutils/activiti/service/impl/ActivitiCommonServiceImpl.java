package com.tp.bpmutils.activiti.service.impl;

import com.tp.bpmutils.activiti.entity.ActRuIdentitylink;
import com.tp.bpmutils.activiti.service.IActivitiCommonService;
import com.tp.bpmutils.activiti.service.repository.BpmRuIdentityLinkRepository;
import com.tp.bpmutils.common.constant.ActivitiConst;
import org.activiti.engine.HistoryService;
import org.activiti.engine.history.HistoricIdentityLink;
import org.activiti.engine.task.IdentityLinkType;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 處理 Activiti Common 服務實作
 *
 * @author tp
 */
@Service
public class ActivitiCommonServiceImpl implements IActivitiCommonService {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiCommonServiceImpl.class);

    /**
     * Activiti HistoryService
     */
    private final transient HistoryService historyService;

    /**
     * BPM runtime IdentityLink Repository
     */
    private final transient BpmRuIdentityLinkRepository bpmRuIdentityLinkRepository;

    /**
     * ActivitiCommonServiceImpl Constructor
     *
     * @param historyService
     * @param bpmRuIdentityLinkRepository
     */
    public ActivitiCommonServiceImpl(HistoryService historyService, BpmRuIdentityLinkRepository bpmRuIdentityLinkRepository) {
        this.historyService = historyService;
        this.bpmRuIdentityLinkRepository = bpmRuIdentityLinkRepository;
    }

    private List<ActRuIdentitylink> getIdentityLinkListByTaskIds(List<String> taskIds) {
        List<ActRuIdentitylink> identityLinkList = bpmRuIdentityLinkRepository.findByTaskIdIn(taskIds);
        return CollectionUtils.isNotEmpty(identityLinkList) ? identityLinkList : new ArrayList<>();
    }

    @Override
    public Map<String, Map<String, List<String>>> getCandidateListByTaskIds(List<String> taskIds) {

        if (CollectionUtils.isEmpty(taskIds)) {
            return null;
        }

        Map<String, Map<String, List<String>>> result = new ConcurrentHashMap<>();

        try {
            List<ActRuIdentitylink> identityLinkList = getIdentityLinkListByTaskIds(taskIds);

            if (CollectionUtils.isNotEmpty(identityLinkList)) {
                for (ActRuIdentitylink identityLink : identityLinkList) {
                    if (StringUtils.equals(identityLink.getType(), IdentityLinkType.CANDIDATE)) {
                        if (StringUtils.isBlank(identityLink.getGroupId()) && StringUtils.isBlank(identityLink.getUserId())) {
                            continue;
                        }
                        if (StringUtils.isNotBlank(identityLink.getGroupId())) {
                            Map<String, List<String>> groupMap = MapUtils.getObject(result, ActivitiConst.CANDIDATE_GROUP, new ConcurrentHashMap<>());
                            List<String> group = MapUtils.getObject(groupMap, identityLink.getTaskId(), new ArrayList<>());
                            group.add(identityLink.getGroupId());
                            groupMap.put(identityLink.getTaskId(), group);

                            result.put(ActivitiConst.CANDIDATE_GROUP, groupMap);
                        } else {
                            Map<String, List<String>> userMap = MapUtils.getObject(result, ActivitiConst.CANDIDATE_USER, new ConcurrentHashMap<>());
                            List<String> user = MapUtils.getObject(userMap, identityLink.getTaskId(), new ArrayList<>());
                            user.add(identityLink.getUserId());
                            userMap.put(identityLink.getTaskId(), user);
                            result.put(ActivitiConst.CANDIDATE_USER, userMap);
                        }
                    }
                }
            }
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        return result;
    }

    @Override
    public Map<String, Map<String, StringBuilder>> getCandidateByTaskIds(List<String> taskIds) {

        if (CollectionUtils.isEmpty(taskIds)) {
            return null;
        }

        Map<String, Map<String, StringBuilder>> result = new ConcurrentHashMap<>();

        try {
            List<ActRuIdentitylink> identityLinkList = getIdentityLinkListByTaskIds(taskIds);
            if (CollectionUtils.isNotEmpty(identityLinkList)) {
                for (ActRuIdentitylink identityLink : identityLinkList) {
                    if (StringUtils.equals(identityLink.getType(), IdentityLinkType.CANDIDATE)) {
                        if (StringUtils.isBlank(identityLink.getGroupId()) && StringUtils.isBlank(identityLink.getUserId())) {
                            continue;
                        }
                        if (StringUtils.isNotBlank(identityLink.getGroupId())) {
                            Map<String, StringBuilder> groupMap = MapUtils.getObject(result, ActivitiConst.CANDIDATE_GROUP, new ConcurrentHashMap<>());
                            StringBuilder group = MapUtils.getObject(groupMap, identityLink.getTaskId(), new StringBuilder());
                            if (group.length() > 0) {
                                group.append(',');
                            }
                            group.append(identityLink.getGroupId());
                            groupMap.put(identityLink.getTaskId(), group);
                            result.put(ActivitiConst.CANDIDATE_GROUP, groupMap);
                        } else {
                            Map<String, StringBuilder> userMap = MapUtils.getObject(result, ActivitiConst.CANDIDATE_USER, new ConcurrentHashMap<>());
                            StringBuilder user = MapUtils.getObject(userMap, identityLink.getTaskId(), new StringBuilder());
                            if (user.length() > 0) {
                                user.append(',');
                            }
                            user.append(identityLink.getUserId());
                            userMap.put(identityLink.getTaskId(), user);
                            result.put(ActivitiConst.CANDIDATE_USER, userMap);
                        }
                    }
                }
            }
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        return result;
    }

    private List<HistoricIdentityLink> getHiIdentityLinkListByTaskIds(List<String> taskIds) {
        List<HistoricIdentityLink> identityLinkList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(taskIds)) {
            for (String taskId : taskIds) {
                List<HistoricIdentityLink> identityLinks = historyService.getHistoricIdentityLinksForTask(taskId);
                if (CollectionUtils.isNotEmpty(identityLinks)) {
                    identityLinkList.addAll(identityLinks);
                }
            }
        }
        return identityLinkList;
    }

    @Override
    public Map<String, Map<String, StringBuilder>> getHiCandidateByTaskIds(List<String> taskIds) {

        if (CollectionUtils.isEmpty(taskIds)) {
            return null;
        }

        Map<String, Map<String, StringBuilder>> result = new ConcurrentHashMap<>();

        try {
            List<HistoricIdentityLink> historicIdentityLinkList = getHiIdentityLinkListByTaskIds(taskIds);
            if (CollectionUtils.isNotEmpty(historicIdentityLinkList)) {
                for (HistoricIdentityLink identityLink : historicIdentityLinkList) {
                    if (StringUtils.equals(identityLink.getType(), IdentityLinkType.CANDIDATE)) {
                        if (StringUtils.isBlank(identityLink.getGroupId()) && StringUtils.isBlank(identityLink.getUserId())) {
                            continue;
                        }
                        if (StringUtils.isNotBlank(identityLink.getGroupId())) {
                            Map<String, StringBuilder> groupMap = MapUtils.getObject(result, ActivitiConst.CANDIDATE_GROUP, new ConcurrentHashMap<>());
                            StringBuilder group = MapUtils.getObject(groupMap, identityLink.getTaskId(), new StringBuilder());
                            if (group.length() > 0) {
                                group.append(',');
                            }
                            group.append(identityLink.getGroupId());
                            groupMap.put(identityLink.getTaskId(), group);
                            result.put(ActivitiConst.CANDIDATE_GROUP, groupMap);
                        } else {
                            Map<String, StringBuilder> userMap = MapUtils.getObject(result, ActivitiConst.CANDIDATE_USER, new ConcurrentHashMap<>());
                            StringBuilder user = MapUtils.getObject(userMap, identityLink.getTaskId(), new StringBuilder());
                            if (user.length() > 0) {
                                user.append(',');
                            }
                            user.append(identityLink.getUserId());
                            userMap.put(identityLink.getTaskId(), user);
                            result.put(ActivitiConst.CANDIDATE_USER, userMap);
                        }
                    }
                }
            }
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage());
            }
        }

        return result;
    }

    @Override
    public String getCandidateGroupByTaskId(Map<String, Map<String, StringBuilder>> candidateMap, String taskId) {
        Map<String, StringBuilder> candidateGroupMap = MapUtils.getObject(candidateMap, ActivitiConst.CANDIDATE_GROUP);
        return null != MapUtils.getObject(candidateGroupMap, taskId) ? MapUtils.getObject(candidateGroupMap, taskId).toString() : null;
    }

    @Override
    public String getCandidateUserByTaskId(Map<String, Map<String, StringBuilder>> candidateMap, String taskId) {
        Map<String, StringBuilder> candidateUserMap = MapUtils.getObject(candidateMap, ActivitiConst.CANDIDATE_USER);
        return null != MapUtils.getObject(candidateUserMap, taskId) ? MapUtils.getObject(candidateUserMap, taskId).toString() : null;
    }
}
