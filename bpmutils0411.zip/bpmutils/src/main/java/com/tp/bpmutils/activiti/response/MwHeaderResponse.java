package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.tp.bpmutils.activiti.request.MwHeader;
import com.tp.bpmutils.common.util.BPMApiResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;

/**
 * MwHeaderResponse
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MwHeaderResponse extends MwHeader {

    /**
     * 處理結果代碼
     */
    @JsonProperty("RETURNCODE")
    protected String returnCode;

    /**
     * 處理結果訊息
     */
    @JsonProperty("RETURNDESC")
    protected String returnDesc;

    /**
     * Constructor 1
     */
    public MwHeaderResponse() {
        super();
    }

    /**
     * Constructor 2
     *
     * @param mwHeader
     */
    public MwHeaderResponse(MwHeader mwHeader) {
        super();
        super.setMsgId(null != mwHeader && StringUtils.isNotBlank(mwHeader.getMsgId()) ? mwHeader.getMsgId() : "UNKNOW");
        super.setSourceChannel(null != mwHeader && StringUtils.isNotBlank(mwHeader.getSourceChannel()) ? mwHeader.getSourceChannel() : "UNKNOW");
        super.setTxnSeq(null != mwHeader && StringUtils.isNotBlank(mwHeader.getTxnSeq()) ? mwHeader.getTxnSeq() : "UNKNOW");
        this.setReturnCode(BPMApiResponse.CODE_SUCCESS);
        this.setReturnDesc(BPMApiResponse.MSG_SUCCESS);
    }

}
