package com.tp.bpmutils.common.exception;

import org.springframework.http.HttpStatus;

import java.io.Serializable;
import java.text.MessageFormat;

/**
 * BPM's Exception
 *
 * @author tp
 */
public class BPMException extends RuntimeException implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1580727815801395754L;

    /**
     * Result Msg
     */
    private String msg;

    /**
     * Result code
     */
    private int code = HttpStatus.INTERNAL_SERVER_ERROR.value();

    /**
     * Exception status
     */
    private BPMExceptionStatus status;

    /**
     * Result data code
     */
    private int rtnCode;

    /**
     * BPMException 1
     *
     * @param msg
     * @param status
     */
    public BPMException(String msg, BPMExceptionStatus status) {
        super(msg);
        this.msg = msg;
        this.status = status;
    }

    /**
     * BPMException 2
     *
     * @param msg
     * @param status
     * @param e
     */
    public BPMException(String msg, BPMExceptionStatus status, Throwable e) {
        super(msg, e);
        this.msg = msg;
        this.status = status;
    }

    /**
     * BPMException 3
     *
     * @param msg
     * @param status
     * @param code
     */
    public BPMException(String msg, BPMExceptionStatus status, int code) {
        super(msg);
        this.msg = msg;
        this.status = status;
        this.code = code;
    }

    /**
     * BPMException 4
     *
     * @param msg
     * @param status
     * @param code
     * @param e
     */
    public BPMException(String msg, BPMExceptionStatus status, int code, Throwable e) {
        super(msg, e);
        this.msg = msg;
        this.status = status;
        this.code = code;
    }

    /**
     * BPMException 5
     *
     * @param msg
     * @param status
     * @param code
     * @param rtnCode
     */
    public BPMException(String msg, BPMExceptionStatus status, int code, int rtnCode) {
        super(msg);
        this.msg = msg;
        this.status = status;
        this.code = code;
        this.rtnCode = rtnCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public BPMExceptionStatus getStatus() {
        return status;
    }

    public void setStatus(BPMExceptionStatus status) {
        this.status = status;
    }

    public int getRtnCode() {
        return rtnCode;
    }

    public void setRtnCode(int rtnCode) {
        this.rtnCode = rtnCode;
    }

    /**
     * Process unknow msg
     *
     * @param errorParameter
     * @return
     */
    public static String getProcessUnknowError(String errorParameter) {
        return MessageFormat.format(BPMExceptionStatus.PROCESS_UNKNOW_ERROR.msg(), errorParameter);
    }

    /**
     * Task unknow msg
     *
     * @param errorParameter
     * @return
     */
    public static String getTaskUnknowError(String errorParameter) {
        return MessageFormat.format(BPMExceptionStatus.TASK_UNKNOW_ERROR.msg(), errorParameter);
    }

    /**
     * Input Parameter msg
     *
     * @param errorParameter
     * @return
     */
    public static String getInputParameterError(String errorParameter) {
        return MessageFormat.format(BPMExceptionStatus.INPUT_PARAMETER_ERROR.msg(), errorParameter);
    }
}
