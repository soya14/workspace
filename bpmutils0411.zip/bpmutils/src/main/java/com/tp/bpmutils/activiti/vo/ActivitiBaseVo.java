package com.tp.bpmutils.activiti.vo;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.io.Serializable;

/**
 * Activiti Base Vo
 */
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiBaseVo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 2140684516258819744L;
}
