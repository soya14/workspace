package com.tp.bpmutils.activiti.service;

import org.activiti.engine.history.HistoricActivityInstance;

import java.util.List;
import java.util.Map;

/**
 * BPM HistoricActivityInstanceQuery 服務介面
 */
public interface IBpmHistoricActivityInstanceQueryService {

    /**
     * Get HistoricActivityInstance List (EndTime is null) by ProcInstIds
     *
     * @param procInstIds
     * @return
     */
    List<HistoricActivityInstance> findByProcInstIdInAndEndTimeIsNull(List<String> procInstIds);

    /**
     * Get Map HistoricActivityInstance List by ProcInstIds
     *
     * @param procInstIds
     * @return
     */
    Map<String, List<HistoricActivityInstance>> findMapByProcInstIdInAndEndTimeIsNull(List<String> procInstIds);

    /**
     * Get HistoricActivityInstance List by ProcInstIds
     *
     * @param procInstIds
     * @return
     */
    List<HistoricActivityInstance> findByProcInstIdIn(List<String> procInstIds);
}
