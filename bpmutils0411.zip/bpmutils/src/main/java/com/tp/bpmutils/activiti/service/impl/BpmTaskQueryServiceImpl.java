package com.tp.bpmutils.activiti.service.impl;

import com.tp.bpmutils.activiti.service.IBpmTaskQueryService;
import org.activiti.engine.ManagementService;
import org.activiti.engine.TaskService;
import org.activiti.engine.task.NativeTaskQuery;
import org.activiti.engine.task.Task;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * BPM TaskQuery 服務實作
 */
@Service
public class BpmTaskQueryServiceImpl implements IBpmTaskQueryService {

    /**
     * Activiti TaskService
     */
    private final transient TaskService taskService;

    /**
     * Activiti ManagementService
     */
    private final transient ManagementService managementService;

    /**
     * BpmTaskQueryServiceImpl Constructor
     *
     * @param taskService
     * @param managementService
     */
    public BpmTaskQueryServiceImpl(TaskService taskService, ManagementService managementService) {
        this.taskService = taskService;
        this.managementService = managementService;
    }

    @Override
    public List<Task> taskCandidateUserIn(List<String> candidateUsers) {

        String sql = "select distinct RES.* from {0} RES inner join {1} I on I.TASK_ID_ = RES.ID_ WHERE RES.ASSIGNEE_ is null and I.TYPE_ = ''candidate'' and ( I.USER_ID_ in ({2}) ) order by RES.ID_ asc";
        String tableName0 = managementService.getTableName(Task.class);
        String tableName1 = "ACT_RU_IDENTITYLINK"; // managementService.getTableName(ActRuIdentitylink.class);
        List nameOfUserIds = new ArrayList();
        String nameOfUserId = "userId{0}";

        for (int i = 0; i < candidateUsers.size(); i++) {
            nameOfUserIds.add("#{" + MessageFormat.format(nameOfUserId, i) + "}");
        }
        NativeTaskQuery nativeTaskQuery = taskService.createNativeTaskQuery().sql(MessageFormat.format(sql, tableName0, tableName1, String.join(",", nameOfUserIds)));
        for (int i = 0; i < nameOfUserIds.size(); i++) {
            nativeTaskQuery.parameter(MessageFormat.format(nameOfUserId, i), candidateUsers.get(i));
        }

        return nativeTaskQuery.list();
    }

    @Override
    public List<Task> taskCandidateGroupLikeIn(List<String> candidateGroups) {

        String sql = "select distinct RES.* from {0} RES inner join {1} I on I.TASK_ID_ = RES.ID_ WHERE RES.ASSIGNEE_ is null and I.TYPE_ = ''candidate'' and ({2}) order by RES.ID_ asc";
        String tableName0 = managementService.getTableName(Task.class);
        String tableName1 = "ACT_RU_IDENTITYLINK"; // managementService.getTableName(ActRuIdentitylink.class);
        List nameOfGroupIds = new ArrayList();
        String nameOfGroupId = "groupId{0}";

        for (int i = 0; i < candidateGroups.size(); i++) {
            nameOfGroupIds.add("I.GROUP_ID_ like #{" + MessageFormat.format(nameOfGroupId, i) + "}");
        }
        NativeTaskQuery nativeTaskQuery = taskService.createNativeTaskQuery().sql(MessageFormat.format(sql, tableName0, tableName1, String.join(" or ", nameOfGroupIds)));
        for (int i = 0; i < nameOfGroupIds.size(); i++) {
            nativeTaskQuery.parameter(MessageFormat.format(nameOfGroupId, i), "%" + candidateGroups.get(i) + "%");
        }

        return nativeTaskQuery.list();
    }
}
