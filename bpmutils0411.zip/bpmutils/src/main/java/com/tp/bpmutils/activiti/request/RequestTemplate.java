package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * RequestTemplate
 *
 * @param <Q>
 */
public class RequestTemplate<Q> {

    /**
     * MWHEADER
     */
    @Valid
    @NotNull
    @JsonProperty("MWHEADER")
    private MwHeader mwHeader;

    /**
     * TRANRQ
     */
    @Valid
    @JsonProperty("TRANRQ")
    private Q tranrq;

    public MwHeader getMwHeader() {
        return mwHeader;
    }

    public void setMwHeader(MwHeader mwHeader) {
        this.mwHeader = mwHeader;
    }

    public Q getTranrq() {
        return tranrq;
    }

    public void setTranrq(Q tranrq) {
        this.tranrq = tranrq;
    }
}
