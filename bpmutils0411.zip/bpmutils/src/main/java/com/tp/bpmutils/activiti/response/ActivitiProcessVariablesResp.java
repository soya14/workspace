package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 取得流程變數回覆
 *
 * @author tp
 */
@Schema(description = "取得流程變數回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiProcessVariablesResp {

    /**
     * 變數資訊
     */
    @Schema(description = "變數資訊")
    private ActivitiMainSubVo data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiProcessVariablesResp success(ActivitiMainSubVo data) {
        ActivitiProcessVariablesResp apiSuccess = new ActivitiProcessVariablesResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public ActivitiMainSubVo getData() {
        return data;
    }

    public void setData(ActivitiMainSubVo data) {
        this.data = data;
    }
}
