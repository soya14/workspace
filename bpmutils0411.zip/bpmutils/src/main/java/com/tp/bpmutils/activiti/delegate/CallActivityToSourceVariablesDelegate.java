package com.tp.bpmutils.activiti.delegate;


import org.activiti.bpmn.model.FieldExtension;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;


/**
 * 子流程結束將變數傳回父流程
 *
 * @author tp
 */
@Service("callActivityToSourceVariablesDelegate")
public class CallActivityToSourceVariablesDelegate implements ExecutionListener {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CallActivityToSourceVariablesDelegate.class);

    private static final long serialVersionUID = 1098799393732959610L;

    /**
     * Activiti's RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * CallActivityGetSuperVariablesDelegate's constructor
     *
     * @param runtimeService
     */
    public CallActivityToSourceVariablesDelegate(RuntimeService runtimeService) {
        this.runtimeService = runtimeService;
    }

    @Override
    public void notify(DelegateExecution execution) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Variables: {}", execution.getVariables());
        }
        // 依照fieldName 與stringValue 指定流程對應變數
        Map<String, FieldExtension> assignFieldMap = new HashMap<>();
        Map<String,Object> resultVariables = new HashMap<>();
        // 取得父流程 processInstanceId
        String superProcessInstanceId = null;
        if(execution instanceof ExecutionEntityImpl){
            ExecutionEntityImpl impl = (ExecutionEntityImpl) execution;
            superProcessInstanceId = impl.getParent().getSuperExecution().getProcessInstanceId();
            if(CollectionUtils.isNotEmpty(impl.getCurrentActivitiListener().getFieldExtensions())){
                impl.getCurrentActivitiListener().getFieldExtensions().forEach(fieldExtension -> {assignFieldMap.put(fieldExtension.getFieldName(),fieldExtension);});
            }
        }

//        Map<String, Object> variables = runtimeService.getVariables(processInstanceId);
//        LOGGER.info("before :{}",variables);
        try {
            // set into this process's variables (將本流程參數塞入父流程)
            for(Map.Entry<String, Object> entry : execution.getVariables().entrySet()) {
                resultVariables.put(assignFieldMap.containsKey(entry.getKey()) ? assignFieldMap.get(entry.getKey()).getStringValue():entry.getKey(),entry.getValue());
            }
            // 更新參數
            runtimeService.setVariables(superProcessInstanceId,resultVariables);
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error("setVariable error :{}",e.getMessage());
            }
        }
//        Map<String, Object> af = runtimeService.getVariables(processInstanceId);
//        LOGGER.info("after:{}",af);

    }
}
