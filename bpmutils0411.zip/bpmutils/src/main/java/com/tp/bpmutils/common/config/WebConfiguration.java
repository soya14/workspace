package com.tp.bpmutils.common.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.tp.bpmutils.common.interceptor.RootInterceptor;

/**
 * WebMvc Configurer
 */
@Configuration
public class WebConfiguration implements WebMvcConfigurer {

	/**
	 * @return RootInterceptor
	 */
	@Bean
	public RootInterceptor rootInterceptor() {
		return new RootInterceptor();
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(rootInterceptor()).addPathPatterns("/**");
	}
}
