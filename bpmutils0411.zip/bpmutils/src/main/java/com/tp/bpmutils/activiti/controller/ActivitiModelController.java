package com.tp.bpmutils.activiti.controller;

import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.*;
import com.tp.bpmutils.activiti.service.IActivitiModelService;
import com.tp.bpmutils.common.controller.BaseController;
import com.tp.bpmutils.common.util.DataUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.support.StandardMultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 * BPM Model Controller
 *
 * @author tp
 */
@RestController
@RequestMapping(value = "activiti")
@Tag(name = "Activiti Model 工具接口")
public class ActivitiModelController extends BaseController {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiModelController.class);

    /**
     * BPM Activiti Process Service
     */
    private final transient IActivitiModelService activitiModelService;

    /**
     * ActivitiModelController Constructor
     *
     * @param activitiModelService
     */
    public ActivitiModelController(IActivitiModelService activitiModelService) {
        super();
        this.activitiModelService = activitiModelService;
    }

    /**
     * 流程上傳部署
     *
     * @param request
     * @param mwHeader
     * @param tranrq
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFWDPOFT001", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "流程上傳部署", description = "流程檔案上傳部署")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "上傳部署成功")
    public ResponseTemplate<ActivitiDeployBPMFileResp> deployBPMNFile(HttpServletRequest request, @Parameter(required = true, name = "流程檔案上傳部署請求MWHEADER") @ModelAttribute(value = "MWHEADER", name = "MWHEADER") ActivitiUploadProcessReq mwHeader, @Parameter(required = true, name = "流程檔案上傳部署請求檔案") @RequestPart("TRANRQ") MultipartFile tranrq) {
        LOGGER.info("Deploy Process...");
        StandardMultipartHttpServletRequest multiRequest = (StandardMultipartHttpServletRequest) request;
        String mwHeaderJson = StringUtils.defaultIfBlank(multiRequest.getParameter("MWHEADER"), multiRequest.getParameter("mwHeader"));
        MwHeader mwHeaderObj = DataUtil.stringToBean(mwHeaderJson, MwHeader.class);
        checkInput(mwHeaderObj, new Object[]{"file", tranrq});
        String processDefinitionId = activitiModelService.deployProcess(tranrq);
        ActivitiDeployBPMFileResp.BPMProcessDefinition definition = new ActivitiDeployBPMFileResp.BPMProcessDefinition();
        definition.setProcessDefinitionId(processDefinitionId);
        return new ResponseTemplate<ActivitiDeployBPMFileResp>(
                new MwHeaderResponse(mwHeaderObj), ActivitiDeployBPMFileResp.success(definition)
        );
    }

    /**
     * 流程資源部署
     *
     * @param
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/deployResourceFiles")
    @Operation(summary = "流程資源部署", description = "流程資源路徑部署")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "啟動成功")
    public ResponseTemplate<ActivitiDeployProcessResp> deployResourceFiles(@Parameter(required = true, name = "流程資源路徑部署請求內容") @Valid @RequestBody RequestTemplate<ActivitiDeployProcessReq> req) {
        LOGGER.info("Deploy Process...");
        checkInput(req.getMwHeader(), req.getTranrq(), req.getTranrq().getRequiredParam(), req.getTranrq().getMultiChoiceParam());
        return new ResponseTemplate<ActivitiDeployProcessResp>(
                new MwHeaderResponse(req.getMwHeader()), ActivitiDeployProcessResp.success(activitiModelService.deployResourceFiles(req.getTranrq()))
        );
    }

    /**
     * 取得流程圖 Base64 位元字串
     *
     * @param req
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGIMGQ001")
    @Operation(summary = "取得流程圖 Base64 位元字串", description = "取得流程圖(SVG) Base64 位元字串")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "取得流程圖(SVG) Base64 位元字串成功")
    public ResponseTemplate<ActivitiProcessImgResp> getProcessImgByPID(@Parameter(required = true, name = "取得流程圖 Base64 位元字串請求內容") @Valid @RequestBody RequestTemplate<ActivitiQueryProcessInstanceReq> req) {
        LOGGER.info("Get Process image...");
        checkInput(req.getMwHeader(), req.getTranrq(), req.getTranrq().getRequiredParam(), req.getTranrq().getMultiChoiceParam());
        return new ResponseTemplate<ActivitiProcessImgResp>(
                new MwHeaderResponse(req.getMwHeader()), ActivitiProcessImgResp.success(activitiModelService.getProcessImg(req.getTranrq()))
        );
    }

    /**
     * 查詢流程定義任務
     *
     * @param req processDefKey：流程定義代碼
     * @return
     */
    @ResponseBody
    @PostMapping(value = "/LIP-B-BFQGPCTQ001")
    @Operation(summary = "查詢流程定義任務", description = "查詢流程定義任務")
    @ResponseStatus(HttpStatus.OK)
    @ApiResponse(responseCode = "200", description = "查詢成功")
    public ResponseTemplate<ActivitiProcessActiveTasksResp> getProcessActiveTasks(@Parameter(required = true, name = "查詢流程定義任務") @Valid @RequestBody RequestTemplate<ActivitiProcessActiveTasksReq> req) {
        if (LOGGER.isInfoEnabled()) {
            LOGGER.info("Get Process's active tasks..., Process Def key: {}", req.getTranrq().getProcessDefKey());
        }
        checkInput(req.getMwHeader(), req.getTranrq(), req.getTranrq().getRequiredParam(), req.getTranrq().getMultiChoiceParam());
        return new ResponseTemplate<ActivitiProcessActiveTasksResp>(
                new MwHeaderResponse(req.getMwHeader()), ActivitiProcessActiveTasksResp.success(activitiModelService.getProcessActiveTasks(req.getTranrq()))
        );
    }
}
