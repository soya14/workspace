package com.tp.bpmutils.common.util;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 流程回覆
 */
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
@Schema(description = "流程回覆")
public class BPMApiResponse {

    /**
     * 回應代碼
     */
    @Schema(description = "回應代碼", required = true)
    private String rtnCode;

    /**
     * 回應訊息
     */
    @Schema(description = "回應訊息", required = true)
    private String msg;

    /**
     * 回應資訊
     */
    @Schema(description = "回應資訊", required = true)
    private Object data;

    /**
     * Code success
     */
    public static final String CODE_SUCCESS = "0000";

    /**
     * Code fail
     */
    public static final String CODE_FAIL = "9999";

    /**
     * Msg success
     */
    public static final String MSG_SUCCESS = "成功";
    /**
     * Msg fail
     */
    public static final String MSG_FAIL = "失敗";

    /**
     * Success 1
     *
     * @return
     */
    public static BPMApiResponse success() {
        BPMApiResponse apiSuccess = new BPMApiResponse();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        return apiSuccess;
    }

    /**
     * Success 2
     *
     * @param data
     * @return
     */
    public static BPMApiResponse success(Object data) {
        BPMApiResponse apiSuccess = new BPMApiResponse();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(MSG_SUCCESS);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    /**
     * Success 3
     *
     * @param message
     * @param data
     * @return
     */
    public static BPMApiResponse success(String message, Object data) {
        BPMApiResponse apiSuccess = new BPMApiResponse();
        apiSuccess.setRtnCode("0000");
        apiSuccess.setMsg(message);
        apiSuccess.setData(data);
        return apiSuccess;
    }

    /**
     * Fail 1
     *
     * @return
     */
    public static BPMApiResponse fail() {
        BPMApiResponse apiFail = new BPMApiResponse();
        apiFail.setRtnCode(CODE_FAIL);
        apiFail.setMsg(MSG_FAIL);
        return apiFail;
    }

    /**
     * Fail 2
     *
     * @param failMsg
     * @return
     */
    public static BPMApiResponse fail(String failMsg) {
        BPMApiResponse apiFail = new BPMApiResponse();
        apiFail.setRtnCode(CODE_FAIL);
        apiFail.setMsg(failMsg);
        return apiFail;
    }

    public String getRtnCode() {
        return rtnCode;
    }

    public void setRtnCode(String rtnCode) {
        this.rtnCode = rtnCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
