package com.tp.bpmutils.activiti.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.util.StrUtil;
import com.tp.bpmutils.activiti.entity.ActHiComment;
import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import com.tp.bpmutils.activiti.mybatis.mapper.ActRuTaskMapper;
import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.ActivitiQueryPendingCountResp;
import com.tp.bpmutils.activiti.service.IActivitiCommonService;
import com.tp.bpmutils.activiti.service.IActivitiQueryService;
import com.tp.bpmutils.activiti.service.IBpmHistoricActivityInstanceQueryService;
import com.tp.bpmutils.activiti.service.repository.BpmCommentQueryRepository;
import com.tp.bpmutils.activiti.service.repository.BpmProcinstInfoRepository;
import com.tp.bpmutils.activiti.vo.ActivitiCurrentTaskVo;
import com.tp.bpmutils.activiti.vo.ActivitiHistoryTaskInstanceVo;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.impl.persistence.entity.CommentEntity;
import org.activiti.engine.repository.ProcessDefinition;
import org.activiti.engine.task.Task;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 處理 Activiti Query 服務實作
 *
 * @author tp
 */
@Service
public class ActivitiQueryServiceImpl implements IActivitiQueryService {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiQueryServiceImpl.class);

    /**
     * Activiti RepositoryService
     */
    private final transient RepositoryService repositoryService;

    /**
     * Activiti TaskService
     */
    private final transient TaskService taskService;

    /**
     * Activiti RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * Activiti HistoryService
     */
    private final transient HistoryService historyService;

    /**
     * BPM ActivitiCommonService
     */
    private final transient IActivitiCommonService activitiCommonService;

    /**
     * BPM CommentQueryRepository
     */
    private final transient BpmCommentQueryRepository bpmCommentQueryRepository;

    /**
     * BPM HistoricActivityInstanceQueryService
     */
    private final transient IBpmHistoricActivityInstanceQueryService bpmHistoricActivityInstanceQueryService;

    /**
     * ActRuTask Mapper
     */
    private final transient ActRuTaskMapper actRuTaskMapper;

    /**
     * BPM ProcinstInfoRepository
     */
    private final transient BpmProcinstInfoRepository bpmProcinstInfoRepository;

    /**
     * ActivitiQueryServiceImpl Constructor
     *  @param repositoryService
     * @param taskService
     * @param runtimeService
     * @param historyService
     * @param activitiCommonService
     * @param bpmCommentQueryRepository
     * @param bpmHistoricActivityInstanceQueryService
     * @param actRuTaskMapper
     * @param bpmProcinstInfoRepository
     */
    public ActivitiQueryServiceImpl(RepositoryService repositoryService, TaskService taskService, RuntimeService runtimeService, HistoryService historyService, IActivitiCommonService activitiCommonService, BpmCommentQueryRepository bpmCommentQueryRepository, IBpmHistoricActivityInstanceQueryService bpmHistoricActivityInstanceQueryService, ActRuTaskMapper actRuTaskMapper, BpmProcinstInfoRepository bpmProcinstInfoRepository) {
        this.repositoryService = repositoryService;
        this.taskService = taskService;
        this.runtimeService = runtimeService;
        this.historyService = historyService;
        this.activitiCommonService = activitiCommonService;
        this.bpmCommentQueryRepository = bpmCommentQueryRepository;
        this.bpmHistoricActivityInstanceQueryService = bpmHistoricActivityInstanceQueryService;
        this.actRuTaskMapper = actRuTaskMapper;
        this.bpmProcinstInfoRepository = bpmProcinstInfoRepository;
    }

    private List<ActivitiTaskVo> selectToDoList(List<String> empCodes, List<String> candidateGroups, String processDefKey, String taskDefKey) {
        // Deprecated: processDefKey與taskDefKey 必須同時存在或同時不存在
        /*if (StringUtils.isNotBlank(processDefKey) ^ StringUtils.isNotBlank(taskDefKey)) {
            throw new BPMException(BPMException.getInputParameterError(StringUtils.isBlank(processDefKey) ? "[ProcessDefKey]" : "[TaskDefKey]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }*/

        List<String> candidateGroupsForLike = new ArrayList<>();
        if (CollUtil.isNotEmpty(candidateGroups)) {
            for (String group : candidateGroups) {
                if (StringUtils.isNotBlank(group)) {
                    candidateGroupsForLike.add("%" + group + "%");
                }
            }
        }

        List<ActivitiTaskVo> taskVoList = actRuTaskMapper.getTodoList(empCodes, candidateGroupsForLike);

        // 過濾
        Map<String, ActivitiTaskVo> taskVoMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(taskVoList)) {
            taskVoList.forEach(taskVo -> {

                ActivitiTaskVo vo = taskVoMap.get(taskVo.getTaskId());
                if (null == vo) {
                    vo = taskVo;
                } else if (StringUtils.isBlank(vo.getAssignee())) {

                    StringBuilder user = new StringBuilder(StringUtils.defaultString(vo.getCandidateUser()));
                    StringBuilder group = new StringBuilder(StringUtils.defaultString(vo.getCandidateGroup()));

                    if (StringUtils.isNotBlank(taskVo.getCandidateUser())) {
                        if (user.length() > 0) {
                            user.append(',');
                        }
                        user.append(taskVo.getCandidateUser());
                    }

                    if (StringUtils.isNotBlank(taskVo.getCandidateGroup())) {
                        if (group.length() > 0) {
                            group.append(',');
                        }
                        group.append(taskVo.getCandidateGroup());
                    }

                    if (user.length() > 0) {
                        vo.setCandidateUser(user.toString());
                    }

                    if (group.length() > 0) {
                        vo.setCandidateGroup(group.toString());
                    }
                }

                // 如果有 Asignee，則需要略過 CandidateUser、CandidateGroup
                if (StringUtils.isNotBlank(vo.getAssignee()) && (StringUtils.isNotBlank(vo.getCandidateUser()) || StringUtils.isNotBlank(vo.getCandidateGroup()))) {
                    vo.setCandidateUser(null);
                    vo.setCandidateGroup(null);
                }

                // processDefKey,taskDefKey檢查
                /*if (StringUtils.isNotBlank(processDefKey)
                        && StringUtils.isNotBlank(taskDefKey)) {
                    if (StringUtils.startsWithIgnoreCase(vo.getMainProcDefId(), processDefKey)
                            && StringUtils.startsWithIgnoreCase(vo.getTaskDefKey(), taskDefKey)) {
                        taskVoMap.put(vo.getTaskId(), vo);
                    }
                } else {
                    taskVoMap.put(vo.getTaskId(), vo);
                }*/

                boolean passProcessDefKey = StringUtils.isBlank(processDefKey) || StringUtils.startsWithIgnoreCase(vo.getMainProcDefId(), processDefKey);
                boolean passTaskDefKey = StringUtils.isBlank(taskDefKey) || StringUtils.startsWithIgnoreCase(vo.getTaskDefKey(), taskDefKey);
                if (passProcessDefKey && passTaskDefKey) {
                    taskVoMap.put(vo.getTaskId(), vo);
                }
            });
        }

        /*if (CollectionUtils.isNotEmpty(taskVoList)
                && StringUtils.isNotBlank(processDefKey)
                && StringUtils.isNotBlank(taskDefKey)) {
            taskVoList = taskVoList.stream().filter(taskVO ->
                    StringUtils.startsWithIgnoreCase(taskVO.getMainProcDefId(), processDefKey)
                            && StringUtils.startsWithIgnoreCase(taskVO.getTaskDefKey(), taskDefKey)
            ).collect(Collectors.toList());
        }

        return taskVoList;*/

        return new ArrayList<>(taskVoMap.values());
    }

    @Override
    public List<ActivitiTaskVo> getTodoList(ActivitiQueryPendingReq req) {
        return selectToDoList(req.getEmpCodes(), req.getCandidateGroups(), req.getProcessDefKey(), req.getTaskDefKey());
        /*
        List<Task> allTaskList = new ArrayList<>();
        List<Task> taskAssigneeList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskAssigneeList = taskService.createTaskQuery().taskAssigneeIds(req.getEmpCodes()).list();
        }
        List<Task> taskCandidateGroupList = null;
        if (CollectionUtils.isNotEmpty(req.getCandidateGroups())) {
            taskCandidateGroupList = bpmTaskQueryService.taskCandidateGroupLikeIn(req.getCandidateGroups());
        }
        List<Task> taskCandidateUserList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskCandidateUserList = bpmTaskQueryService.taskCandidateUserIn(req.getEmpCodes());
        }

        if (CollectionUtils.isNotEmpty(taskAssigneeList)) {
            allTaskList.addAll(taskAssigneeList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateGroupList)) {
            allTaskList.addAll(taskCandidateGroupList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateUserList)) {
            allTaskList.addAll(taskCandidateUserList);
        }

        // 查詢指定流程任務節點
        if (CollectionUtils.isNotEmpty(allTaskList)
                && StringUtils.isNotBlank(req.getProcessDefKey())
                && StringUtils.isNotBlank(req.getTaskDefKey())) {
            allTaskList = allTaskList.stream().filter(e ->
                    e.getProcessDefinitionId().toUpperCase(Locale.ROOT).startsWith(req.getProcessDefKey().toUpperCase(Locale.ROOT))
                            && e.getTaskDefinitionKey().toUpperCase(Locale.ROOT).startsWith(req.getTaskDefKey().toUpperCase(Locale.ROOT))
            ).collect(Collectors.toList());
        }

        List<ActivitiTaskVo> taskVoList = new ArrayList<>();
        if (CollectionUtils.isEmpty(allTaskList)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("{} task list is empty...", req.getEmpCodes());
            }
        } else {

            // 彙整所有任務的taskId清單
            List<String> taskIds = new ArrayList<>();
            allTaskList.forEach(task -> {
                if (!taskIds.contains(task.getId())) {
                    taskIds.add(task.getId());
                }
            });

            Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);

            allTaskList.sort(Comparator.comparing(Task::getCreateTime));
            allTaskList.forEach(task -> {
                ActivitiTaskVo vo = new ActivitiTaskVo(
                        task,
                        activitiCommonService.getCandidateGroupByTaskId(candidateMap, task.getId()),
                        activitiCommonService.getCandidateUserByTaskId(candidateMap, task.getId()));
                taskVoList.add(vo);
            });
        }

        return taskVoList;
         */
    }

    @Override
    public List<ActivitiQueryPendingCountResp.ActivitiPendingProcess> getTodoListCounting(ActivitiQueryPendingCountReq req) {

        List<ActivitiTaskVo> taskVoList = selectToDoList(req.getEmpCodes(), req.getCandidateGroups(), req.getProcessDefKey(), req.getTaskDefKey());

        List<ActivitiQueryPendingCountResp.ActivitiPendingProcess> todoListCounting = new ArrayList<>();

        if (CollUtil.isNotEmpty(taskVoList)) {
            HashSet<String> processDefinitionKeys = new HashSet<>();

            taskVoList.forEach(task -> {
                String processDefinitionKey = StringUtils.split(task.getProcessDefinitionId(), ":")[0];
                processDefinitionKeys.add(processDefinitionKey);
            });

            // 彙整流程定義名稱
            Map<String, String> processDefinitionNameMap = new HashMap<>();
            if (CollectionUtils.isNotEmpty(processDefinitionKeys)) {
                List<ProcessDefinition> processDefinitions = repositoryService.createProcessDefinitionQuery().
                        processDefinitionKeys(processDefinitionKeys).latestVersion().list();
                if (CollectionUtils.isNotEmpty(processDefinitions)) {
                    for (ProcessDefinition processDefinition : processDefinitions) {
                        processDefinitionNameMap.put(processDefinition.getKey(), processDefinition.getName());
                    }
                }
            }

            Map<String, ActivitiQueryPendingCountResp.ActivitiPendingProcess> todoCountingMap = new HashMap<>();

            taskVoList.forEach(task -> {
                String processDefinitionKey = StringUtils.split(task.getProcessDefinitionId(), ":")[0];
                String mainProcDefKey = StringUtils.isEmpty(task.getMainProcDefId()) ? "" : StringUtils.split(task.getMainProcDefId(), ":")[0];
                String sourceProcDefKey = StringUtils.isEmpty(task.getSourceProcDefId()) ? "" : StringUtils.split(task.getSourceProcDefId(), ":")[0];
                // 流程定義名稱
                String processDefinitionName = processDefinitionNameMap.get(processDefinitionKey);

                ActivitiQueryPendingCountResp.ActivitiPendingProcess todoCounting = todoCountingMap.get(processDefinitionKey);
                if (todoCounting == null) {
                    todoCounting = new ActivitiQueryPendingCountResp.ActivitiPendingProcess();
                    todoCounting.setProcessDefKey(processDefinitionKey);
                    todoCounting.setProcessName(processDefinitionName);
                    todoCounting.setTotalCount(0);
                    todoCounting.setMainProcDefKey(mainProcDefKey);
                    todoCounting.setSourceProcDefKey(sourceProcDefKey);
                    todoCountingMap.put(processDefinitionKey, todoCounting);
                    todoListCounting.add(todoCounting);
                }

                List<ActivitiQueryPendingCountResp.ActivitiPendingTask> tasks = todoCounting.getTasks();
                if (tasks == null) {
                    todoCounting.setTasks(new ArrayList<>());
                }

                ActivitiQueryPendingCountResp.ActivitiPendingTask counting = null;

                for (ActivitiQueryPendingCountResp.ActivitiPendingTask pendingTask : todoCounting.getTasks()) {
                    if (StringUtils.equals(task.getTaskDefKey(), pendingTask.getTaskDefKey())) {
                        counting = pendingTask;
                    }
                }

                if (null == counting) {
                    counting = new ActivitiQueryPendingCountResp.ActivitiPendingTask();
                    counting.setTaskName(task.getTaskName());
                    counting.setTaskDefKey(task.getTaskDefKey());
                    counting.setCount(Integer.valueOf(0));
                    todoCounting.getTasks().add(counting);
                }

                counting.setCount(counting.getCount() + 1);
                todoCounting.setTotalCount(todoCounting.getTotalCount() + 1);
            });
        }

        return todoListCounting;

        /*
        // processDefKey與taskDefKey 必須同時存在或同時不存在
        if (StringUtils.isNotBlank(req.getProcessDefKey()) ^ StringUtils.isNotBlank(req.getTaskDefKey())) {
            throw new BPMException(BPMException.getInputParameterError(StringUtils.isBlank(req.getProcessDefKey()) ? "[processDefKey]" : "[taskDefKey]"), BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }

        if (CollUtil.isEmpty(req.getEmpCodes()) && CollUtil.isEmpty(req.getCandidateGroups())) {
            throw new BPMException("[EmpCodes] && [CandidateGroups] is empty", BPMExceptionStatus.INPUT_PARAMETER_ERROR, HttpStatus.BAD_REQUEST.value());
        }

        List<ActivitiQueryPendingCountResp.ActivitiPendingProcess> todoListCounting = new ArrayList<>();

        List<Task> allTaskList = new ArrayList<>();

        List<Task> taskAssigneeList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskAssigneeList = taskService.createTaskQuery().taskAssigneeIds(req.getEmpCodes()).list();
        }
        List<Task> taskCandidateGroupList = null;
        if (CollectionUtils.isNotEmpty(req.getCandidateGroups())) {
            taskCandidateGroupList = bpmTaskQueryService.taskCandidateGroupLikeIn(req.getCandidateGroups());
        }
        List<Task> taskCandidateUserList = null;
        if (CollectionUtils.isNotEmpty(req.getEmpCodes())) {
            taskCandidateUserList = bpmTaskQueryService.taskCandidateUserIn(req.getEmpCodes());
        }

        if (CollectionUtils.isNotEmpty(taskAssigneeList)) {
            allTaskList.addAll(taskAssigneeList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateGroupList)) {
            allTaskList.addAll(taskCandidateGroupList);
        }

        if (CollectionUtils.isNotEmpty(taskCandidateUserList)) {
            allTaskList.addAll(taskCandidateUserList);
        }

        // 查詢指定流程任務節點
        if (CollectionUtils.isNotEmpty(allTaskList)
                && StringUtils.isNotBlank(req.getProcessDefKey())
                && StringUtils.isNotBlank(req.getTaskDefKey())) {
            allTaskList = allTaskList.stream().filter(e ->
                    e.getProcessDefinitionId().toUpperCase(Locale.ROOT).startsWith(req.getProcessDefKey().toUpperCase(Locale.ROOT))
                            && e.getTaskDefinitionKey().toUpperCase(Locale.ROOT).startsWith(req.getTaskDefKey().toUpperCase(Locale.ROOT))
            ).collect(Collectors.toList());
        }

        if (CollectionUtils.isEmpty(allTaskList)) {
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("{} task list is empty...", req.getEmpCodes());
            }
        } else {

            List<String> processDefinitionKeys = new ArrayList<>();
            allTaskList.forEach(task -> {
                String processDefinitionKey = StringUtils.split(task.getProcessDefinitionId(), ":")[0];
                if (!processDefinitionKeys.contains(processDefinitionKey)) {
                    processDefinitionKeys.add(processDefinitionKey);
                }
            });

            // 彙整流程定義名稱
            Map<String, String> processDefinitionNameMap = new HashMap<>();
            if (CollectionUtils.isNotEmpty(processDefinitionKeys)) {
                List<ProcessDefinition> processDefinitions = repositoryService.createProcessDefinitionQuery().processDefinitionKeys(new HashSet<String>(processDefinitionKeys)).latestVersion().list();
                if (CollectionUtils.isNotEmpty(processDefinitions)) {
                    for (ProcessDefinition processDefinition : processDefinitions) {
                        processDefinitionNameMap.put(processDefinition.getKey(), processDefinition.getName());
                    }
                }
            }

            allTaskList.forEach(task -> {

                String processDefinitionKey = StringUtils.split(task.getProcessDefinitionId(), ":")[0];
                // 流程定義名稱
                String processDefinitionName = processDefinitionNameMap.get(processDefinitionKey);

                ActivitiQueryPendingCountResp.ActivitiPendingProcess todoCounting = null;
                if (CollectionUtils.isNotEmpty(todoListCounting)) {
                    for (ActivitiQueryPendingCountResp.ActivitiPendingProcess pendingProcess : todoListCounting) {
                        if (StringUtils.equals(processDefinitionKey, pendingProcess.getProcessDefKey())) {
                            todoCounting = pendingProcess;
                        }
                    }
                }

                if (null == todoCounting) {
                    todoCounting = new ActivitiQueryPendingCountResp.ActivitiPendingProcess();
                    todoCounting.setProcessDefKey(processDefinitionKey);
                    todoCounting.setProcessName(processDefinitionName);
                    todoCounting.setTotalCount(Integer.valueOf(0));
                    todoCounting.setMainProcDefKey(processDefinitionKey);
                    todoListCounting.add(todoCounting);
                }

                ActivitiQueryPendingCountResp.ActivitiPendingTask counting = null;
                if (CollectionUtils.isNotEmpty(todoCounting.getTasks())) {
                    for (ActivitiQueryPendingCountResp.ActivitiPendingTask pendingTask : todoCounting.getTasks()) {
                        if (StringUtils.equals(task.getTaskDefinitionKey(), pendingTask.getTaskDefKey())) {
                            counting = pendingTask;
                        }
                    }
                }

                if (null == counting) {
                    counting = new ActivitiQueryPendingCountResp.ActivitiPendingTask();
                    counting.setTaskName(task.getName());
                    counting.setTaskDefKey(task.getTaskDefinitionKey());
                    counting.setCount(Integer.valueOf(0));
                    if (null == todoCounting.getTasks()) {
                        todoCounting.setTasks(new ArrayList<>());
                    }
                    todoCounting.getTasks().add(counting);
                }

                counting.setCount(counting.getCount() + 1);
                todoCounting.setTotalCount(todoCounting.getTotalCount() + 1);
            });
        }
        return todoListCounting;
         */
    }

    @Override
    public ActivitiTaskVo getTaskInfo(ActivitiQueryTaskReq req) {
        Task task = taskService.createTaskQuery()
                .taskId(req.getTaskId())
                .singleResult();

        // 若 查無任務 且 歷史案件不為空，則返回錯誤訊息: 此案件已被審核
        if (task == null) {
            HistoricTaskInstance his = historyService.createHistoricTaskInstanceQuery().taskId(req.getTaskId()).finished().singleResult();
            if (his != null) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error(BPMExceptionStatus.APPROVED_ERROR.msg() + "! TaskId: " + req.getTaskId() + ", completeTask complete");
                }
                throw new BPMException(BPMExceptionStatus.APPROVED_ERROR.msg(), BPMExceptionStatus.APPROVED_ERROR, HttpStatus.BAD_REQUEST.value(), 3);
            } else {
                throw new BPMException(BPMException.getTaskUnknowError(req.getTaskId()), BPMExceptionStatus.TASK_UNKNOW_ERROR, HttpStatus.BAD_REQUEST.value());
            }
        }

        List<String> taskIds = new ArrayList<>();
        taskIds.add(task.getId());

        Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);
        BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(task.getProcessInstanceId());

        return new ActivitiTaskVo(
                task,
                activitiCommonService.getCandidateGroupByTaskId(candidateMap, task.getId()),
                activitiCommonService.getCandidateUserByTaskId(candidateMap, task.getId()),
                bpmProcinstInfo
        );
    }

    @Override
    public ActivitiMainSubVo getProcessVariables(ActivitiQueryProcessInstanceReq activitiQueryProcessInstanceReq) {
        String processInstanceId = activitiQueryProcessInstanceReq.getProcessInstanceId();
        Map<String, Object> process = runtimeService.getVariables(processInstanceId);

        BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(processInstanceId);

        ActivitiMainSubVo result = new ActivitiMainSubVo();
        result.setProcess(process);

        if (bpmProcinstInfo != null) {
            Map<String, Object> mainProcess = StrUtil.equals(processInstanceId, bpmProcinstInfo.getMainProcInstId()) ? process : runtimeService.getVariables(bpmProcinstInfo.getMainProcInstId());
            result.setMainProcess(mainProcess);

            if (StrUtil.isNotBlank(bpmProcinstInfo.getSourceProcInstId())) {
                result.setSourceProcess(runtimeService.getVariables(bpmProcinstInfo.getSourceProcInstId()));
            }
        } else {
            result.setMainProcess(process);
        }

        return result;
    }

    @Override
    public ActivitiMainSubVo getProcessVariable(ActivitiQueryProcessVariableReq activitiQueryProcessVariableReq) {
        String processInstanceId = activitiQueryProcessVariableReq.getProcessInstanceId();
        String variable = activitiQueryProcessVariableReq.getVariable();
        Object process = runtimeService.getVariable(processInstanceId, variable);

        BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(processInstanceId);

        ActivitiMainSubVo result = new ActivitiMainSubVo();
        result.setProcess(process);

        if (bpmProcinstInfo != null) {
            Object mainProcess = StrUtil.equals(processInstanceId, bpmProcinstInfo.getMainProcInstId()) ? process : runtimeService.getVariable(bpmProcinstInfo.getMainProcInstId(), variable);
            result.setMainProcess(mainProcess);

            if (StrUtil.isNotBlank(bpmProcinstInfo.getSourceProcInstId())) {
                result.setSourceProcess(runtimeService.getVariable(bpmProcinstInfo.getSourceProcInstId(), variable));
            }
        } else {
            result.setMainProcess(process);
        }

        return result;
    }

    /**
     * 依processInstId清單查詢ACT_HI_TASKINST中已結束的任務資料
     *
     * @param procInstIds
     * @return
     */
    private Map<String, List<HistoricTaskInstance>> getProcInstIdActHiTaskinstListMap(List<String> procInstIds) {

        Map<String, List<HistoricTaskInstance>> procInstIdActHiTaskinstListMap = new HashMap<>();
        List<HistoricTaskInstance> historicTaskInstanceList = historyService.createHistoricTaskInstanceQuery().processInstanceIdIn(procInstIds).finished().list();
        if (CollectionUtils.isNotEmpty(historicTaskInstanceList)) {
            for (HistoricTaskInstance inst : historicTaskInstanceList) {
                List<HistoricTaskInstance> actHiActinst = MapUtils.getObject(procInstIdActHiTaskinstListMap, inst.getProcessInstanceId(), new ArrayList<>());
                actHiActinst.add(inst);
                procInstIdActHiTaskinstListMap.put(inst.getProcessInstanceId(), actHiActinst);
            }
        }
        return procInstIdActHiTaskinstListMap;
    }

    /**
     * 取得已結束的最新任務資料
     *
     * @param historicTaskInstanceList
     * @return
     */
    private HistoricTaskInstance getLastActHiTaskinst(List<HistoricTaskInstance> historicTaskInstanceList) {

        HistoricTaskInstance historicTaskInstance = null;
        if (CollectionUtils.isNotEmpty(historicTaskInstanceList)) {
            for (HistoricTaskInstance inst : historicTaskInstanceList) {
                if (null == historicTaskInstance || historicTaskInstance.getEndTime().before(inst.getEndTime())) {
                    historicTaskInstance = inst;
                }
            }
        }
        return historicTaskInstance;
    }

    /**
     * 依processInstId清單查詢ACT_HI_COMMENT資料
     *
     * @param procInstIds
     * @return
     */
    private Map<String, List<ActHiComment>> getProcInstIdActHiCommentListMap(List<String> procInstIds) {

        Map<String, List<ActHiComment>> procInstIdActHiCommentListMap = new HashMap<>();
        List<ActHiComment> actHiComments = bpmCommentQueryRepository.findByProcInstIdIn(procInstIds);
        if (CollectionUtils.isNotEmpty(actHiComments)) {
            for (ActHiComment comment : actHiComments) {
                List<ActHiComment> actHiCommentList = MapUtils.getObject(procInstIdActHiCommentListMap, comment.getProcInstId(), new ArrayList<>());
                actHiCommentList.add(comment);
                procInstIdActHiCommentListMap.put(comment.getProcInstId(), actHiCommentList);
            }
        }
        return procInstIdActHiCommentListMap;
    }

    /**
     * 取得子母流程中，優先序子>上一階>主流程 HistoricTaskInstance 清單
     *
     * @param procInstIdActHiTaskinstListMap
     * @param bpmProcinstInfo
     * @return
     */
    private List<HistoricTaskInstance> getHistoricTaskInstanceListForSubOrMainProcess(Map<String, List<HistoricTaskInstance>> procInstIdActHiTaskinstListMap, BpmProcinstInfo bpmProcinstInfo) {

        List<HistoricTaskInstance> tmpHistoricTaskInstanceList = MapUtils.getObject(procInstIdActHiTaskinstListMap, bpmProcinstInfo.getProcInstId(), new ArrayList<>());

        // 子流程無歷史任務紀錄，取得上一階流程歷史任務紀錄
        if (CollectionUtils.isEmpty(tmpHistoricTaskInstanceList)
                // 若為子母流程，且跟上一階流程ID不同
                && StringUtils.isNotBlank(bpmProcinstInfo.getSourceProcInstId()) && !StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getSourceProcInstId())) {
            List<HistoricTaskInstance> tmpHistoricTaskInstanceList2 = procInstIdActHiTaskinstListMap.get(bpmProcinstInfo.getSourceProcInstId());
            if (CollectionUtils.isNotEmpty(tmpHistoricTaskInstanceList2)) {
                tmpHistoricTaskInstanceList.addAll(tmpHistoricTaskInstanceList2);
            }
        }

        // 子流程及上一階流程無歷史任務紀錄，取得主流程歷史任務紀錄
        if (CollectionUtils.isEmpty(tmpHistoricTaskInstanceList)
                // 若為子母流程，且跟 主流程ID不同 和 主流程與上一階流程ID不同
                && !StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getMainProcInstId()) && !StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getSourceProcInstId())) {
            List<HistoricTaskInstance> tmpHistoricTaskInstanceList2 = procInstIdActHiTaskinstListMap.get(bpmProcinstInfo.getMainProcInstId());
            if (CollectionUtils.isNotEmpty(tmpHistoricTaskInstanceList2)) {
                tmpHistoricTaskInstanceList.addAll(tmpHistoricTaskInstanceList2);
            }
        }

        return tmpHistoricTaskInstanceList;
    }

    /**
     * 取得子母流程中，優先序子>上一階>主流程 ActHiComment 清單
     *
     * @param procInstIdActHiCommentListMap
     * @param bpmProcinstInfo
     * @return
     */
    private List<ActHiComment> getActHiCommentListForSubOrMainProcess(Map<String, List<ActHiComment>> procInstIdActHiCommentListMap, BpmProcinstInfo bpmProcinstInfo) {

        List<ActHiComment> tmpCommentList = MapUtils.getObject(procInstIdActHiCommentListMap, bpmProcinstInfo.getProcInstId(), new ArrayList<>());

        // 子流程無備註紀錄，取得上一階流程備註紀錄
        if (CollectionUtils.isEmpty(tmpCommentList)
                // 若為子母流程，且跟上一階流程ID不同
                && StringUtils.isNotBlank(bpmProcinstInfo.getSourceProcInstId()) && !StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getSourceProcInstId())) {
            List<ActHiComment> tmpCommentList2 = MapUtils.getObject(procInstIdActHiCommentListMap, bpmProcinstInfo.getSourceProcInstId(), new ArrayList<>());
            if (CollectionUtils.isNotEmpty(tmpCommentList2)) {
                tmpCommentList.addAll(tmpCommentList2);
            }
        }

        // 子流程及上一階流程無備註紀錄，取得主流程備註紀錄
        if (CollectionUtils.isEmpty(tmpCommentList)
                // 若為子母流程，且跟 主流程ID不同 和 主流程與上一階流程ID不同
                && !StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getMainProcInstId()) && !StringUtils.equals(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo.getSourceProcInstId())) {
            List<ActHiComment> tmpCommentList2 = MapUtils.getObject(procInstIdActHiCommentListMap, bpmProcinstInfo.getMainProcInstId(), new ArrayList<>());
            if (CollectionUtils.isNotEmpty(tmpCommentList2)) {
                tmpCommentList.addAll(tmpCommentList2);
            }
        }

        return tmpCommentList;
    }

    @Override
    public List<ActivitiCurrentTaskVo> getCurrentTasks(ActivitiQueryCurrentTaskReq activitiQueryCurrentTaskReq) {

        List<ActivitiCurrentTaskVo> currentTasks = new ArrayList<>();

        List<String> processInstanceIds = new ArrayList<>();
        Map<String, BpmProcinstInfo> bpmProcinstInfoMap = new HashMap<>();

        List<BpmProcinstInfo> bpmProcinstInfoList = bpmProcinstInfoRepository.findByProcInstIdWithSameMainProcInstIdsIn(activitiQueryCurrentTaskReq.getProcessInstanceIds());
        if (CollectionUtils.isNotEmpty(bpmProcinstInfoList)) {
            for (BpmProcinstInfo bpmProcinstInfo : bpmProcinstInfoList) {
                if (!processInstanceIds.contains(bpmProcinstInfo.getProcInstId())) {
                    processInstanceIds.add(bpmProcinstInfo.getProcInstId());
                }
                bpmProcinstInfoMap.put(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo);
            }
        }

        // 未結束歷史節點
        Map<String, List<HistoricActivityInstance>> processInstanceIdHistoricActivityInstanceList = bpmHistoricActivityInstanceQueryService.findMapByProcInstIdInAndEndTimeIsNull(processInstanceIds);
        // 已結束任務節點
        Map<String, List<HistoricTaskInstance>> procInstIdActHiTaskinstListMap = getProcInstIdActHiTaskinstListMap(processInstanceIds);
        // 備註
        Map<String, List<ActHiComment>> procInstIdActHiCommentListMap = getProcInstIdActHiCommentListMap(processInstanceIds);

        for (String processInstanceId : processInstanceIds) {

            List<HistoricActivityInstance> historicActivityInstanceList = processInstanceIdHistoricActivityInstanceList.get(processInstanceId);
            if (CollectionUtils.isEmpty(historicActivityInstanceList)) {
                continue;
            }

            List<String> taskIds = new ArrayList<>();
            if (CollectionUtils.isNotEmpty(historicActivityInstanceList)) {
                for (HistoricActivityInstance historicActivityInstance : historicActivityInstanceList) {
                    if (StringUtils.isNotBlank(historicActivityInstance.getTaskId())) {
                        taskIds.add(historicActivityInstance.getTaskId());
                    }
                }
            }

            Map<String, Map<String, StringBuilder>> candidateMap = activitiCommonService.getCandidateByTaskIds(taskIds);

            for (HistoricActivityInstance historicActivityInstance : historicActivityInstanceList) {

                // 處理TaskType為Task的資料
                if (StringUtils.isNotBlank(historicActivityInstance.getTaskId())) {

                    BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoMap.get(processInstanceId);

                    // HistoricTaskInstance actHiTaskinst = getLastActHiTaskinst(procInstIdActHiTaskinstListMap.get(processInstanceId));
                    // 取得子母流程中，優先序子>上一階>主流程 HistoricTaskInstance 清單
                    List<HistoricTaskInstance> tmpHistoricTaskInstanceList = getHistoricTaskInstanceListForSubOrMainProcess(procInstIdActHiTaskinstListMap, bpmProcinstInfo);
                    HistoricTaskInstance actHiTaskinst = getLastActHiTaskinst(tmpHistoricTaskInstanceList);

                    String taskId = null;
                    if (null != actHiTaskinst) {
                        taskId = actHiTaskinst.getId();
                    }

                    List<ActHiComment> commentList = new ArrayList<>();
                    if (StringUtils.isNotBlank(taskId)) {
                        // List<ActHiComment> tmpCommentList = MapUtils.getObject(procInstIdActHiCommentListMap, processInstanceId, new ArrayList<>());
                        // 取得子母流程中，優先序子>上一階>主流程 ActHiComment 清單
                        List<ActHiComment> tmpCommentList = getActHiCommentListForSubOrMainProcess(procInstIdActHiCommentListMap, bpmProcinstInfo);
                        if (CollectionUtils.isNotEmpty(tmpCommentList)) {
                            for (ActHiComment comment : tmpCommentList) {
                                if (StringUtils.equals(comment.getTaskId(), taskId)) {
                                    commentList.add(comment);
                                }
                            }
                        }
                    }
                    // taskService.getProcessInstanceComments(processInstanceId);

                    // BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoMap.get(historicActivityInstance.getProcessInstanceId());
                    String lastTaskName = null;
                    ActHiComment comment = null;
                    if (CollectionUtils.isNotEmpty(commentList)) {
                        if (LOGGER.isInfoEnabled()) {
                            LOGGER.info("Process Instance:{}, Comment List size :{}", processInstanceId, commentList.size());
                        }
                        commentList.sort(Comparator.comparing(ActHiComment::getTime));
                        comment = commentList.get(commentList.size() - 1);
                        HistoricTaskInstance his = historyService.createHistoricTaskInstanceQuery()
                                .taskId(comment.getTaskId())
                                .singleResult();

                        lastTaskName = his.getName();
                    }

                    ActivitiCurrentTaskVo vo = new ActivitiCurrentTaskVo(
                            historicActivityInstance,
                            activitiCommonService.getCandidateGroupByTaskId(candidateMap, historicActivityInstance.getTaskId()),
                            activitiCommonService.getCandidateUserByTaskId(candidateMap, historicActivityInstance.getTaskId()),
                            lastTaskName,
                            comment,
                            bpmProcinstInfo
                    );

                    currentTasks.add(vo);
                }
            }
        }

        //以任務編號排序順序輸出
        currentTasks.sort(Comparator.comparing(ActivitiTaskVo::getTaskId));

        return currentTasks;
    }

    @Override
    public List<ActivitiHistoryTaskInstanceVo> queryProcessInstanceHis(ActivitiQueryProcessInstanceReq req) {

        List<ActivitiHistoryTaskInstanceVo> taskVoList = new ArrayList<>();

        // 依 procInstId 查詢有相同 mainProcInstId 的 BpmProcinstInfo 清單
        List<BpmProcinstInfo> bpmProcinstInfoList = bpmProcinstInfoRepository.findByProcInstIdWithSameMainProcInstId(req.getProcessInstanceId());
        // 彙整相同 mainProcInstId 的 procInstId 清單
        List<String> procInstIdList = new ArrayList<>();
        Map<String, BpmProcinstInfo> bpmProcinstInfoMap = new HashMap<>();
        if (CollectionUtils.isNotEmpty(bpmProcinstInfoList)) {
            for (BpmProcinstInfo bpmProcinstInfo : bpmProcinstInfoList) {
                procInstIdList.add(bpmProcinstInfo.getProcInstId());
                bpmProcinstInfoMap.put(bpmProcinstInfo.getProcInstId(), bpmProcinstInfo);
            }
        }

        List<ActHiComment> actHiCommentList = bpmCommentQueryRepository.findByProcInstIdIn(procInstIdList);
        if (CollectionUtils.isNotEmpty(actHiCommentList)) {

            // 保留type=comment
            actHiCommentList = actHiCommentList.stream().filter(e -> StringUtils.equals(CommentEntity.TYPE_COMMENT, e.getType())).collect(Collectors.toList());

            if (LOGGER.isInfoEnabled()) {
                LOGGER.info("Process Instance:{}, Comment List size :{}", req.getProcessInstanceId(), actHiCommentList.size());
            }

            actHiCommentList.sort(Comparator.comparing(ActHiComment::getTime));

            List<HistoricActivityInstance> hisList = bpmHistoricActivityInstanceQueryService.findByProcInstIdIn(procInstIdList);
            Map<String, HistoricActivityInstance> hisMap = new HashMap<>();
            if (CollectionUtils.isNotEmpty(hisList)) {
                for (HistoricActivityInstance his : hisList) {
                    if (StringUtils.isNotBlank(his.getTaskId())) {
                        hisMap.put(his.getTaskId(), his);
                    }
                }
            }

            actHiCommentList.forEach(comment -> {
                // 略過 ProcInstId 或 TaskId 為空的 comment
                if (StringUtils.isNotBlank(comment.getTaskId()) && StringUtils.isNotBlank(comment.getProcInstId())) {
                    HistoricActivityInstance his = hisMap.get(comment.getTaskId());
                    BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoMap.get(comment.getProcInstId());
                    // HistoricActivityInstance 和 BpmProcinstInfo 中必須有資料
                    if (null != his && null != bpmProcinstInfo) {
                        if (LOGGER.isDebugEnabled()) {
                            LOGGER.debug("審核人： " + comment.getUserId() + " ,審核內容：" + comment.getFullMsg() + " ,審核時間:" + comment.getTime().toString());
                        }
                        try {
                            ActivitiHistoryTaskInstanceVo vo = new ActivitiHistoryTaskInstanceVo(comment, his, bpmProcinstInfo.getMainProcInstId(), bpmProcinstInfo.getMainProcDefId(), bpmProcinstInfo.getSourceProcInstId(), bpmProcinstInfo.getSourceProcDefId());
                            taskVoList.add(vo);
                        } catch (IOException e) {
                            if (LOGGER.isErrorEnabled()) {
                                LOGGER.error("產生ActivitiHistoryTaskInstanceVo錯誤, taskId: {}", comment.getTaskId());
                            }
                        }
                    }
                }
            });
        }

        return taskVoList;
    }
}
