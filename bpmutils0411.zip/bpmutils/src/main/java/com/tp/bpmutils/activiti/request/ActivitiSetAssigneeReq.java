package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import static io.swagger.v3.oas.annotations.media.Schema.AccessMode.READ_ONLY;

/**
 * 改派處理者請求
 *
 * @author tp
 */
@Schema(description = "改派處理者請求")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiSetAssigneeReq {

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"taskId", "assignee"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 節點編號
     */
    @Schema(description = "節點編號：5", required = true)
    private String taskId;

    /**
     * 新的處理者
     */
    @Schema(description = "新的處理者：1", required = true)
    private String assignee;

    /**
     * Get Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    /**
     * Get Multi Choice Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }
}
