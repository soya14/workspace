package com.tp.bpmutils.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.beans.FeatureDescriptor;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Data Util
 *
 * @author tp
 */
public class DataUtil {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DataUtil.class);

    /**
     * Singleton ObjectMapper for all transport related libraries
     */
    public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private DataUtil() {
    }

    /**
     * Get ObjectMapper instance
     *
     * @param createNew
     * @return
     */
    public static ObjectMapper getMapperInstance(boolean createNew) {
        if (createNew) {
            return new ObjectMapper();
        } else {
            return OBJECT_MAPPER;
        }
    }

    /**
     * Converted into a java object
     *
     * @param object ready conversion of objects
     * @param clazz  ready conversion of class
     * @return <T>
     */
    public static <T> T deepClone(Object object, Class<T> clazz) {
        if (object == null) {
            return null;
        }
        return stringToBean(objectToString(object), clazz);
    }

    /**
     * Converted into a java string objects json
     *
     * @param value ready to convert json string
     * @param clazz ready conversion of class
     * @return <T>
     */
    public static <T> T stringToBean(String value, Class<T> clazz) {
        if (value == null) {
            return null;
        }
        try {
            return getMapperInstance(false).readValue(value, clazz);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Converted into a java object string json
     *
     * @param object ready conversion of objects
     * @return String
     */
    public static String objectToString(Object object) {
        if (object == null) {
            return null;
        }
        try {
            return getMapperInstance(false).writeValueAsString(object);
        } catch (Exception e) {
            return null;
        }

    }

    /**
     * Converted into a java map
     *
     * @param bean ready conversion of objects
     * @return Map
     */
    public static Map<String, Object> beanToMap(Object bean) {
        if (bean == null) {
            return null;
        }
        try {
            return getMapperInstance(false).readValue(objectToString(bean), Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Converted into a java map
     *
     * @param value ready to convert json string
     * @return Map
     */
    public static Map<String, Object> stringToMap(String value) {
        if (value == null) {
            return null;
        }
        try {
            return getMapperInstance(false).readValue(value, Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Dump object's null Property Names
     *
     * @param source
     * @return
     */
    public static String[] getNullPropertyNames(Object source) {
        final BeanWrapper wrappedSource = new BeanWrapperImpl(source);
        return Stream.of(wrappedSource.getPropertyDescriptors()).map(FeatureDescriptor::getName)
                .filter(propertyName -> wrappedSource.getPropertyValue(propertyName) == null).toArray(String[]::new);
    }

    /**
     * 確認是否全數字
     *
     * @param str
     * @return
     */
    public static Boolean isValuesAllNum(String str) {
        Boolean rtn = false;
        try {
            Pattern pattern = Pattern.compile("[0-9]+");
            Matcher isNum = pattern.matcher(str);
            rtn = isNum.matches();
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage());
            }
        }
        return rtn;
    }

    /**
     * 確認是否全英文
     *
     * @param str
     * @return
     */
    public static Boolean isValuesAllEn(String str) {
        Boolean rtn = false;
        try {
            Pattern pattern = Pattern.compile("[a-zA-Z]+");
            Matcher isNum = pattern.matcher(str);
            rtn = isNum.matches();
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage());
            }
        }
        return rtn;
    }

    /**
     * Valid JSON string
     *
     * @param text
     * @return
     */
    public static boolean isJSONValid(String text) {
        try {
            getMapperInstance(false).readTree(text);
        } catch (Exception ex) {
            return false;
        }
        return true;
    }

    /**
     * 檢核並過濾輸入中的XSS、SQL攻擊
     *
     * @param value
     * @return
     */
    public static String stripXSSAndSQL(String value) {

        String result = null;
        if (StringUtils.isNotBlank(value)) {
            result = value.replaceAll("", "");

            Pattern scriptPattern = null;

            // Avoid anything between script tags
            scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
            result = scriptPattern.matcher(result).replaceAll("");

            // Avoid anything in a src='...' type of expression
            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            result = scriptPattern.matcher(result).replaceAll("");

            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            result = scriptPattern.matcher(result).replaceAll("");

            // Remove any lonesome </script> tag
            scriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);
            result = scriptPattern.matcher(result).replaceAll("");

            // Remove any lonesome <script ...> tag
            scriptPattern = Pattern.compile("<script(.*?)>",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            result = scriptPattern.matcher(result).replaceAll("");

            // Avoid eval(...) expressions
            scriptPattern = Pattern.compile("eval\\((.*?)\\)",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            result = scriptPattern.matcher(result).replaceAll("");

            // Avoid expression(...) expressions
            scriptPattern = Pattern.compile("expression\\((.*?)\\)",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            result = scriptPattern.matcher(result).replaceAll("");

            // Avoid javascript:... expressions
            scriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);
            result = scriptPattern.matcher(result).replaceAll("");

            // Avoid vbscript:... expressions
            scriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);
            result = scriptPattern.matcher(result).replaceAll("");

            // Avoid onload= expressions
            scriptPattern = Pattern.compile("onload(.*?)=",
                    Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
            result = scriptPattern.matcher(result).replaceAll("");

            // result = StringEscapeUtils.escapeSql(result);
            result = sqlRealScapeString(result);
        }

        return result;
    }

    private static String sqlRealScapeString(String str) {
        String data = null;
        if (str != null && str.length() > 0) {
            str = str.replace("\\", "\\\\");
            str = str.replace("'", "\\'");
            str = str.replace("\0", "\\0");
            str = str.replace("\n", "\\n");
            str = str.replace("\r", "\\r");
            str = str.replace("\"", "\\\"");
            str = str.replace("\\x1a", "\\Z");
            data = str;
        }
        return data;
    }
}
