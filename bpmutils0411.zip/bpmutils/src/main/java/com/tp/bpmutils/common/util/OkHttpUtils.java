package com.tp.bpmutils.common.util;

import com.tp.bpmutils.common.config.OkHttpConfiguration;
import com.tp.bpmutils.common.exception.BPMException;
import com.tp.bpmutils.common.exception.BPMExceptionStatus;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;

/**
 * Http連線呼叫公用程式<br/>
 */
@Component
public class OkHttpUtils {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(OkHttpUtils.class);

    /**
     * OkHttp common param
     */
    public static final String STATUS_CODE = "statusCode";

    /**
     * OkHttp common param
     */
    public static final String MESSAGE = "message";

    /**
     * OkHttp common param
     */
    public static final String BODY = "body";

    /**
     * OkHttpClient singleton object
     */
    private static OkHttpClient okHttpClient;

    private OkHttpUtils(OkHttpClient inOkHttpClient) {
        setOkHttpClient(inOkHttpClient);
    }

    private static void setOkHttpClient(OkHttpClient newOkHttpClient) {
        okHttpClient = newOkHttpClient;
    }

    /**
     * Get OkHttpClient instance
     *
     * @param sec
     * @return
     */
    public static OkHttpClient getInstance(Integer sec) {
        if (Objects.isNull(sec)) {
            return okHttpClient;
        } else {
            return OkHttpConfiguration.getInstanceSetTimeOut(sec);
        }
    }

    /**
     * 取得呼叫status code
     *
     * @param respResult
     * @return
     */
    public static int getCode(Map<String, Object> respResult) {
        return MapUtils.getIntValue(respResult, STATUS_CODE);
    }

    /**
     * 取得呼叫http message
     *
     * @param respResult
     * @return
     */
    public static String getMessage(Map<String, Object> respResult) {
        return MapUtils.getString(respResult, MESSAGE);
    }

    /**
     * OkHttp common execute
     *
     * @param url
     * @param headers
     * @param body
     * @param method
     * @return
     * @throws IOException
     */
    public static OKResponse execute(String url, Map<String, String> headers, RequestBody body, String method) throws IOException {

        Response response = null;
        OKResponse okResponse = null;
        try {
            Request.Builder builder = new Request.Builder();

            // url
            builder.url(url);

            if (headers != null) {
                // header
                for (Entry<String, String> mEntry : headers.entrySet()) {
                    String mEntryKey = mEntry.getKey();
                    Object mEntryValue = mEntry.getValue();
                    if (StringUtils.isBlank(mEntryKey)) {
                        continue;
                    }
                    builder.addHeader(mEntryKey, mEntryValue.toString());
                }
            }

            // body
            if (StringUtils.equalsIgnoreCase(method, "GET")) {
                builder.get();
            } else if (StringUtils.equalsIgnoreCase(method, "POST")) {
                builder.post(body);
            } else if (StringUtils.equalsIgnoreCase(method, "PUT")) {
                builder.put(body);
            } else if (StringUtils.equalsIgnoreCase(method, "DELETE")) {
                builder.delete(body);
            } else {
                throw new BPMException("method is not support", BPMExceptionStatus.METHOD_ERROR);
            }

            Request request = builder.build();
            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("===============================request info start==============================");
                LOGGER.debug("request url=" + org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString(request.url()));
                LOGGER.debug("request method=" + request.method());
                LOGGER.debug("request headers=" + org.apache.commons.lang3.builder.ToStringBuilder.reflectionToString(request.headers()));
                LOGGER.debug("===============================request info end================================");
            }

            // call
            //response = getInstance(sec).newCall(request).execute();
            response = getInstance(null).newCall(request).execute();

            okResponse = new OKResponse();

            okResponse.setStatus(response.code());
            okResponse.setMessage(response.message());
            okResponse.setBodyString(response.body().string());
            okResponse.setHeaders(response.headers().toMultimap());
            okResponse.setRequest(request);

        } finally {
            if (response != null) {
                try {
                    response.body().close();
                    response.close();
                } catch (Exception ex) {
                    LOGGER.error("Response close error.");
                }
            }
        }

        return okResponse;
    }

    /**
     * OkHttp common Response
     *
     * @author tp
     */
    public static class OKResponse {

        /**
         * OkHttp common status
         */
        private int status;

        /**
         * OkHttp common message
         */
        private String message;

        /**
         * OkHttp common headers
         */
        private Map<String, List<String>> headers;

        /**
         * OkHttp common body string
         */
        private String bodyString;

        /**
         * OkHttp common request
         */
        private Request request;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public Map<String, List<String>> getHeaders() {
            return headers;
        }

        public void setHeaders(Map<String, List<String>> headers) {
            this.headers = headers;
        }

        public String getBodyString() {
            return bodyString;
        }

        public void setBodyString(String bodyString) {
            this.bodyString = bodyString;
        }

        public Request getRequest() {
            return request;
        }

        public void setRequest(Request request) {
            this.request = request;
        }
    }
}
