package com.tp.bpmutils.activiti.service.listener;

import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import com.tp.bpmutils.activiti.service.repository.BpmProcinstInfoRepository;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.event.ActivitiEvent;
import org.activiti.engine.delegate.event.ActivitiEventListener;
import org.activiti.engine.delegate.event.impl.ActivitiEntityEventImpl;
import org.activiti.engine.impl.persistence.entity.HistoricProcessInstanceEntityImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.Map;

/**
 * BPM Event Listener<br/>
 * use for runtimeService.addEventListener or Config by ActivitiConfiguration
 *
 * @author
 */
@Component
public class BpmEventListener implements ActivitiEventListener {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BpmEventListener.class);

    /**
     * BPM ProcinstInfoRepository
     */
    private final transient BpmProcinstInfoRepository bpmProcinstInfoRepository;

    /**
     * Activiti RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * BpmEventListener Constructor
     *
     * @param bpmProcinstInfoRepository
     * @param runtimeService
     */
    public BpmEventListener(BpmProcinstInfoRepository bpmProcinstInfoRepository, RuntimeService runtimeService) {
        this.bpmProcinstInfoRepository = bpmProcinstInfoRepository;
        this.runtimeService = runtimeService;
    }

    @Override
    public void onEvent(ActivitiEvent event) {
        switch (event.getType()) {

            case JOB_EXECUTION_SUCCESS:
                LOGGER.info("A job well done!");
                break;

            case JOB_EXECUTION_FAILURE:
                LOGGER.info("A job has failed...");
                break;

            case HISTORIC_PROCESS_INSTANCE_ENDED:
                if (event instanceof ActivitiEntityEventImpl) {
                    ActivitiEntityEventImpl eventImpl = (ActivitiEntityEventImpl) event;
                    Object entity = eventImpl.getEntity();
                    if (entity instanceof HistoricProcessInstanceEntityImpl) {
                        HistoricProcessInstanceEntityImpl hiProcInstEntityImpl = (HistoricProcessInstanceEntityImpl) entity;
                        if (LOGGER.isInfoEnabled()) {
                            LOGGER.info("A process has ended: {}", hiProcInstEntityImpl.getProcessInstanceId());
                        }
                        bpmProcinstInfoRepository.setEndTimeFor(hiProcInstEntityImpl.getEndTime(), hiProcInstEntityImpl.getProcessInstanceId());
                    }
                }
                break;

            case HISTORIC_PROCESS_INSTANCE_CREATED:
                if (event instanceof ActivitiEntityEventImpl) {
                    ActivitiEntityEventImpl eventImpl = (ActivitiEntityEventImpl) event;
                    Object entity = eventImpl.getEntity();
                    if (entity instanceof HistoricProcessInstanceEntityImpl) {
                        HistoricProcessInstanceEntityImpl hiProcInstEntityImpl = (HistoricProcessInstanceEntityImpl) entity;

                        if (LOGGER.isInfoEnabled()) {
                            LOGGER.info("A process has created: {}", hiProcInstEntityImpl.getProcessInstanceId());
                        }
                        if (StringUtils.isNotBlank(hiProcInstEntityImpl.getSuperProcessInstanceId())) {
                            Map<String, Object> variables = runtimeService.getVariables(hiProcInstEntityImpl.getSuperProcessInstanceId());
                            for(Map.Entry<String, Object> entry : variables.entrySet()) {
                                runtimeService.setVariable(hiProcInstEntityImpl.getProcessInstanceId(), entry.getKey(), entry.getValue());
                            }

                            // 子流程，增加寫入「子母流程關系紀錄表」
                            String procInstId = hiProcInstEntityImpl.getProcessInstanceId();
                            String procDefId = hiProcInstEntityImpl.getProcessDefinitionId();
                            Date startTIme = hiProcInstEntityImpl.getStartTime();
                            String sourceProcInstId = hiProcInstEntityImpl.getSuperProcessInstanceId();
                            BpmProcinstInfo bpmProcinstInfo = bpmProcinstInfoRepository.findByProcInstId(sourceProcInstId);
                            String sourceProcDefId = bpmProcinstInfo.getProcDefId();
                            String mainProcInstId = bpmProcinstInfo.getMainProcInstId();
                            String mainProcDefId = bpmProcinstInfo.getMainProcDefId();
                            bpmProcinstInfoRepository.save(new BpmProcinstInfo(procInstId, procDefId, mainProcInstId, mainProcDefId, sourceProcInstId, sourceProcDefId, startTIme, null));
                        }
                    }
                }
                break;

            default:
                if (event instanceof ActivitiEntityEventImpl) {
                    ActivitiEntityEventImpl eventImpl = (ActivitiEntityEventImpl) event;
                    Object entity = eventImpl.getEntity();
                    if (entity instanceof HistoricProcessInstanceEntityImpl) {
                        HistoricProcessInstanceEntityImpl hiProcInstEntityImpl = (HistoricProcessInstanceEntityImpl) entity;
                        if (LOGGER.isInfoEnabled()) {
                            LOGGER.info("A process {} is {}", hiProcInstEntityImpl.getProcessInstanceId(), event.getType());
                        }
                    }
                }
                break;
        }
    }

    @Override
    public boolean isFailOnException() {
        // The logic in the onEvent method of this listener is not critical, exceptions
        // can be ignored if logging fails...
        return false;
    }
}
