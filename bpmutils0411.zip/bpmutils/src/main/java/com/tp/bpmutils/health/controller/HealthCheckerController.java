package com.tp.bpmutils.health.controller;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Health Checker
 */
@RestController
@RequestMapping("healthChecker")
public class HealthCheckerController {

    /**
     * Env name
     */
    @Value("${env.name}")
    private transient String envName;

    /**
     * health Checker
     *
     * @return
     */
    @GetMapping("/entry")
    public String healthChecker() {
        return StringUtils.isEmpty(envName) ? "Production" : envName;
    }
}
