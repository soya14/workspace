package com.tp.bpmutils.activiti.service.repository;

import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

/**
 * 子母流程關聯主檔
 *
 * @author tp
 */
@Repository
public interface BpmProcinstInfoRepository extends CrudRepository<BpmProcinstInfo, String>, JpaSpecificationExecutor<BpmProcinstInfo> {

    /**
     * 依 procInstId 查詢 BpmProcinstInfo
     *
     * @param procInstId
     * @return
     */
    BpmProcinstInfo findByProcInstId(String procInstId);

    /**
     * 依 mainProcInstId 查詢 BpmProcinstInfo 清單
     *
     * @param mainProcInstId
     * @return
     */
    List<BpmProcinstInfo> findByMainProcInstId(String mainProcInstId);

    /**
     * 依 sourceProcInstId 查詢 BpmProcinstInfo 清單
     *
     * @param sourceProcInstId
     * @return
     */
    List<BpmProcinstInfo> findBySourceProcInstId(String sourceProcInstId);

    /**
     * 依 procInstId 清單查詢 BpmProcinstInfo 清單
     *
     * @param procInstIds
     * @return
     */
    List<BpmProcinstInfo> findByProcInstIdIn(List<String> procInstIds);

    /**
     * 依 procInstId 查詢有相同 mainProcInstId 的 BpmProcinstInfo 清單
     *
     * @param procInstId
     * @return
     */
    @Query("select b1 from BpmProcinstInfo b1 inner join BpmProcinstInfo b2 on b1.mainProcInstId = b2.mainProcInstId where b2.procInstId = ?1")
    List<BpmProcinstInfo> findByProcInstIdWithSameMainProcInstId(String procInstId);

    /**
     * 依 procInstId 清單查詢有相同 mainProcInstId 的 BpmProcinstInfo 清單
     *
     * @param procInstIds
     * @return
     */
    @Query("select b1 from BpmProcinstInfo b1 inner join BpmProcinstInfo b2 on b1.mainProcInstId = b2.mainProcInstId where b2.procInstId in (:procInstIds)")
    List<BpmProcinstInfo> findByProcInstIdWithSameMainProcInstIdsIn(@Param("procInstIds") List<String> procInstIds);

    /**
     * 依 procInstId 更新 EndTime
     *
     * @param endTime
     * @param procInstId
     * @return
     */
    @Modifying
    @Query("update BpmProcinstInfo b set b.endTime = ?1 where b.procInstId = ?2")
    int setEndTimeFor(Date endTime, String procInstId);
}
