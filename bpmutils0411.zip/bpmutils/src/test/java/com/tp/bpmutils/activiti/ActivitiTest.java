package com.tp.bpmutils.activiti;

import org.activiti.bpmn.model.BpmnModel;
import org.activiti.bpmn.model.FlowNode;
import org.activiti.bpmn.model.SequenceFlow;
import org.activiti.engine.HistoryService;
import org.activiti.engine.RepositoryService;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.activiti.engine.history.HistoricActivityInstance;
import org.activiti.engine.history.HistoricProcessInstance;
import org.activiti.engine.history.HistoricTaskInstance;
import org.activiti.engine.repository.Deployment;
import org.activiti.engine.runtime.ProcessInstance;
import org.activiti.engine.task.Comment;
import org.activiti.engine.task.Task;
import org.activiti.image.impl.DefaultProcessDiagramGenerator;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Unit Test Activiti
 */
@SpringBootTest
@ExtendWith(SpringExtension.class)
@WebAppConfiguration
public class ActivitiTest {

    /**
     * Logger object
     */
	private static final Logger LOGGER = LoggerFactory.getLogger(ActivitiTest.class);

    /**
     * Activiti RepositoryService
     */
    @Autowired
    private transient RepositoryService repositoryService;

    /**
     * Activiti RuntimeService
     */
    @Autowired
    private transient RuntimeService runtimeService;

    /**
     * Activiti TaskService
     */
    @Autowired
    private transient TaskService taskService;

    /**
     * Activiti HistoryService
     */
    @Autowired
    private transient HistoryService historyService;

    /**
     * static Data Map
     */
    private static final Map<String, Object> DATA_MAP = new ConcurrentHashMap<>();

    /**
     * Default size
     */
    private static final int FLOW_DEFAULT_SIZE = 1;
    
    /**
     * 流程圖部屬
     */
    @Test
    public void deployment() {
        Deployment deployment = repositoryService.createDeployment()
                .addClasspathResource("process/pendingItemSetting.bpmn")
                .category("WORK")
                .name("Pending Item Setting")
                .deploy();
        DATA_MAP.put("deploymentId", deployment.getId());
        LOGGER.info("Deployment: {}", null != deployment ? deployment.toString() : null);
        assertNotNull("deployment is not null", deployment);
    }

    /**
     * Test queryStartEvent
     */
    @Test
    public void queryStartEvent() {

        int count = 1;
        String processInstanceId = MapUtils.getString(DATA_MAP, "processInstanceId");
        while (StringUtils.isBlank(processInstanceId)) {
            try {
                Thread.sleep(100);
                processInstanceId = MapUtils.getString(DATA_MAP, "processInstanceId");
                count++;
            } catch (Exception e) {
                LOGGER.error("", e);
            } finally {
                if (StringUtils.isNotBlank(processInstanceId) || count > 10) {
                    break;
                }
            }
        }

        List<ProcessInstance> instances = null;
        if (StringUtils.isNotBlank(processInstanceId)) {
            instances = runtimeService.createProcessInstanceQuery()
                    .processInstanceId(processInstanceId)
                    .list();
            if (CollectionUtils.isNotEmpty(instances)) {
                instances.forEach(in -> LOGGER.info(in.getProcessInstanceId()));
            }
        } else {
            LOGGER.info("queryStartEvent no processInstanceId");
        }
        assertNotNull("ProcessInstance is not null", instances);
    }

    /**
     * 查詢 ACT_HI_PROCINST Table
     */
    @Test
    public void queryCurrentProcessInstance() {
        List<ProcessInstance> processInstanceList = runtimeService.createProcessInstanceQuery().list();
        if (CollectionUtils.isNotEmpty(processInstanceList)) {
            processInstanceList.forEach(pi ->
                    LOGGER.info("id: " + pi.getId() + " StartUser:" + pi.getStartUserId() + "Name: " + pi.getName()));
        }
        assertNotNull("processInstanceList is not null", processInstanceList);
    }

    /**
     * Test queryTaskAssignee
     */
    @Test
    public void queryTaskAssignee() {
        List<Task> taskList = taskService.createTaskQuery().taskAssignee("2020666_2").list();
        if (CollectionUtils.isNotEmpty(taskList)) {
            taskList.forEach(task -> {
                LOGGER.info("id: {} ,name: {} ,Create Time: {}", null != task ? task.getId() : null, null != task ? task.getName() : null, null != task ? task.getCreateTime() : null);
            });
        }
        assertNotNull("taskList is not null", taskList);
    }

    /**
     * 啟動一案例實例
     */
    @Test
    public void startProcessInstance() {
        Map paramMap = new ConcurrentHashMap();
        ProcessInstance pi = runtimeService.startProcessInstanceById("PendingItemSetting:2:2504", paramMap);
        LOGGER.info("Process instance id : {}", null != pi ?  pi.toString() : null);
        assertNotNull("Process instance id is not null", pi);
    }

    /**
     * Test ShowImg
     */
    @Test
    public void testShowImg() {
//        showCurrentImg("2505");
//        showHisNode("20002");
//        showProcessIMG("2525");
//        showHisNodeAndSequence("2525");
        boolean result = getResourceDiagramInputStream("20445");
        assertTrue("getResourceDiagramInputStream run", result);
    }

    /**
     * 獲取當前節點資訊
     *
     * @param processInstanceId
     */
    public void showCurrentImg(String processInstanceId) {
        HistoricProcessInstance processInstance = historyService
                .createHistoricProcessInstanceQuery()
                .processInstanceId(processInstanceId).singleResult();
        // 获取流程图
        BpmnModel bpmnModel = repositoryService.getBpmnModel(processInstance.getProcessDefinitionId());

        //取得當前的節點
        List<String> activeActivityIds = new ArrayList();

        try {
            activeActivityIds = runtimeService.getActiveActivityIds(processInstanceId);
        } catch (Exception e1) {
            LOGGER.error("error: {}", null != e1 ? e1.getMessage() : null, e1);
        }

        // 这个类在5.22.0往上的版本中才有
        DefaultProcessDiagramGenerator diagramGenerator = new DefaultProcessDiagramGenerator();
        //绘制bpmnModel代表的流程的流程图
        InputStream inputStream = diagramGenerator.generateDiagram(bpmnModel, activeActivityIds, new ArrayList<String>(), "新細明體", "新細明體", "新細明體");
        OutputStream output = null;
        try {
            output = Files.newOutputStream(Paths.get("d:/" + processInstanceId + ".svg"));
            IOUtils.copy(inputStream, output);
        } catch (IOException e) {
            LOGGER.error("error: {}", null != e ? e.getMessage() : null, e);
        } finally {
        	if (null != output) {
        		try {
        			output.close();
        		} catch (Exception e) {
                    LOGGER.error("", e);
        		}
        	}
        	if (null != inputStream) {
        		try {
        			inputStream.close();
        		} catch (Exception e) {
                    LOGGER.error("", e);
        		}
        	}
        }
        LOGGER.info("完成");
    }

    /**
     * 獲取歷史節點(不包含線)
     *
     * @param processInstance
     * @throws IOException 
     */
    public void showHisNode(String processInstance) throws IOException {
        // 先從流程案例取得流程圖資訊(ProcessDefinition)
        HistoricProcessInstance hisProcessInstance = historyService
                .createHistoricProcessInstanceQuery()
                .processInstanceId(processInstance).singleResult();
        BpmnModel bpmnModel = repositoryService.getBpmnModel(hisProcessInstance.getProcessDefinitionId());

        // 查詢歷史節點資料，透過ProcessInstance (act_hi_actinst)
        List<HistoricActivityInstance> hisActIntList = historyService.createHistoricActivityInstanceQuery()
                .processInstanceId(processInstance)
                .list();

        List<String> activityIdList = new ArrayList<>();

        hisActIntList.forEach(hi -> {
            String taskKey = hi.getActivityId();
            activityIdList.add(taskKey);
        });

        DefaultProcessDiagramGenerator defaultProcessDiagramGenerator = new DefaultProcessDiagramGenerator();
        InputStream inputStream = defaultProcessDiagramGenerator.generateDiagram(bpmnModel, activityIdList, new ArrayList(), "新細明體", "新細明體", "新細明體");
        OutputStream output = null;
        try {
            output = Files.newOutputStream(Paths.get("d:/" + processInstance + ".svg"));
            IOUtils.copy(inputStream, output);
        } catch (IOException e) {
            LOGGER.error("error: {}", null != e ? e.getMessage() : null, e);
        } finally {
        	if (null != output) {
        		try {
        			output.close();
        		} catch (Exception e) {
                    LOGGER.error("", e);
        		}
        	}
        	inputStream.close();
        }
        LOGGER.info("完成");
    }

    /**
     * 獲取歷史流程圖
     * @throws IOException 
     */
    public void showHisNodeAndSequence(String processInstance) throws IOException {
        // 先從流程案例取得流程圖資訊(ProcessDefinition)
        HistoricProcessInstance hisProcessInstance = historyService.createHistoricProcessInstanceQuery()
                .processInstanceId(processInstance)
                .singleResult();
        BpmnModel bpmnModel = repositoryService.getBpmnModel(hisProcessInstance.getProcessDefinitionId());

        // 查詢歷史節點資料，透過ProcessInstance (act_hi_actinst)
        List<HistoricActivityInstance> hisActIntList = historyService.createHistoricActivityInstanceQuery()
                .processInstanceId(processInstance)
//                .orderByHistoricActivityInstanceStartTime()
//                .asc()
                .list();

        List<String> highLightedFlowIds = new ArrayList<>();
        // 所有節點資訊
        List<FlowNode> flowNodeList = new ArrayList<>();
        // 已完成的歷史資訊(正在進行中的節點不會置入)
        List<HistoricActivityInstance> finishedActivityInstnace = new ArrayList<>();
        List<String> generateFlowNode = new ArrayList<>();

        hisActIntList.forEach(hi -> {
            FlowNode flowNode = (FlowNode) bpmnModel.getMainProcess().getFlowElement(hi.getActivityId(), true);
            flowNodeList.add(flowNode);
            generateFlowNode.add(hi.getActivityId());
            if (hi.getEndTime() != null) {
                finishedActivityInstnace.add(hi);
            }
        });
        FlowNode currentFlowNode = null;
        FlowNode targetFlowNode = null;
        for (HistoricActivityInstance historicActivityInstance : finishedActivityInstnace) {
            currentFlowNode = (FlowNode) bpmnModel.getMainProcess().getFlowElement(historicActivityInstance.getActivityId(), true);
            List<SequenceFlow> sequenceFlowList = currentFlowNode.getOutgoingFlows();
            String activityType = historicActivityInstance.getActivityType();
            if (StringUtils.equals("parallelGateway", activityType) || StringUtils.equals("inclusiveGateway", activityType)) {
                // 遍历历史活动节点，找到匹配流程目标节点的
                for (SequenceFlow sequenceFlow : sequenceFlowList) {
                    targetFlowNode = (FlowNode) bpmnModel.getMainProcess().getFlowElement(sequenceFlow.getTargetRef(), true);
                    if (flowNodeList.contains(targetFlowNode)) {
                        highLightedFlowIds.add(targetFlowNode.getId());
                    }
                }
            } else {
                List<Map<String, Object>> tempMapList = new ArrayList<>();
                for (SequenceFlow sequenceFlow : sequenceFlowList) {
                    for (HistoricActivityInstance instance : hisActIntList) {
                        if (instance.getActivityId().equals(sequenceFlow.getTargetRef())) {
                            Map<String, Object> map = new ConcurrentHashMap<>();
                            map.put("highLightedFlowId", sequenceFlow.getId());
                            map.put("highLightedFlowStartTime", instance.getStartTime().getTime());
                            tempMapList.add(map);
                        }
                    }
                }
                if (CollectionUtils.isNotEmpty(tempMapList)) {
                    // 遍历匹配的集合，取得开始时间最早的一个
                    long earliestStamp = 0L;
                    String highLightedFlowId = null;
                    for (Map<String, Object> map : tempMapList) {
                        long highLightedFlowStartTime = Long.parseLong(map.get("highLightedFlowStartTime").toString());
                        if (earliestStamp == 0 || earliestStamp >= highLightedFlowStartTime) {
                            highLightedFlowId = map.get("highLightedFlowId").toString();
                            earliestStamp = highLightedFlowStartTime;
                        }
                    }
                    highLightedFlowIds.add(highLightedFlowId);
                }
            }
        }
        LOGGER.info("############# ===>>>>{}", null != highLightedFlowIds ? highLightedFlowIds : null);
        DefaultProcessDiagramGenerator defaultProcessDiagramGenerator = new DefaultProcessDiagramGenerator();
        InputStream inputStream = defaultProcessDiagramGenerator.generateDiagram(bpmnModel, generateFlowNode, highLightedFlowIds, "新細明體", "新細明體", "新細明體");
        OutputStream output = null;
        try {
            output = Files.newOutputStream(Paths.get("d:/" + processInstance + ".svg"));
            IOUtils.copy(inputStream, output);
        } catch (IOException e) {
            LOGGER.error("error: {}", null != e ? e.getMessage() : null, e);
        } finally {
        	if (null != output) {
        		try {
        			output.close();
        		} catch (Exception e) {
                    LOGGER.error("", e);
        		}
        	}
        	inputStream.close();
        }
        LOGGER.info("完成");
    }

    /**
     * 依processInstanceId取得流程圖InputStream
     *
     * @param id
     */
    public boolean getResourceDiagramInputStream(String id) {
    	InputStream imageStream = null;
    	OutputStream output =  null;
        try {
            // 获取历史流程实例
            HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(id).singleResult();
            // 获取流程中已经执行的节点，按照执行先后顺序排序
            List<HistoricActivityInstance> historicActivityInstanceList = historyService.createHistoricActivityInstanceQuery().processInstanceId(id).orderByHistoricActivityInstanceId().asc().list();
            // 构造已执行的节点ID集合
            List<String> executedActivityIdList = new ArrayList<String>();
            for (HistoricActivityInstance activityInstance : historicActivityInstanceList) {
                executedActivityIdList.add(activityInstance.getActivityId());
            }
            // 获取bpmnModel
            BpmnModel bpmnModel = repositoryService.getBpmnModel(historicProcessInstance.getProcessDefinitionId());
            // 获取流程已发生流转的线ID集合
            List<String> flowIds = this.getExecutedFlows(bpmnModel, historicActivityInstanceList);

            DefaultProcessDiagramGenerator processDiagramGenerator = new DefaultProcessDiagramGenerator();
            imageStream = processDiagramGenerator.generateDiagram(bpmnModel, executedActivityIdList, flowIds, "新細明體", "新細明體", "新細明體");
            output = Files.newOutputStream(Paths.get("d:/" + id + ".svg"));
            IOUtils.copy(imageStream, output);
        } catch (Exception e) {
            LOGGER.error("error: {}", null != e ? e.getMessage() : null, e);
            return false;
        } finally {
        	if (null != output) {
        		try {
        			output.close();
        		} catch (Exception e) {
                    LOGGER.error("", e);
        		}
        	}
        	if (null != imageStream) {
        		try {
        			imageStream.close();
        		} catch (Exception e) {
                    LOGGER.error("", e);
        		}
        	}
        }
        return true;
    }

    private List<String> getExecutedFlows(BpmnModel bpmnModel,
                                          List<HistoricActivityInstance> historicActivityInstanceList) {
        List<String> executedFlowIdList = new ArrayList<>();
        for (int i = 0; i < historicActivityInstanceList.size() - 1; i++) {
            HistoricActivityInstance hai = historicActivityInstanceList.get(i);
            FlowNode flowNode = (FlowNode) bpmnModel.getFlowElement(hai.getActivityId());
            List<SequenceFlow> sequenceFlows = flowNode.getOutgoingFlows();
            if (sequenceFlows.size() > FLOW_DEFAULT_SIZE) {
                HistoricActivityInstance nextHai = historicActivityInstanceList.get(i + 1);
                sequenceFlows.forEach(sequenceFlow -> {
                    if (sequenceFlow.getTargetFlowElement().getId().equals(nextHai.getActivityId())) {
                        executedFlowIdList.add(sequenceFlow.getId());
                    }
                });
            } else if (sequenceFlows.size() == FLOW_DEFAULT_SIZE) {
                executedFlowIdList.add(sequenceFlows.get(0).getId());
            }
        }
        return executedFlowIdList;
    }

    /**
     * Test queryTask
     */
    @Test
    public void queryTask() {
        HistoricTaskInstance his = historyService.createHistoricTaskInstanceQuery().taskId("2523").singleResult();
        assertNotNull("his is not null", his);
    }

    /**
     * Test getProcessComments
     */
    @Test
    public void getProcessCommentsTest() {
        List<Comment> commentList = getProcessComments("72691");
        commentList.forEach(comment -> {
            LOGGER.info("Comment: {}", null != comment ? comment.toString() : null);
        });
        assertNotNull("commentList is not null", commentList);
    }

    /**
     * 依processInstanceId取得備註清單
     *
     * @param processInstanceId
     * @return
     */
    public List<Comment> getProcessComments(String processInstanceId) {
        List<Comment> historyCommnets = new ArrayList<>();
        List<HistoricActivityInstance> hais = historyService.createHistoricActivityInstanceQuery().processInstanceId(processInstanceId).activityType("userTask").list();
        for (HistoricActivityInstance hai : hais) {
            String historytaskId = hai.getTaskId();
            List<Comment> comments = taskService.getTaskComments(historytaskId);
            if (CollectionUtils.isNotEmpty(comments)) {
                historyCommnets.addAll(comments);
            }
        }
        return historyCommnets;
    }
}
