package com.tp.bpmutils.common.constant;

/**
 * Activiti constant
 */
public class ActivitiConst {

    /**
     * Type: candidateGroup
     */
    public static final String CANDIDATE_GROUP = "candidateGroup";

    /**
     * Type: candidateUser
     */
    public static final String CANDIDATE_USER = "candidateUser";
}
