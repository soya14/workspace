package com.tp.bpmutils.activiti.delegate;

import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import com.tp.bpmutils.activiti.service.repository.BpmProcinstInfoRepository;
import org.activiti.bpmn.model.FieldExtension;
import org.activiti.engine.RuntimeService;
import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.impl.persistence.entity.ExecutionEntityImpl;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * callActivity 子流程中取得父流程中變數
 *
 * @author tp
 */
@Service("callActivityGetSuperVariablesDelegate")
public class CallActivityGetSourceVariablesDelegate implements ExecutionListener {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(CallActivityGetSourceVariablesDelegate.class);

    private static final long serialVersionUID = -1062639439583143194L;

    /**
     * Activiti's RuntimeService
     */
    private final transient RuntimeService runtimeService;

    /**
     * BPM ProcinstInfoRepository
     */
    private final transient BpmProcinstInfoRepository bpmProcinstInfoRepository;

    /**
     * CallActivityGetSuperVariablesDelegate's constructor
     *
     * @param runtimeService
     */
    public CallActivityGetSourceVariablesDelegate(RuntimeService runtimeService, BpmProcinstInfoRepository bpmProcinstInfoRepository) {
        this.runtimeService = runtimeService;
        this.bpmProcinstInfoRepository = bpmProcinstInfoRepository;
    }

    @Override
    public void notify(DelegateExecution execution) {
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("Variables: {}", execution.getVariables());
        }
        // 依照fieldName 與stringValue 指定流程對應變數
        Map<String, FieldExtension> assignFieldMap = new HashMap<>();
        // set the value into bpm_procinst_info table (儲存 bpm_procinst_info 所需資訊)
        String processInstanceId = execution.getProcessInstanceId();
        String processDefinitionId = execution.getProcessDefinitionId();
        String mainProcessInstanceId = null;
        String mainProcessDefinitionId = null;
        String sourceProcessInstanceId = null;
        String sourceProcessDefinitionId = null;
        Date startTime = null;

        if (execution instanceof ExecutionEntityImpl) {
            ExecutionEntityImpl impl = (ExecutionEntityImpl) execution;
            startTime = impl.getStartTime();
            sourceProcessInstanceId = impl.getParent().getSuperExecution().getProcessInstanceId();
            sourceProcessDefinitionId = impl.getParent().getSuperExecution().getProcessDefinitionId();
            if (CollectionUtils.isNotEmpty(impl.getCurrentActivitiListener().getFieldExtensions())) {
                impl.getCurrentActivitiListener().getFieldExtensions().forEach(fieldExtension -> {
                    assignFieldMap.put(fieldExtension.getFieldName(), fieldExtension);
                });
            }
        }
        // query super process's variables (取得父流程參數)
        Map<String, Object> variables = runtimeService.getVariables(sourceProcessInstanceId);

        // set into this process's variables (將父流程參數塞入本流程)
        for (Map.Entry<String, Object> entry : variables.entrySet()) {
            if (assignFieldMap.containsKey(entry.getKey())) {
                execution.setVariable(assignFieldMap.get(entry.getKey()).getStringValue(), entry.getValue());
            }
        }

        // query super process's info , we need it's mainProcInstId and mainProcDefId (取得父流程資訊，需要主流程資訊)
        BpmProcinstInfo sourceBpmPricunstInfo = bpmProcinstInfoRepository.findByProcInstId(sourceProcessInstanceId);
        mainProcessInstanceId = sourceBpmPricunstInfo.getMainProcInstId();
        mainProcessDefinitionId = sourceBpmPricunstInfo.getMainProcDefId();
        LOGGER.debug("processInstanceId:{}, processDefinitionId:{},mainProcessInstanceId :{}, mainProcessDefinitionId:{},sourceProcessInstanceId:{}, sourceProcessDefinitionId:{},startTime:{}",
                processInstanceId, processDefinitionId,
                mainProcessInstanceId, mainProcessDefinitionId,
                sourceProcessInstanceId, sourceProcessDefinitionId,
                startTime);
        try {
            bpmProcinstInfoRepository.save(
                    new BpmProcinstInfo(
                            processInstanceId, processDefinitionId,
                            mainProcessInstanceId, mainProcessDefinitionId,
                            sourceProcessInstanceId, sourceProcessDefinitionId,
                            startTime, null
                    )
            );
        } catch (Exception e) {
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error("callActivityGetSuperVariablesDelegate save error :{}", e.getMessage());
            }
        }


    }
}
