package com.tp.bpmutils.common.config;

import ch.qos.logback.core.PropertyDefinerBase;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * LogFolder Definer
 */
public class LogFolderDefiner extends PropertyDefinerBase {

    /**
     * folderName
     */
    private static String folderName;

    @Override
    public String getPropertyValue() {
        if (StringUtils.isBlank(folderName)) {
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
            folderName = LocalDateTime.now().format(dateTimeFormatter);
        }
        return folderName;
    }
}
