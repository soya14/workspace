package com.tp.bpmutils.activiti.vo;

import com.tp.bpmutils.activiti.entity.ActHiComment;
import com.tp.bpmutils.activiti.entity.BpmProcinstInfo;
import com.tp.bpmutils.common.util.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import org.activiti.engine.history.HistoricActivityInstance;

/**
 * 目前停留節點資訊
 */
@Schema(description = "目前停留節點資訊")
public class ActivitiCurrentTaskVo extends ActivitiTaskVo {

    /**
     *
     */
    private static final long serialVersionUID = 8557319183022167936L;

    /**
     * 前一關任務名稱
     */
    @Schema(description = "前一關任務名稱")
    private String lastTaskName;

    /**
     * 前一關審核員工編號
     */
    @Schema(description = "前一關審核員工編號")
    private String lastCompleteUserId;

    /**
     * 前一關審核時間
     */
    @Schema(description = "前一關審核時間")
    private String lastCompleteTime;

    /**
     * ActivitiCurrentTaskVo 1
     */
    public ActivitiCurrentTaskVo() {
        super();
    }

    /**
     * ActivitiCurrentTaskVo 2
     *
     * @param historicActivityInstance
     * @param candidateGroup
     * @param candidateUser
     * @param lastTaskName
     * @param comment
     */
    public ActivitiCurrentTaskVo(HistoricActivityInstance historicActivityInstance, String candidateGroup, String candidateUser, String lastTaskName, ActHiComment comment) {
        super(historicActivityInstance, candidateGroup, candidateUser);
        this.lastTaskName = lastTaskName;
        if (comment != null) {
            this.lastCompleteUserId = comment.getUserId();
            this.lastCompleteTime = DateUtil.dateToString(comment.getTime(), DateUtil.PATTEN_YEAR_MONTH_DAY_FULL_TIME);
        }
    }

    /**
     * ActivitiCurrentTaskVo 3
     *
     * @param historicActivityInstance
     * @param candidateGroup
     * @param candidateUser
     * @param lastTaskName
     * @param comment
     */
    public ActivitiCurrentTaskVo(HistoricActivityInstance historicActivityInstance, String candidateGroup, String candidateUser, String lastTaskName, ActHiComment comment, BpmProcinstInfo bpmProcinstInfo) {
        super(historicActivityInstance, candidateGroup, candidateUser, bpmProcinstInfo);
        this.lastTaskName = lastTaskName;
        if (comment != null) {
            this.lastCompleteUserId = comment.getUserId();
            this.lastCompleteTime = DateUtil.dateToString(comment.getTime(), DateUtil.PATTEN_YEAR_MONTH_DAY_FULL_TIME);
        }
    }

    public String getLastTaskName() {
        return lastTaskName;
    }

    public void setLastTaskName(String lastTaskName) {
        this.lastTaskName = lastTaskName;
    }

    public String getLastCompleteUserId() {
        return lastCompleteUserId;
    }

    public void setLastCompleteUserId(String lastCompleteUserId) {
        this.lastCompleteUserId = lastCompleteUserId;
    }

    public String getLastCompleteTime() {
        return lastCompleteTime;
    }

    public void setLastCompleteTime(String lastCompleteTime) {
        this.lastCompleteTime = lastCompleteTime;
    }
}
