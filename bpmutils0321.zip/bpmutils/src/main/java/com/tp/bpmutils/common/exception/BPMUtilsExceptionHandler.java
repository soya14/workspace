package com.tp.bpmutils.common.exception;

import com.tp.bpmutils.activiti.response.MwHeaderResponse;
import com.tp.bpmutils.activiti.response.ResponseTemplate;
import com.tp.bpmutils.common.controller.BaseController;
import com.tp.bpmutils.common.util.BPMApiResponse;
import org.activiti.engine.ActivitiObjectNotFoundException;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.multipart.MultipartException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.UUID;

/**
 * BPM Exception Handler
 *
 * @author tp
 */
@RestControllerAdvice
public class BPMUtilsExceptionHandler {

    /**
     * Logger object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BPMUtilsExceptionHandler.class);

    /**
     * Exception Handler
     *
     * @param request
     * @param response
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ResponseTemplate<Map<String, Object>> handleException(HttpServletRequest request, HttpServletResponse response, Exception e) {

        if (LOGGER.isErrorEnabled()) {
            LOGGER.error(e.getMessage(), e);
        }

        int status = 0;
        String message = null;
        BPMExceptionStatus bpmExceptionStatus = null;

        if (e instanceof BPMException) {

            int code = ((BPMException) e).getCode();
            LOGGER.error("code: {}", code);

            if (code >= 100 && code < 600) {
                status = code;
            }

            message = ((BPMException) e).getMsg();
            bpmExceptionStatus = ((BPMException) e).getStatus();
        }

        if (0 == status) {
            if (HttpStatus.valueOf(response.getStatus()).is2xxSuccessful()) {
                if (LOGGER.isErrorEnabled()) {
                    LOGGER.error("this status: {}", response.getStatus());
                }
                if (e instanceof HttpRequestMethodNotSupportedException) {
                    status = HttpStatus.METHOD_NOT_ALLOWED.value();
                } else if (e instanceof HttpMediaTypeNotAcceptableException || e instanceof HttpMediaTypeNotSupportedException) {
                    status = HttpStatus.UNSUPPORTED_MEDIA_TYPE.value();
                } else if (e instanceof ActivitiObjectNotFoundException) {
                    status = HttpStatus.BAD_REQUEST.value();
                } else if (e instanceof MultipartException) {
                    status = HttpStatus.BAD_REQUEST.value();
                    if (StringUtils.isBlank(message)) {
                        message = BPMException.getInputParameterError("[INPUT FILE]");
                        bpmExceptionStatus = BPMExceptionStatus.INPUT_PARAMETER_ERROR;
                    }
                } else {
                    status = HttpStatus.INTERNAL_SERVER_ERROR.value();
                }
            } else {
                status = response.getStatus();
            }
        }

        if (StringUtils.isBlank(message)) {
            message = e.getMessage();
            if (StringUtils.isBlank(message)) {
                message = BPMExceptionStatus.SYSTEM_ERROR.msg();
            }
        }

        if (null == bpmExceptionStatus) {
            bpmExceptionStatus = BPMExceptionStatus.SYSTEM_ERROR;
        }

        response.setStatus(status);

        // 處理 Header 中 Error Code
        handleHeaderErrorCode(response, status, bpmExceptionStatus);

        // 處理 Header 中 Server 端資訊
        handleHeaderServerInfo(response);

        // return BPMApiResponse.fail(message);

        Map<String, Object> reqData = BaseController.getReqData();
        String msgId = MapUtils.getString(reqData, "MSGID");
        String sourceChannel = MapUtils.getString(reqData, "SOURCECHANNEL");
        String txnSeq = MapUtils.getString(reqData, "TXNSEQ");

        MwHeaderResponse mwHeader = new MwHeaderResponse();
        mwHeader.setMsgId(msgId);
        mwHeader.setSourceChannel(sourceChannel);
        mwHeader.setTxnSeq(txnSeq);
        mwHeader.setReturnCode(BPMApiResponse.CODE_FAIL);
        mwHeader.setReturnDesc(message);

        return new ResponseTemplate<Map<String, Object>>(mwHeader);
    }

    /**
     * 處理 Header 中 Error Code
     *
     * @param response
     * @param status
     * @param bpmExceptionStatus
     */
    private void handleHeaderErrorCode(HttpServletResponse response, int status, BPMExceptionStatus bpmExceptionStatus) {
        HttpStatus httpStatus = HttpStatus.valueOf(status);
        if (httpStatus.is4xxClientError() || httpStatus.is5xxServerError()) {
            response.setHeader("X-Error-Code", bpmExceptionStatus.code() + "." + bpmExceptionStatus.description());
//            response.setHeader("X-Error-Msg", bpmExceptionStatus.description());
        }
    }

    /**
     * 處理 Header 中 Server 端資訊
     *
     * @param response
     */
    private void handleHeaderServerInfo(HttpServletResponse response) {
        if (null == response.getHeader("X-Server-TraceId")) {
            String xServerTraceId = UUID.randomUUID().toString();
            response.setHeader("X-Server-TraceId", xServerTraceId);
            response.setHeader("X-Server-Date", DateTimeFormatter.RFC_1123_DATE_TIME
                    .withZone(ZoneOffset.UTC)
                    .format(Instant.now()));
        }
    }

}
