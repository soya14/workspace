package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import com.tp.bpmutils.activiti.vo.ActivitiHistoryTaskInstanceVo;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 查詢案件回覆
 *
 * @author tp
 */
@Schema(description = "查詢案件回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiQueryProcessInstanceResp {

    /**
     * 案件資訊
     */
    @Schema(description = "案件資訊")
    private List<ActivitiHistoryTaskInstanceVo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiQueryProcessInstanceResp success(List<ActivitiHistoryTaskInstanceVo> data) {
        ActivitiQueryProcessInstanceResp apiSuccess = new ActivitiQueryProcessInstanceResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public List<ActivitiHistoryTaskInstanceVo> getData() {
        return data;
    }

    public void setData(List<ActivitiHistoryTaskInstanceVo> data) {
        this.data = data;
    }
}
