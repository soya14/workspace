package com.tp.bpmutils.activiti.service;

import java.util.List;
import java.util.Map;

/**
 * 處理 Activiti Common 服務介面
 *
 * @author tp
 */
public interface IActivitiCommonService {

    /**
     * 取得任務的候選角色及成員清單
     *
     * @param taskIds
     * @return
     */
    Map<String, Map<String, List<String>>> getCandidateListByTaskIds(List<String> taskIds);

    /**
     * 取得任務的候選角色及成員
     *
     * @param taskIds
     * @return
     */
    Map<String, Map<String, StringBuilder>> getCandidateByTaskIds(List<String> taskIds);

    /**
     * 取得歷史任務的候選角色及成員
     *
     * @param taskIds
     * @return
     */
    Map<String, Map<String, StringBuilder>> getHiCandidateByTaskIds(List<String> taskIds);

    /**
     * 取得任務的候選角色
     *
     * @param candidateMap
     * @param taskId
     * @return
     */
    String getCandidateGroupByTaskId(Map<String, Map<String, StringBuilder>> candidateMap, String taskId);

    /**
     * 取得任務的候選成員
     *
     * @param candidateMap
     * @param taskId
     * @return
     */
    String getCandidateUserByTaskId(Map<String, Map<String, StringBuilder>> candidateMap, String taskId);
}
