package com.tp.bpmutils.activiti.service;

import com.tp.bpmutils.activiti.request.*;
import com.tp.bpmutils.activiti.response.ActivitiQueryPendingCountResp;
import com.tp.bpmutils.activiti.vo.ActivitiCurrentTaskVo;
import com.tp.bpmutils.activiti.vo.ActivitiHistoryTaskInstanceVo;
import com.tp.bpmutils.activiti.vo.ActivitiMainSubVo;
import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;

import java.util.List;

/**
 * 處理 Activiti Query 服務介面
 *
 * @author tp
 */
public interface IActivitiQueryService {

    /**
     * 查詢待審清單
     *
     * @param req
     * @return
     */
    List<ActivitiTaskVo> getTodoList(ActivitiQueryPendingReq req);

    /**
     * 查詢待審數量
     *
     * @param req
     * @return
     */
    List<ActivitiQueryPendingCountResp.ActivitiPendingProcess> getTodoListCounting(ActivitiQueryPendingCountReq req);

    /**
     * 查詢當前節點
     *
     * @param req
     * @return
     */
    ActivitiTaskVo getTaskInfo(ActivitiQueryTaskReq req);

    /**
     * 取得流程變數
     *
     * @param activitiQueryProcessInstanceReq
     */
    ActivitiMainSubVo getProcessVariables(ActivitiQueryProcessInstanceReq activitiQueryProcessInstanceReq);

    /**
     * 取得流程變數
     *
     * @param activitiQueryProcessVariableReq
     */
    ActivitiMainSubVo getProcessVariable(ActivitiQueryProcessVariableReq activitiQueryProcessVariableReq);

    /**
     * 目前停留在那些節點(含前一關)
     *
     * @param activitiQueryCurrentTaskReq
     * @return
     */
    List<ActivitiCurrentTaskVo> getCurrentTasks(ActivitiQueryCurrentTaskReq activitiQueryCurrentTaskReq);

    /**
     * 查詢案件 審核歷程 (By Process Instance)
     *
     * @param req
     */
    List<ActivitiHistoryTaskInstanceVo> queryProcessInstanceHis(ActivitiQueryProcessInstanceReq req);
}
