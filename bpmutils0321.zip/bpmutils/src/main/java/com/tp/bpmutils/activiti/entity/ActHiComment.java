package com.tp.bpmutils.activiti.entity;

import org.apache.commons.lang3.ArrayUtils;
import org.hibernate.annotations.Type;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import java.util.Date;

/**
 * Historic Comment entity
 */
@Entity
public class ActHiComment {

    /**
     * ID
     */
    @Id
    @Column(name = "ID_")
    private String id;

    /**
     * 備註類型
     */
    @Column(name = "TYPE_")
    private String type;

    /**
     * 備註時間
     */
    @Column(name = "TIME_")
    private Date time;

    /**
     * 備註人員ID
     */
    @Column(name = "USER_ID_")
    private String userId;

    /**
     * 任務編號
     */
    @Column(name = "TASK_ID_")
    private String taskId;

    /**
     * 流程實例代號
     */
    @Column(name = "PROC_INST_ID_")
    private String procInstId;

    /**
     * 行為類型
     */
    @Column(name = "ACTION_")
    private String action;

    /**
     * 備註內容
     */
    @Column(name = "MESSAGE_")
    private String message;

    /**
     * 備註全部內容
     */
    @Type( type = "org.hibernate.type.BinaryType" ) //for postgreSql
    @Lob
    @Column(name = "FULL_MSG_")
    private byte[] fullMsg;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getProcInstId() {
        return procInstId;
    }

    public void setProcInstId(String procInstId) {
        this.procInstId = procInstId;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public byte[] getFullMsg() {
        return fullMsg.clone();
    }

    public void setFullMsg(byte[] fullMsg) {
        this.fullMsg = ArrayUtils.clone(fullMsg);
    }
}
