package com.tp.bpmutils.activiti.mybatis.mapper;

import com.tp.bpmutils.activiti.vo.ActivitiTaskVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * ActRuTask Mapper
 */
public interface ActRuTaskMapper {

    /**
     *  依 EmpCode 清單及 CandidateGroup 清單查詢任務
     *
     * @param empCodes
     * @param candidateGroups
     * @return
     */
    List<ActivitiTaskVo> getTodoList(@Param("empCodes") List<String> empCodes, @Param("candidateGroups") List<String> candidateGroups);

}
