package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 移除原本的處理者回覆
 *
 * @author tp
 */
@Schema(description = "移除原本的處理者回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiDeleteCandidateUserResp {

    /**
     * 結果
     */
    @Schema(description = "結果", example = "true")
    private Boolean data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiDeleteCandidateUserResp success(Boolean data) {
        ActivitiDeleteCandidateUserResp apiSuccess = new ActivitiDeleteCandidateUserResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }
}
