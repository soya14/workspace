package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

/**
 * 新增處理者回覆
 *
 * @author tp
 */
@Schema(description = "新增處理者回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiAddCandidateUserResp {

    /**
     * 結果
     */
    @Schema(description = "結果", example = "true")
    private Boolean data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiAddCandidateUserResp success(Boolean data) {
        ActivitiAddCandidateUserResp apiSuccess = new ActivitiAddCandidateUserResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public Boolean getData() {
        return data;
    }

    public void setData(Boolean data) {
        this.data = data;
    }
}
