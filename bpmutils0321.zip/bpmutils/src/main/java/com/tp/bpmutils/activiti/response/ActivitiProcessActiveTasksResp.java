package com.tp.bpmutils.activiti.response;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

/**
 * 查詢流程定義任務回覆
 *
 * @author tp
 */
@Schema(description = "查詢流程定義任務回覆")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiProcessActiveTasksResp {

    /**
     * 定義任務
     */
    @ArraySchema(arraySchema = @Schema(description = "定義任務"))
    private List<ElementInfo> data;

    /**
     * Success Result
     *
     * @param data
     * @return
     */
    public static ActivitiProcessActiveTasksResp success(List<ElementInfo> data) {
        ActivitiProcessActiveTasksResp apiSuccess = new ActivitiProcessActiveTasksResp();
        apiSuccess.setData(data);
        return apiSuccess;
    }

    public List<ElementInfo> getData() {
        return data;
    }

    public void setData(List<ElementInfo> data) {
        this.data = data;
    }

    /**
     * 流程任務元素資訊回覆
     */
    @JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
    @Schema(description = "流程任務元素資訊回覆")
    public static class ElementInfo {

        /**
         * 元素類型
         */
        @Schema(description = "元素類型")
        private String elementType;

        /**
         * 元素編號
         */
        @Schema(description = "元素編號")
        private String elementId;

        /**
         * 元素名稱
         */
        @Schema(description = "元素名稱")
        private String elementName;

        public String getElementType() {
            return elementType;
        }

        public void setElementType(String elementType) {
            this.elementType = elementType;
        }

        public String getElementId() {
            return elementId;
        }

        public void setElementId(String elementId) {
            this.elementId = elementId;
        }

        public String getElementName() {
            return elementName;
        }

        public void setElementName(String elementName) {
            this.elementName = elementName;
        }
    }
}
