package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import static io.swagger.v3.oas.annotations.media.Schema.AccessMode.READ_ONLY;

/**
 * 新增處理群組請求
 *
 * @author tp
 */
@Schema(description = "新增處理群組請求")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiAddCandidateGroupReq {

    /**
     * Check Param
     */
    protected static final String[] REQUIRED_PARAM = {"taskId", "group"};
    /**
     * Check Multi Choice Param
     */
    protected static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 任務編號
     */
    @Schema(description = "任務編號：5", required = true)
    private String taskId;

    /**
     * 增加群組
     */
    @Schema(description = "要增加哪個群組：1", required = true)
    private String group;

    /**
     * Get Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    /**
     * Get Multi Choice Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
