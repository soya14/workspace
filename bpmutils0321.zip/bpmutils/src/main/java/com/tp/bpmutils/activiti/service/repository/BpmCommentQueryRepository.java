package com.tp.bpmutils.activiti.service.repository;

import com.tp.bpmutils.activiti.entity.ActHiComment;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * BPM Comment Repository
 */
public interface BpmCommentQueryRepository extends Repository<ActHiComment, String> {

    /**
     * 依 procInstId 清單查詢 Comment 清單
     *
     * @param procInstIds
     * @return
     */
    @Query(value = "select distinct RES " +
            " from ActHiComment RES " +
            " WHERE ( RES.procInstId IN :PROCINSTIDS ) ")
    List<ActHiComment> findByProcInstIdIn(@Param("PROCINSTIDS") List<String> procInstIds);
}
