package com.tp.bpmutils.common.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import java.util.ArrayList;
import java.util.List;

/**
 * Swagger config
 */
@Configuration
public class SwaggerConfig {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(SwaggerConfig.class);

    /**
     * Environment
     */
    @Autowired
    private transient Environment environment;

    /**
     * Servers url list
     */
    @Value("#{'${swagger.servers}'.split(',')}")
    private transient List<String> servers;

    /**
     * Create GroupedOpenApi
     *
     * @return
     */
    @Bean
    public GroupedOpenApi publicApi() {

        String customPath = environment.getProperty("swagger.customPath");
        String pathMapping = environment.getProperty("swagger.pathMapping");

        if (StringUtils.equals("Y", customPath)) {
            return GroupedOpenApi.builder()
                    .group("bpmutils API")
                    .pathsToMatch(pathMapping)
                    .build();
        } else {
            return GroupedOpenApi.builder()
                    .group("bpmutils API")
                    .pathsToMatch("/**")
                    .build();
        }
    }

    /**
     * Springdoc Bean
     *
     * @return
     */
    @Bean
    public OpenAPI springDocOpenAPI() {

        String version = environment.getProperty("swagger.version");

        LOGGER.info("servers: {}", servers);

        // 接口測試路徑
        List<Server> serverList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(servers)) {
            for (String url : servers) {
                Server server = new Server();
                server.setUrl(url);
                serverList.add(server);
            }
        }

        return new OpenAPI()
                .servers(serverList)
                .info(new Info().title("bpmutils API")
                        .description("bpmutils API")
                        .version(version));
    }
}