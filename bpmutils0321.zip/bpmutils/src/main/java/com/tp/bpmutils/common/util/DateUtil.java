package com.tp.bpmutils.common.util;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Date Util
 */
public class DateUtil {

    /**
     * Logger Object
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtil.class);

    /**
     * yyyy/MM/dd HH:mm:ss
     */
    public static final String PATTEN_YEAR_MONTH_DAY_FULL_TIME = "yyyy/MM/dd HH:mm:ss";

    /**
     * Date 轉字串
     * @param date
     * @param pattern
     * @return
     */
    public static String dateToString(Date date, String pattern){
        String str = "";
        try {
            if (date != null) {
                DateFormat dateFormat = new SimpleDateFormat(pattern, Locale.getDefault(Locale.Category.FORMAT));
                str = dateFormat.format(date);
            }
        } catch (Exception e){
            if (LOGGER.isErrorEnabled()) {
                LOGGER.error(e.getMessage(), e);
            }
        }
        return str;
    }

    /**
     * 字符串轉換成日期
     *
     * @param strDate 日期字符串
     * @param pattern 日期的格式，如：DateUtils.DATE_TIME_PATTERN
     */
    public static Date stringToDate(String strDate, String pattern) {
        if (StringUtils.isBlank(strDate)) {
            return null;
        }

        DateTimeFormatter fmt = DateTimeFormat.forPattern(pattern);
        return fmt.parseLocalDateTime(strDate).toDate();
    }

}
