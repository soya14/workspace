package com.tp.bpmutils.activiti.request;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import io.swagger.v3.oas.annotations.media.Schema;

import static io.swagger.v3.oas.annotations.media.Schema.AccessMode.READ_ONLY;

/**
 * 流程部署請求
 *
 * @author tp
 */
@Schema(description = "流程部署請求")
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class ActivitiDeployProcessReq {

    /**
     * Check Param
     */
    private static final String[] REQUIRED_PARAM = {"deployFolder"};
    /**
     * Check Multi Choice Param
     */
    private static final String[][] MULTI_CHOICE_PARAM = {};

    /**
     * 流程資源路徑
     */
    @Schema(description = "流程資源路徑：/tmp", required = true)
    private String deployFolder;

    /**
     * Get Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[] getRequiredParam() {
        return REQUIRED_PARAM.clone();
    }

    /**
     * Get Multi Choice Param
     *
     * @return
     */
    @Schema(accessMode = READ_ONLY)
    public String[][] getMultiChoiceParam() {
        return MULTI_CHOICE_PARAM;
    }

    public String getDeployFolder() {
        return deployFolder;
    }

    public void setDeployFolder(String deployFolder) {
        this.deployFolder = deployFolder;
    }
}
